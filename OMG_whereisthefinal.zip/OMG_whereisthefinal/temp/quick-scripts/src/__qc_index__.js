
require('./assets/script/audioEngine');
require('./assets/script/background');
require('./assets/script/data');
require('./assets/script/gameRule');
require('./assets/script/human');
require('./assets/script/welcome');
