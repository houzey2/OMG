
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/human.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2b5b6G5FHZOvbt0IV88u4KD', 'human');
// script/human.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    time: 0
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.sp = cc.v2(0, 0);
    this.state = '';
    this.humanAni = this.node.getComponent(cc.Animation);
  },
  setState: function setState(state) {
    if (this.state != state) {
      this.state = state;
    }

    this.humanAni.play(this.state);
  },
  start: function start() {},
  update: function update(dt) {
    this.time++;
    var state = '';

    if (this.time > 10) {
      var action = Math.floor(Math.random() * 4);

      if (action == 0 && this.node.y <= 640 - 16 - 32) {
        // up
        state = 'human_up';
        this.sp.x = 0;
        this.sp.y = 32;
      } else if (action == 1 && this.node.y >= 16 + 32) {
        // down
        state = 'human_down';
        this.sp.x = 0;
        this.sp.y = -32;
      } else if (action == 2 && this.node.x >= 16 + 32) {
        // left
        state = 'human_left';
        this.sp.x = -32;
        this.sp.y = 0;
      } else if (action == 3 && this.node.x <= 640 - 16 - 32) {
        // right
        state = 'human_right';
        this.sp.x = 32;
        this.sp.y = 0;
      } else {
        this.sp.x = 0;
        this.sp.y = 0;
      }

      if (this.sp.x) {
        this.node.x += this.sp.x;
      } else if (this.sp.y) {
        this.node.y += this.sp.y;
      }

      this.time = 0;

      if (state) {
        this.setState(state);
      } //console.log('x:'+ this.node.x + ' y:'+ this.node.y);

    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHQvaHVtYW4uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJ0aW1lIiwib25Mb2FkIiwic3AiLCJ2MiIsInN0YXRlIiwiaHVtYW5BbmkiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwiQW5pbWF0aW9uIiwic2V0U3RhdGUiLCJwbGF5Iiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImFjdGlvbiIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsInkiLCJ4Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsSUFBSSxFQUFFO0FBREUsR0FIUDtBQU9MO0FBRUFDLEVBQUFBLE1BVEssb0JBU0s7QUFDTixTQUFLQyxFQUFMLEdBQVVOLEVBQUUsQ0FBQ08sRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQVY7QUFDQSxTQUFLQyxLQUFMLEdBQWEsRUFBYjtBQUNBLFNBQUtDLFFBQUwsR0FBZ0IsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLFNBQTFCLENBQWhCO0FBQ0gsR0FiSTtBQWVMQyxFQUFBQSxRQWZLLG9CQWVJTCxLQWZKLEVBZVc7QUFDWixRQUFJLEtBQUtBLEtBQUwsSUFBY0EsS0FBbEIsRUFBeUI7QUFDckIsV0FBS0EsS0FBTCxHQUFhQSxLQUFiO0FBQ0g7O0FBQ0QsU0FBS0MsUUFBTCxDQUFjSyxJQUFkLENBQW1CLEtBQUtOLEtBQXhCO0FBQ0gsR0FwQkk7QUFzQkxPLEVBQUFBLEtBdEJLLG1CQXNCSSxDQUVSLENBeEJJO0FBMEJMQyxFQUFBQSxNQTFCSyxrQkEwQkdDLEVBMUJILEVBMEJPO0FBQ1IsU0FBS2IsSUFBTDtBQUNBLFFBQUlJLEtBQUssR0FBRyxFQUFaOztBQUNBLFFBQUksS0FBS0osSUFBTCxHQUFZLEVBQWhCLEVBQW9CO0FBQ2hCLFVBQUljLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFiOztBQUNBLFVBQUlILE1BQU0sSUFBSSxDQUFWLElBQWUsS0FBS1IsSUFBTCxDQUFVWSxDQUFWLElBQWUsTUFBTSxFQUFOLEdBQVcsRUFBN0MsRUFBaUQ7QUFDN0M7QUFDQWQsUUFBQUEsS0FBSyxHQUFHLFVBQVI7QUFDQSxhQUFLRixFQUFMLENBQVFpQixDQUFSLEdBQVksQ0FBWjtBQUNBLGFBQUtqQixFQUFMLENBQVFnQixDQUFSLEdBQVksRUFBWjtBQUNILE9BTEQsTUFLTyxJQUFJSixNQUFNLElBQUksQ0FBVixJQUFlLEtBQUtSLElBQUwsQ0FBVVksQ0FBVixJQUFlLEtBQUssRUFBdkMsRUFBMkM7QUFDOUM7QUFDQWQsUUFBQUEsS0FBSyxHQUFHLFlBQVI7QUFDQSxhQUFLRixFQUFMLENBQVFpQixDQUFSLEdBQVksQ0FBWjtBQUNBLGFBQUtqQixFQUFMLENBQVFnQixDQUFSLEdBQVksQ0FBQyxFQUFiO0FBQ0gsT0FMTSxNQUtBLElBQUlKLE1BQU0sSUFBSSxDQUFWLElBQWUsS0FBS1IsSUFBTCxDQUFVYSxDQUFWLElBQWUsS0FBSyxFQUF2QyxFQUEyQztBQUM5QztBQUNBZixRQUFBQSxLQUFLLEdBQUcsWUFBUjtBQUNBLGFBQUtGLEVBQUwsQ0FBUWlCLENBQVIsR0FBWSxDQUFDLEVBQWI7QUFDQSxhQUFLakIsRUFBTCxDQUFRZ0IsQ0FBUixHQUFZLENBQVo7QUFDSCxPQUxNLE1BS0EsSUFBSUosTUFBTSxJQUFJLENBQVYsSUFBZSxLQUFLUixJQUFMLENBQVVhLENBQVYsSUFBZSxNQUFNLEVBQU4sR0FBVyxFQUE3QyxFQUFpRDtBQUNwRDtBQUNBZixRQUFBQSxLQUFLLEdBQUcsYUFBUjtBQUNBLGFBQUtGLEVBQUwsQ0FBUWlCLENBQVIsR0FBWSxFQUFaO0FBQ0EsYUFBS2pCLEVBQUwsQ0FBUWdCLENBQVIsR0FBWSxDQUFaO0FBQ0gsT0FMTSxNQUtBO0FBQ0gsYUFBS2hCLEVBQUwsQ0FBUWlCLENBQVIsR0FBWSxDQUFaO0FBQ0EsYUFBS2pCLEVBQUwsQ0FBUWdCLENBQVIsR0FBWSxDQUFaO0FBQ0g7O0FBRUQsVUFBSSxLQUFLaEIsRUFBTCxDQUFRaUIsQ0FBWixFQUFlO0FBQ1gsYUFBS2IsSUFBTCxDQUFVYSxDQUFWLElBQWUsS0FBS2pCLEVBQUwsQ0FBUWlCLENBQXZCO0FBQ0gsT0FGRCxNQUVPLElBQUksS0FBS2pCLEVBQUwsQ0FBUWdCLENBQVosRUFBZTtBQUNsQixhQUFLWixJQUFMLENBQVVZLENBQVYsSUFBZSxLQUFLaEIsRUFBTCxDQUFRZ0IsQ0FBdkI7QUFDSDs7QUFFRCxXQUFLbEIsSUFBTCxHQUFZLENBQVo7O0FBRUEsVUFBSUksS0FBSixFQUFXO0FBQ1AsYUFBS0ssUUFBTCxDQUFjTCxLQUFkO0FBQ0gsT0FyQ2UsQ0FzQ2hCOztBQUNIO0FBRUo7QUF0RUksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgdGltZTogMCxcbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICBvbkxvYWQgKCkge1xuICAgICAgICB0aGlzLnNwID0gY2MudjIoMCwgMCk7IFxuICAgICAgICB0aGlzLnN0YXRlID0gJyc7XG4gICAgICAgIHRoaXMuaHVtYW5BbmkgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG4gICAgfSxcblxuICAgIHNldFN0YXRlKHN0YXRlKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlICE9IHN0YXRlKSB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5odW1hbkFuaS5wbGF5KHRoaXMuc3RhdGUpO1xuICAgIH0sXG5cbiAgICBzdGFydCAoKSB7XG5cbiAgICB9LFxuXG4gICAgdXBkYXRlIChkdCkge1xuICAgICAgICB0aGlzLnRpbWUrKztcbiAgICAgICAgbGV0IHN0YXRlID0gJyc7XG4gICAgICAgIGlmICh0aGlzLnRpbWUgPiAxMCkge1xuICAgICAgICAgICAgbGV0IGFjdGlvbiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQpO1xuICAgICAgICAgICAgaWYgKGFjdGlvbiA9PSAwICYmIHRoaXMubm9kZS55IDw9IDY0MCAtIDE2IC0gMzIpIHtcbiAgICAgICAgICAgICAgICAvLyB1cFxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX3VwJztcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnggPSAwO1xuICAgICAgICAgICAgICAgIHRoaXMuc3AueSA9IDMyO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMSAmJiB0aGlzLm5vZGUueSA+PSAxNiArIDMyKSB7XG4gICAgICAgICAgICAgICAgLy8gZG93blxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX2Rvd24nO1xuICAgICAgICAgICAgICAgIHRoaXMuc3AueCA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy5zcC55ID0gLTMyO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMiAmJiB0aGlzLm5vZGUueCA+PSAxNiArIDMyKSB7XG4gICAgICAgICAgICAgICAgLy8gbGVmdFxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX2xlZnQnO1xuICAgICAgICAgICAgICAgIHRoaXMuc3AueCA9IC0zMjtcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnkgPSAwO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMyAmJiB0aGlzLm5vZGUueCA8PSA2NDAgLSAxNiAtIDMyKSB7XG4gICAgICAgICAgICAgICAgLy8gcmlnaHRcbiAgICAgICAgICAgICAgICBzdGF0ZSA9ICdodW1hbl9yaWdodCc7XG4gICAgICAgICAgICAgICAgdGhpcy5zcC54ID0gMzI7XG4gICAgICAgICAgICAgICAgdGhpcy5zcC55ID0gMDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zcC54ID0gMDtcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnkgPSAwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5zcC54KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy5zcC54O1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLnNwLnkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUueSArPSB0aGlzLnNwLnk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMudGltZSA9IDA7XG5cbiAgICAgICAgICAgIGlmIChzdGF0ZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZygneDonKyB0aGlzLm5vZGUueCArICcgeTonKyB0aGlzLm5vZGUueSk7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfSxcbn0pO1xuIl19