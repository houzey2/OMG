
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/background.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45da1YETqRAT6FyGk0iNFtO', 'background');
// script/background.js

"use strict";

var globalMapKey = [];
var globalGameData = [];
var globalYear = 0;

var com = require('data');

cc.Class({
  "extends": cc.Component,
  properties: {
    humanNode: cc.Node,
    humanTimer: 0,
    audioBgm: cc.AudioClip,
    audioClick: cc.AudioClip,
    mapNode: cc.Node,
    water: cc.Prefab,
    //water 0
    sand: cc.Prefab,
    //sand 1
    grass: cc.Prefab,
    //grass 2
    town: cc.Prefab,
    //town 3
    crop: cc.Prefab,
    //crop 4
    wheat: cc.Prefab,
    //wheat 5
    vocan: cc.Prefab,
    //vocan 6
    stone: cc.Prefab,
    //stone 7
    tree: cc.Prefab,
    // tree 8
    fruit: cc.Prefab,
    //fruit 9
    berry: cc.Prefab,
    //berry 10
    chicken: cc.Prefab,
    //chicken 11
    dog: cc.Prefab,
    //dog 12
    cow: cc.Prefab,
    //cow 13
    sheep: cc.Prefab,
    //sheep 14
    lion: cc.Prefab,
    // lion 15
    poison: cc.Prefab,
    //berry 16
    populationText: cc.Label,
    foodText: cc.Label,
    resourceText: cc.Label,
    techText: cc.Label,
    LevelText: cc.Label,
    powerText: cc.Label,
    mapKey: [],
    nodeKey: [],
    prefabKey: [],
    gameData: [],
    sizeX: 20,
    sizeY: 20,
    time: 0,
    // year num
    frame: 0,
    button1: cc.Button,
    button2: cc.Button,
    button3: cc.Button,
    button4: cc.Button,
    button5: cc.Button,
    button6: cc.Button,
    log: cc.Label,
    gameOverString: cc.Label,
    gameOver: cc.Node,
    gameOverOrNot: false,
    gameOverTime: 0,
    logframe: 0,
    progressBar: {
      "default": null,
      type: cc.ProgressBar
    }
  },
  onLoad: function onLoad() {
    cc.audioEngine.play(this.audioBgm, true, 1);
    this.prefabKey = [this.water, this.sand, this.grass, this.town, this.crop, this.wheat, this.vocan, this.stone, this.tree, this.fruit, this.berry, this.chicken, this.dog, this.cow, this.sheep, this.lion, this.poison]; //                     0          1          2           3          4          5           6           7           8          9           10          11            12        13         14          15        16

    this.gameData = [10, 0, 300, 0, 1, 1, [0, 0, 0, 0, 0], 100, 100, 0, 100, 0]; //gameData [population, house, food, resource, tech, multiplier, [chicken, dog, cow, sheep, lion], power, powerMax, currentExp, ExpNeed, GodLevel]
    //             0          1      2       3       4       5                     6                     7       8           9        10        11

    this.initArray(this.mapKey, this.sizeX, this.sizeY);
    this.initArray(this.nodeKey, this.sizeX, this.sizeY);
    this.worldGen(this.mapKey); //console.log('restartOrNot');
    //console.log(com.restart);

    this.readUserData();
    console.log('gameOver =' + this.gameOverOrNot); //console.log(this.mapKey);
    //console.log(this.gameData);

    this.loadMap(this.nodeKey, this.mapKey);
    this.gameOver.active = false;
    this.sp = cc.v2(0, 0);
    this.state = '';
    this.humanAni = this.humanNode.getComponent(cc.Animation);
  },
  // set state for human moving
  setState: function setState(state) {
    if (this.state != state) {
      this.state = state;
    }

    this.humanAni.play(this.state);
  },
  //initial an empty array
  initArray: function initArray(array, row, colume) {
    for (var i = 0; i < row; i++) {
      array[i] = [];

      for (var j = 0; j < colume; j++) {
        array[i][j] = null;
      }
    }
  },
  //generate world map
  worldGen: function worldGen(arrayMap) {
    //setting a sea background
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        var item = 0;
        arrayMap[i][j] = item;
      }
    } //add sand as the island


    for (var _i = arrayMap.length / 2 - Math.floor(Math.random() * 5) - 1; _i < arrayMap.length / 2 + Math.floor(Math.random() * 5) + 1; _i++) {
      for (var _j = arrayMap[_i].length / 2 - Math.floor(Math.random() * 5) - 1; _j < arrayMap[_i].length / 2 + Math.floor(Math.random() * 5) + 1; _j++) {
        arrayMap[_i][_j] = 1;
      }
    } //add a single grassland


    for (var _i2 = arrayMap.length / 2 - Math.floor(Math.random() * 2) - 1; _i2 < arrayMap.length / 2 + Math.floor(Math.random() * 2) + 1; _i2++) {
      for (var _j2 = arrayMap[_i2].length / 2 - Math.floor(Math.random() * 2) - 1; _j2 < arrayMap[_i2].length / 2 + Math.floor(Math.random() * 2) + 1; _j2++) {
        arrayMap[_i2][_j2] = 2;
      }
    }

    arrayMap[arrayMap.length / 2][arrayMap[0].length / 2] = 2;
  },
  //load map from key
  loadMap: function loadMap(arrayNode, arrayMap) {
    for (var i = 0; i < arrayMap.length; i++) {
      for (var j = 0; j < arrayMap[i].length; j++) {
        arrayNode[i][j] = this.initNode(arrayMap[i][j], i, j, 32);
      }
    }
  },
  //add node as child
  initNode: function initNode(num, y, x, size) {
    var item = null;
    item = cc.instantiate(this.prefabKey[num]);
    var position = cc.v2(x * size + size / 2, y * size + size / 2);
    item.setPosition(position);
    item.name = y + '00' + x;
    this.mapNode.addChild(item);
    return item;
  },
  //number of item
  numOfItem: function numOfItem(array, num) {
    if (this.checkNodeExist(array, num)) {
      return this.findNode(array, num).length;
    }

    return 0;
  },
  //find if the node exist
  checkNodeExist: function checkNodeExist(array, number) {
    var ifFind = false;

    for (var i = 0; i < array.length; i++) {
      for (var j = 0; j < array[i].length; j++) {
        if (array[i][j] == number) {
          ifFind = true;
        }
      }
    }

    return ifFind;
  },
  //find the node with the key and return an array
  findNode: function findNode(array, number) {
    if (this.checkNodeExist(array, number)) {
      var arrayToReturn = [];
      var count = 0;

      for (var i = 0; i < array.length; i++) {
        for (var j = 0; j < array[i].length; j++) {
          if (array[i][j] == number) {
            arrayToReturn[count] = [i, j];
            count++;
          }
        }
      }

      return arrayToReturn;
    }
  },
  //check if the current location is in bound
  inBound: function inBound(y, x) {
    if (y < 0 || y >= this.sizeY || x < 0 || x >= this.sizeX) {
      return false;
    } else {
      return true;
    }
  },
  //replace with node by corredinate
  replaceNodeByCoordinate: function replaceNodeByCoordinate(arrayNode, arrayMap, y, x, newNum) {
    var nodeToDestory = this.mapNode.getChildByName(y + '00' + x);
    nodeToDestory.destroy();
    arrayNode[y][x] = this.initNode(newNum, y, x, 32);
    arrayMap[y][x] = newNum;
  },
  //replacew a single block of orgenNum type to newNum
  replaceNodeByKind: function replaceNodeByKind(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var listOfItem = this.findNode(arrayMap, origenNum);
      var index = Math.floor(Math.random() * listOfItem.length);
      this.replaceNodeByCoordinate(arrayNode, arrayMap, listOfItem[index][0], listOfItem[index][1], newNum);
      return [listOfItem[index][0], listOfItem[index][1]];
    }
  },
  //replace all node with 
  replaceAll: function replaceAll(arrayNode, arrayMap, origenNum, newNum) {
    if (this.checkNodeExist(arrayMap, origenNum)) {
      var replaceArray = this.findNode(arrayMap, origenNum);

      for (var i = 0; i < replaceArray.length; i++) {
        this.replaceNodeByCoordinate(arrayNode, arrayMap, replaceArray[i][0], replaceArray[i][1], newNum);
      }
    }
  },
  //check surrounding blocks
  surCheck: function surCheck(array, y, x, numToReplace) {
    for (var i = -1; i < 2; i++) {
      for (var j = -1; j < 2; j++) {
        if (this.inBound(y + i, x + j)) {
          if (array[y + i][x + j] == numToReplace) {
            return true;
          }
        }
      }
    }

    return false;
  },
  //replace x number of block with 'origenNum' type that surround (x,y) block with 'replaceNum' type
  surReplaceSingleOfType: function surReplaceSingleOfType(arrayNode, arrayMap, y, x, origenNum, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    if (this.surCheck(this.mapKey, y, x, origenNum)) {
      //while the surrounding node is not the origenal node we want to replace
      while (arrayMap[newY][newX] != origenNum || !this.inBound(newY, newX)) {
        moveX = Math.floor(Math.random() * 3) - 1;
        moveY = Math.floor(Math.random() * 3) - 1;
        newX = x + moveX;
        newY = y + moveY;
      }

      this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
    }
  },
  //replace x number of block that surround (x,y) block with 'replaceNum' type
  surReplaceSingle: function surReplaceSingle(arrayNode, arrayMap, y, x, replaceNum) {
    //gives a placement -1, 0, 1
    var moveX = Math.floor(Math.random() * 3) - 1;
    var moveY = Math.floor(Math.random() * 3) - 1;
    var newX = x + moveX;
    var newY = y + moveY;

    while (moveX == 0 && moveY == 0 || !this.inBound(newY, newX)) {
      moveX = Math.floor(Math.random() * 3) - 1;
      moveY = Math.floor(Math.random() * 3) - 1;
      newX = x + moveX;
      newY = y + moveY;
    }

    this.replaceNodeByCoordinate(arrayNode, arrayMap, newY, newX, replaceNum);
  },
  clickBackHomeButton: function clickBackHomeButton() {
    console.log('return to main page');
    this.saveUserData();
    cc.audioEngine.stopAll();
    cc.director.loadScene("welcome");
  },
  clickShareButton: function clickShareButton() {
    canvas.toTempFilePath({
      destWidth: 800,
      destHeight: 640,
      success: function success(res) {
        console.log("可以保存该截屏图片  ", res);
        wx.shareAppMessage({
          title: "欢迎参观我的岛屿～",
          imageUrl: res.tempFilePath,
          success: function success(res) {},
          fail: function fail() {}
        });
      }
    });
  },
  //actions  ************************************************************************************************************************************
  //click button "1"
  clickButton1: function clickButton1() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < this.gameData[8]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] = 0;
    this.action1();
  },
  //click button "2"
  clickButton2: function clickButton2() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 60) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 60;
    this.action2();
  },
  //click button "3"
  clickButton3: function clickButton3() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 40) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 40;
    this.action3();
  },
  //click button "4"
  clickButton4: function clickButton4() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 20 + this.gameData[11]) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 20 + this.gameData[11];
    this.action4();
  },
  //click button "5"
  clickButton5: function clickButton5() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 30) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 30;
    this.action5();
  },
  //click button "6"
  clickButton6: function clickButton6() {
    cc.audioEngine.play(this.audioClick, false, 1);

    if (this.gameData[7] < 50) {
      this.log.string = '法力值不足，点击无效\n' + this.log.string;
      return;
    }

    this.gameData[7] -= 50;
    this.action6();
  },
  //land
  action1: function action1() {
    //if (mana < 120) {
    //    return;
    //}
    //mana -= 120;
    this.genGround(); //增加陆地，消耗全部法力
  },
  //stone
  action2: function action2() {
    //if (mana < 60) {
    //    //notification
    //    return;
    //}
    //mana -= 60;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var randomNum = Math.floor(Math.random() * 2);

      switch (randomNum) {
        case 0:
          this.genGround(); //增加陆地

          break;

        case 1:
          this.genStone(this.gameData); //刷新铁矿，发现加科技

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      var numbersOfAction = 2;

      var _randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (_randomNum) {
        case 0:
          this.genVocano(); //生成火山

          break;

        case 1:
          this.vocanoEx(this.mapKey); //火山喷发，产生石头

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction = 2;

      var _randomNum2 = Math.floor(Math.random() * _numbersOfAction);

      switch (_randomNum2) {
        case 0:
          this.desertification(this.nodeKey, this.mapKey); //沙漠化

          break;

        case 1:
          this.earthquake(this.nodeKey, this.mapKey); //地震

          break;
      }
    }
  },
  //sky
  action3: function action3() {
    // 好事啊
    //if (mana < 40) {
    //    //notification
    //    return;
    //}
    //mana -= 40;
    var random = Math.random();

    if (random < Math.pow(0.1, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.storm(this.gameData); //雷 增加科技

          break;

        case 1:
          this.foodDouble(this.gameData); //丰收

          break;
      }
    } else if (random < Math.pow(0.8, this.gameData[4])) {
      // 就那么回事吧
      var _numbersOfAction2 = 2;

      var _randomNum3 = Math.floor(Math.random() * _numbersOfAction2);

      switch (_randomNum3) {
        case 0:
          this.rain(this.gameData); //降水

          break;

        case 1:
          this.wind(this.nodeKey, this.mapKey); //风， 吹走任何物品

          break;
      }
    } else {
      // 不要这个！！
      var _numbersOfAction3 = 1; //need change

      var _randomNum4 = Math.floor(Math.random() * _numbersOfAction3);

      switch (_randomNum4) {
        case 0:
          this.drought(this.gameData); //干旱，概率火灾，粮食减产

          break;

        case 1:
          //水灾，土地变成水
          break;

        case 2:
          //this.onFire(); //火灾
          break;
      }
    }
  },
  //plant
  action4: function action4() {
    //if (mana < 10) {
    //notification
    //    return;
    //}
    //mana -= 10;
    // 好事啊
    var random = Math.random();

    if (random < Math.pow(0.7, this.gameData[4])) {
      var numbersOfAction = 3;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genBerry(); //果树 前期物资，加食物

          break;

        case 1:
          this.genTree(); //树

          break;

        case 2:
          this.genGrass(); //草

          break;
      }
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genPoison(); //毒果子，吃了会死。
    } else {
      // 不要这个！！
      this.genCrop(); //耕地
    }
  },
  //animal
  action5: function action5() {
    //if (mana < 30) {
    //    //notification
    //    return;
    //}
    //mana -= 30;
    // 小型动物
    var random = Math.random();

    if (random < Math.pow(0.5, this.gameData[4])) {
      var numbersOfAction = 2;
      var randomNum = Math.floor(Math.random() * numbersOfAction);

      switch (randomNum) {
        case 0:
          this.genDog(this.gameData); // 🐕，科技值大于1.2驯服，减少大型动物攻击概率

          break;

        case 1:
          this.genChicken(); // 🐓，科技之大于 1.1驯服，每年少量🍗

          break;
      }
    } else if (random < Math.pow(0.75, this.gameData[4])) {
      // 中型动物
      this.genSheep(); //🐏， 每年中量🍖，科技值大于2 可驯服
    } else if (random < Math.pow(0.9, this.gameData[4])) {
      // 就那么回事吧
      this.genCow(); //🐂， 会攻击人，每年大量🥩，科技值大于3可驯服，驯服后攻击
    } else {
      // 不要这个！！
      this.genLion(this.gameData); //🦁，会攻击人，无法驯服
    }
  },
  //population
  action6: function action6() {
    this.genPeople(this.gameData); //this.gameData[0] = 0;//test
  },
  //spawn island, spawn vocan, spawn stone, desertification  ****************************************************************************************************
  genPeople: function genPeople(arrayData) {
    if (arrayData[2] > 50) {
      arrayData[0] += 5;
      arrayData[2] -= 50;
      this.log.string = '人口+5\n' + this.log.string;
      this.gameData[9] += 5;
    } else {
      this.log.string = '食物不足，需要50食物\n' + this.log.string;
    }
  },
  //extend ground
  genGround: function genGround() {
    var position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);

    if (this.surCheck(this.mapKey, position[0], position[1], 0) == false) {
      position = this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    }

    for (var i = 0; i < 1 + 2 * Math.floor(Math.random() * 4); i++) {
      this.surReplaceSingleOfType(this.nodeKey, this.mapKey, position[0], position[1], 0, 1);
    }

    if (!this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 1);
    }

    this.gameData[9] += 20;
    console.log('陆地扩张');
    this.log.string = '第' + this.time + '年 ' + ' 陆地扩张\n' + this.log.string;
  },
  genStone: function genStone(arrayData) {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 7);
      arrayData[4] += 0.01;
      console.log('找到矿物，科技+0.01');
      arrayData[9] += 10;
      arrayData[3] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 人们发现发现了一个新石矿，\n资源+10,科技+0.01\n' + this.log.string;
    } else {
      this.log.string = '空地不足，无法获取石矿' + this.log.string;
    }
  },
  //generate a vocano
  genVocano: function genVocano() {
    if (this.checkNodeExist(this.mapKey, 1)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 6);
      this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
    } else {
      if (this.checkNodeExist(this.mapKey, 0) == false) {
        this.log.string = '空地不足，无法形成火山' + this.log.string;
      } else {
        this.replaceNodeByKind(this.nodeKey, this.mapKey, 0, 6);
        this.log.string = '第' + this.time + '年 ' + ' 板块运动，形成火山\n' + this.log.string;
      }
    }
  },
  // vocano explode
  vocanoEx: function vocanoEx(arrayMap) {
    if (this.checkNodeExist(this.mapKey, 6)) {
      var listOfItem = this.findNode(arrayMap, 6);
      var index = Math.floor(Math.random() * listOfItem.length);

      for (var i = 0; i < Math.floor(Math.random() * 4) + 1; i++) {
        this.surReplaceSingle(this.nodeKey, this.mapKey, listOfItem[index][0], listOfItem[index][1], 7);
      }

      this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
    } else {
      this.genVocano();

      if (this.checkNodeExist(this.mapKey, 6)) {
        this.log.string = '第' + this.time + '年 ' + ' 火山喷发\n' + this.log.string;
      }
    }
  },
  //earthquake
  earthquake: function earthquake(arrayNode, arrayMap) {
    for (var i = 0; i < Math.floor(Math.random() * 10) + 5; i++) {
      var y = Math.floor(Math.random() * arrayMap.length);
      var x = Math.floor(Math.random() * arrayMap[0].length);
      var oriHouse = this.numOfItem(arrayMap, 3);

      for (var _i3 = 0; _i3 < Math.floor(Math.random() * oriHouse / 3); _i3++) {
        if (this.numOfItem(arrayMap, 3) > 0) {
          this.surReplaceSingleOfType(arrayNode, arrayMap, y, x, 3, 7);
          this.gameData[0] -= Math.ceil(Math.random() * 3);

          if (this.gameData[0] <= 0) {
            this.gameData[0] = 0;
          }
        }
      }
    }

    console.log('地震啦');
    this.gameData[9] -= 10;
    this.log.string = '第' + this.time + '年 ' + ' 发生了地震，人口减少\n' + this.log.string;
  },
  //Desertification
  desertification: function desertification(arrayNode, arrayMap) {
    var randNum = Math.random();

    if (this.checkNodeExist(this.mapKey, 2)) {
      var grass = this.findNode(this.mapKey, 2);

      for (var i = 0; i < Math.floor(grass.length / 10); i++) {
        randNum = Math.random();

        if (randNum < 0.6) {
          this.replaceNodeByKind(arrayNode, arrayMap, 2, 1);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var crop = this.findNode(this.mapKey, 5);

      for (var _i4 = 0; _i4 < Math.floor(crop.length / 10); _i4++) {
        randNum = Math.random();

        if (randNum < 0.4) {
          this.replaceNodeByKind(arrayNode, arrayNode, 4, 1);
        }
      }
    }

    console.log('沙漠化');
    this.gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 土地沙漠化，农田收成受损\n' + this.log.string;
  },
  //rain, dry, harvest, storm  *****************************************************************************************************************************
  //harvest
  foodDouble: function foodDouble(gameData) {
    gameData[2] *= 1.5;
    console.log('食物丰收');
    gameData[9] += 20;
    this.log.string = '第' + this.time + '年 ' + ' 风调雨顺，食物大丰收，食物*2\n' + this.log.string;
  },
  //storm
  storm: function storm(gameData) {
    var word = '';
    gameData[4] += 0.01;

    if (Math.random() > 0.5) {
      gameData[5] += 0.2;
      word = '雨水灌溉了庄稼';
      gameData[9] += 10;
    } else {
      gameData[5] -= 0.2;
      gameData[9] -= 10;
      word = '造成水灾';
    }

    console.log('雷阵雨');
    this.log.string = '第' + this.time + '年 ' + ' 雷阵雨 ' + word + '\n' + this.log.string;
  },
  //rain: food boost
  rain: function rain(gameData) {
    gameData[5] += Math.random() / 2;
    console.log('下雨啦');
    gameData[9] += 10;
    this.log.string = '第' + this.time + '年 ' + ' 下雨啦\n' + this.log.string;
  },
  //drought: food decay
  drought: function drought(gameData) {
    gameData[5] -= Math.random() / 2;
    console.log('干旱');
    gameData[9] -= 20;
    this.log.string = '第' + this.time + '年 ' + ' 雨水少，发生了干旱\n' + this.log.string;
  },
  //wind: reomve some node
  wind: function wind(arrayNode, arrayMap) {
    if (this.checkNodeExist(this.mapKey, 8)) {
      var tree = this.findNode(arrayMap, 8);

      for (var i = 0; i < Math.floor(tree.length / 10); i++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 8, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 5)) {
      var wheat = this.findNode(arrayMap, 5);

      for (var _i5 = 0; _i5 < Math.floor(wheat.length / 10); _i5++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 3)) {
      var house = this.findNode(arrayMap, 3);

      for (var _i6 = 0; _i6 < Math.floor(house.length / 10); _i6++) {
        if (Math.random() < 0.1) {
          this.replaceNodeByKind(arrayNode, arrayMap, 3, 2);
        }
      }
    }

    if (this.checkNodeExist(this.mapKey, 7)) {
      var stone = this.findNode(arrayMap, 7);

      for (var _i7 = 0; _i7 < Math.floor(stone.length / 10); _i7++) {
        if (Math.random() < 0.2) {
          this.replaceNodeByKind(arrayNode, arrayMap, 7, 2);
        }
      }
    }

    console.log('刮大风');
    this.log.string = '第' + this.time + '年 ' + ' 大风来袭\n' + this.log.string;
  },
  ////fire event
  //onFire: function (arrayNode, arrayMap) {
  //    let listOfItemForest = this.findNode(arrayMap, 4);
  //    let listOfItemHouse = this.findNode(arrayMap, 6);
  //    let listOfItemFram = this.findNode(arrayMap, 7);
  //    let numbersOfPlace = 3;
  //    let randomNum = Math.floor(Math.random() * numbersOfPlace);
  //    switch (randomNum) {
  //        case 0: if (listOfItemForest != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemForest[index][0], listOfItemForest[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 1: if (listOfItemHouse != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemHouse[index][0], listOfItemHouse[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //        case 2: if (listOfItemHouseFram != null) {
  //            let index = (Math.floor(Math.random() * listOfItem.length));
  //            this.replaceNode(arrayNode, arrayMap, listOfItemFram[index][0], listOfItemFram[index][1], 9);
  //            return [listOfItem[index][0], listOfItem[index][1]];
  //        }
  //            break;
  //    }
  //    this.log.string = 'Year ' + this.time + ' onFire\n' + this.log.string;
  //},
  ////off fire event
  //OffFire: function (arrayNode, arrayMap) {
  //    this.replaceAll(arrayNode, arrayMap, 9, 1);
  //    this.log.string = 'Year ' + this.time + ' off fire\n' + this.log.string;
  //},
  //berry, tree, fruit, poison  **************************************************************************************************************************
  //grow berrybush
  genBerry: function genBerry() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 10);
      console.log('生成果丛');
      this.log.string = '生成浆果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //grow poison
  genPoison: function genPoison() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 16);
      console.log('生成毒果丛');
      this.log.string = '第' + this.time + '年 ' + ' 生成毒果丛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，种植浆果丛失败\n' + this.log.string;
    }
  },
  //plant crop
  genCrop: function genCrop() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 4);
      console.log('生成耕地');
      this.gameData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + ' 开拓耕地\n' + this.log.string;
    } else {
      this.log.string = '草地不足，开垦耕地失败\n' + this.log.string;
    }
  },
  //grass grow up to trees
  genTree: function genTree() {
    if (this.checkNodeExist(this.mapKey, 2) == false) {
      this.log.string = '草地不足，植树造林失败\n' + this.log.string;
      return;
    }

    this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 8);
    console.log('生成树');
    this.log.string = '第' + this.time + '年 ' + ' 植树造林\n' + this.log.string;
  },
  genGrass: function genGrass() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 1, 2);
    console.log('生成草');
    this.log.string = '第' + this.time + '年 ' + ' 草，指一种植物\n' + this.log.string;
  },
  //chicken, dog, cow, sheep, lion      *************************************************************************************************************************
  genChicken: function genChicken() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 11);
      console.log('生成鸡');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野鸡\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genDog: function genDog(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 12);
      arrayData[6][1] += 1;
      console.log('生成狼');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只野狼\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genCow: function genCow() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 13);
      console.log('生成牛');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头野牛\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genSheep: function genSheep() {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 14);
      console.log('生成羊');
      this.log.string = '第' + this.time + '年 ' + ' 发现一只羊\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  genLion: function genLion(arrayData) {
    if (this.checkNodeExist(this.mapKey, 2)) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 15);
      arrayData[6][4] += 1;
      console.log('生成狮子');
      this.log.string = '第' + this.time + '年 ' + ' 发现一头凶猛的狮子\n' + this.log.string;
    } else {
      this.log.string = '草地不足，触发动物事件失败\n' + this.log.string;
    }
  },
  //update function ***********************************************************************************************************************************************
  //power restore
  powerUpdate: function powerUpdate(gameData) {
    gameData[7] += 10 + gameData[8] * 0.05;

    if (gameData[9] >= gameData[10]) {
      //level up
      gameData[8] += 20;
      gameData[9] -= gameData[10];
      gameData[10] = gameData[10] * 1.2;
      gameData[11]++;
    } else if (gameData[9] < 0) {
      gameData[8] -= 20;
      gameData[10] = gameData[10] / 1.2;

      if (gameData[10] <= 100) {
        gameData[10] == 100;
      }

      gameData[9] = gameData[10] + gameData[9];
      gameData[11]--;

      if (gameData[11] < 0) {
        gameData[11] = 0;
      }
    }

    if (gameData[7] >= gameData[8]) {
      gameData[7] = gameData[8];
    }
  },
  //gather berrybush
  gatherBerry: function gatherBerry(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 10, 2);
    arrayData[2] += 3;
    console.log('gather berry');
    arrayData[9] += 5;
    this.log.string = '收集浆果，食物+3\n' + this.log.string;
  },
  //gather poison
  gatherPoison: function gatherPoison(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 16, 2);
    arrayData[0] -= 1;
    console.log('gather poison');
    arrayData[9] -= 10;
    this.log.string = '一个不幸的人吃了剧毒的果子，人口-1\n' + this.log.string;
  },
  //the fruit trees around town harvest
  gatherFruit: function gatherFruit(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 9, 8);
    arrayData[2] += 5;
    console.log('fruit harvest');
    arrayData[9] += 10;
    this.log.string = '人们外出游玩，采摘果子，食物+5\n' + this.log.string;
  },
  gatherCrop: function gatherCrop(arrayData, arrayMap, num) {
    console.log('gather food');
    var gathercount = num;
    var numFruit = this.numOfItem(arrayMap, 9);
    var numBerry = this.numOfItem(arrayMap, 10);
    var numPoison = this.numOfItem(arrayMap, 16);

    if (numFruit > 0 || numBerry > 0 || numPoison > 0) {
      arrayData[9] += 5;
    }

    if (num > numFruit + numBerry + numPoison) {
      gathercount = numBerry + numPoison + numFruit;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering food');

      if (numFruit > 0) {
        this.gatherFruit(arrayData);
      } else {
        if (numPoison <= 0) {
          this.gatherBerry(arrayData);
        } else if (numBerry <= 0) {
          this.gatherPoison(arrayData);
        } else {
          if (Math.random() > 0.5) {
            this.gatherBerry(arrayData);
          } else {
            this.gatherPoison(arrayData);
          }
        }
      }
    }
  },
  gatherTree: function gatherTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[9] += 10;
    console.log('gather tree, resource + 20');
    this.log.string = '采集到树木，资源+10\n' + this.log.string;
  },
  gatherFruitTree: function gatherFruitTree(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 2);
    arrayData[3] += 10;
    arrayData[2] += 4;
    arrayData[9] += 10;
    console.log('gather fruit tree, resource + 20');
    this.log.string = '采集到果树，资源+10，食物+4\n' + this.log.string;
  },
  gatherStone: function gatherStone(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 7, 1);
    arrayData[3] += 30;
    arrayData[9] += 10;
    console.log('gather stone, resource + 20');
    this.log.string = '发现了矿石，资源+30\n' + this.log.string;
  },
  gatherResource: function gatherResource(arrayData, arrayMap, num) {
    console.log('gather resource');
    var gathercount = num;
    var numTree = this.numOfItem(arrayMap, 8);
    var numFruitTree = this.numOfItem(arrayMap, 9);
    var numStone = this.numOfItem(arrayMap, 7);

    if (numTree > 0 || numFruitTree > 0 || numStone > 0) {}

    if (num > numTree + numStone + numFruitTree) {
      gathercount = numTree + numStone + numFruitTree;
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering resource');

      if (numStone > 0) {
        this.gatherStone(arrayData);
      } else {
        if (numTree <= 0) {
          this.gatherFruitTree(arrayData);
        } else {
          this.gatherTree(arrayData);
        }
      }
    }
  },
  killChicken: function killChicken(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 11, 2);
    arrayData[2] += 5;
    console.log('kill chicken');
    arrayData[9] += 1;
    this.log.string = '一只鸡被杀来吃了，食物+5，经验+1\n' + this.log.string;
  },
  killDog: function killDog(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 12, 2);
    arrayData[5][1] -= 1;
    var dead = Math.floor(Math.random() * 2);
    arrayData[0] -= dead;
    arrayData[2] += 4;
    console.log('kill dog');

    if (dead == 1) {
      arrayData[9] += 0;
      this.log.string = '杀死狼' + '，不过有' + dead + '死于狼爪下\n' + this.log.string;
    } else {
      arrayData[9] += 5;
      this.log.string = '杀死狼' + '，不过有' + dead + '死于狼爪下，经验+5\n' + this.log.string;
    }
  },
  killCow: function killCow(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 13, 2);
    var dead = Math.floor(Math.random() * 3);
    arrayData[0] -= dead;
    arrayData[2] += 8;
    console.log('kill cow');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '杀死牛' + '，不过有' + dead + '死于牛角下，经验+10\n' + this.log.string;
    }

    this.log.string = '杀死牛' + '，不过有' + dead + '死于牛角下\n' + this.log.string;
  },
  killSheep: function killSheep(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 14, 2);
    arrayData[2] += 4;
    console.log('kill sheep');
    arrayData[9] += 5;
    this.log.string = '一只羊被杀做烤全羊，食物+4\n' + this.log.string;
  },
  killLion: function killLion(arrayData) {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 15, 2);
    arrayData[5][4] -= 1;
    var dead = Math.floor(Math.random() * 4);
    arrayData[0] -= dead;
    arrayData[2] += 16;
    console.log('kill lion');

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '杀死狮子' + '，不过有' + dead + '人被狮子咬死了\n' + this.log.string;
    } else if (dead = 0) {
      arrayData[9] += 20;
      this.log.string = '捕获一头狮子，经验+20' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '捕杀狮子的过程中，有' + dead + '人牺牲,经验+10' + this.log.string;
    }
  },
  gatherMeat: function gatherMeat(arrayData, arrayMap, num) {
    console.log('gather meat');
    var gathercount = num;
    var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];
    var wolf = this.numOfItem(arrayMap, 12);
    var lion = this.numOfItem(arrayMap, 15);

    if (chicken > 0 || sheep > 0 || cow > 0 || wolf > 0 || lion > 0) {
      this.log.string = '从动物身上获取肉，食物增加\n' + this.log.string;
    }

    if (num > Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4)) {
      gathercount = Math.floor(chicken + sheep / 2 + cow / 3 + wolf / 2 + lion / 4);
    }

    for (var i = 0; i < gathercount; i++) {
      console.log('gathering meat');

      if (chicken > 0) {
        this.killChicken(arrayData);

        if (Math.random() < 0.1 && arrayData[6][0] > 0) {
          arrayData[6][0] -= 1;
        }
      } else if (sheep > 0) {
        this.killSheep(arrayData);

        if (Math.random() < 0.09 && arrayData[6][3] > 0) {
          arrayData[6][3] -= 1;
        }
      } else if (cow > 0) {
        this.killCow(arrayData);

        if (Math.random() < 0.08 && arrayData[6][2] > 0) {
          arrayData[6][2] -= 1;
        }
      } else if (wolf > 0) {
        this.killDog(arrayData);
      } else {
        this.killLion(arrayData);
      }
    }
  },
  tameChicken: function tameChicken(arrayData) {
    arrayData[6][0] += 1;
    console.log('tam chicken');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一只鸡，经验+5\n' + this.log.string;
  },
  tameCow: function tameCow(arrayData) {
    arrayData[6][2] += 1;
    arrayData[0] -= Math.floor(Math.random() * 2);
    console.log('tam cow');
    var dead = Math.floor(Math.random() * 4);

    if (dead >= 2) {
      arrayData[9] += 0;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛\n' + this.log.string;
    } else {
      arrayData[9] += 10;
      this.log.string = '第' + this.time + '年 ' + '成功驯服并永远拥有一头牛,经验+10\n' + this.log.string;
    }
  },
  tameSheep: function tameSheep(arrayData) {
    arrayData[6][3] += 1;
    console.log('tam sheep');
    arrayData[9] += 5;
    this.log.string = '第' + this.time + '年 ' + ' 成功驯服并永远拥有一只羊，经验+5\n' + this.log.string;
  },
  gatherTam: function gatherTam(arrayData, arrayMap, num) {
    console.log('try taming');
    var ifTamed = false; //let chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
    //let sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
    //let cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

    for (var i = 0; i < num; i++) {
      var chicken = this.numOfItem(arrayMap, 11) - arrayData[6][0];
      var sheep = this.numOfItem(arrayMap, 14) - arrayData[6][3];
      var cow = this.numOfItem(arrayMap, 13) - arrayData[6][2];

      if (chicken > 0 && Math.random() < 0.5) {
        this.tameChicken(arrayData);
        ifTamed = true;
      } else if (sheep > 0 && Math.random() < 0.4 && this.gameData[4] >= 1.2) {
        this.tameSheep(arrayData);
        ifTamed = true;
      } else if (cow > 0 && Math.random() < 0.3 && this.gameData[4] >= 1.4) {
        this.tameCow(arrayData);
        ifTamed = true;
      }
    }
    /*if (chicken + sheep + cow > 0) {
        if (!ifTamed) {
            this.log.string = '驯服失败\n' + this.log.string;
        }
    } else {
        this.log.string = '无动物驯服\n' + this.log.string;
    }*/

  },
  // update AI ******************************************************************************************************
  buildHouse: function buildHouse(gameData) {
    if (gameData[3] >= 100 && gameData[1] < gameData[0] / 2) {
      this.replaceNodeByKind(this.nodeKey, this.mapKey, 2, 3);
      gameData[3] -= 100;
      gameData[1] += 1;
      this.log.string = '成功建造一栋房子\n' + this.log.string;
    } else {}
  },
  foodUpdate: function foodUpdate(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    arrayData[2] += numOfPlot * 16 * arrayData[4] * arrayData[5] - arrayData[0] * 4;

    if (arrayData[2] < 0) {
      arrayData[2] = 0;
    }

    console.log('food: ' + Math.floor(arrayData[2]));
  },
  //crop grow
  growCrop: function growCrop() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 4, 5);
    console.log('crop grow');
    this.log.string = '庄稼成熟了\n' + this.log.string;
  },
  //trees around the town change to fruit trees
  growFruit: function growFruit() {
    this.replaceNodeByKind(this.nodeKey, this.mapKey, 8, 9);
    console.log('fruit');
    this.log.string = '树上结果子了\n' + this.log.string;
  },
  resourceDestory: function resourceDestory(arrayData, arrayMap) {
    var chicken = [this.numOfItem(arrayMap, 11) - arrayData[6][0], 11, 0.1];
    var sheep = [this.numOfItem(arrayMap, 14) - arrayData[6][3], 14, 0.05];
    var cow = [this.numOfItem(arrayMap, 13) - arrayData[6][2], 13, 0.05];
    var wolf = [this.numOfItem(arrayMap, 12), 12, 0.05];
    var lion = [this.numOfItem(arrayMap, 15), 15, 0.1];
    var berry = [this.numOfItem(arrayMap, 10), 10, 0.4];
    var poison = [this.numOfItem(arrayMap, 16), 16, 0.4];
    var tree = [this.numOfItem(arrayMap, 8), 8, 0.05];
    var fruit = [this.numOfItem(arrayMap, 9), 9, 0.05];
    var itemList = [chicken, sheep, cow, wolf, lion, berry, poison, tree, fruit];

    for (var i = 0; i < itemList.length; i++) {
      for (var j = 0; j < itemList[i][0]; j++) {
        if (Math.random() < itemList[i][2]) {
          this.replaceNodeByKind(this.nodeKey, this.mapKey, itemList[i][1], 2);
        }
      }
    }
  },
  landupdate: function landupdate(arrayData, arrayNode, arrayMap) {
    this.resourceDestory(arrayData, arrayMap);

    for (var i = 0; i < this.numOfItem(arrayMap, 4); i++) {
      this.growCrop();
    }

    for (var _i8 = 0; _i8 < this.numOfItem(arrayMap, 8); _i8++) {
      if (Math.random() < 0.3) {
        this.growFruit();
      }
    }

    var numOfPlot = this.numOfItem(arrayMap, 5);

    while (numOfPlot > arrayData[0]) {
      this.replaceNodeByKind(arrayNode, arrayMap, 5, 2);
      numOfPlot -= 1;
      console.log('not enough people farming');
    }
  },
  techUpdate: function techUpdate(arrayData) {
    arrayData[4] += 0.005;
    console.log('tech: ' + Math.round(arrayData[4])); //this.log.string = '科技值+0.001\n' + this.log.string;
  },
  populationUpdate: function populationUpdate(arrayData) {
    var wolf = this.numOfItem(this.mapKey, 12);
    var lion = this.numOfItem(this.mapKey, 15);

    for (var i = 0; i < wolf; i++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.1) {
        arrayData[0] -= 1;
        this.log.string = '缺少房屋，一个不幸的流浪汉被野狼杀害\n' + this.log.string;
      }
    }

    for (var _i9 = 0; _i9 < lion; _i9++) {
      if (arrayData[0] > arrayData[1] * 3 && Math.random() < 0.3) {
        arrayData[0] -= 1;
        this.log.string = '缺少房屋，一个不幸的流浪汉被狮子杀害\n' + this.log.string;
      }
    }

    if (arrayData[2] == 0) {
      this.log.string = '第' + this.time + '年 ' + ' 饥荒,人口损失惨重\n' + this.log.string;

      if (arrayData[0] > 3) {
        arrayData[0] = Math.ceil(arrayData[0] * 3 / 4); //this.log.string = Math.ceil(arrayData[0] * 1 / 4); + this.log.string;
      } else {
        arrayData[0] = Math.floor(arrayData[0] * 3 / 4);
      }

      if (arrayData[0] == 1) {
        arrayData[0] = 0;
      }
    }
  },
  changeWeather: function changeWeather(arrayData) {
    arrayData[5] -= (arrayData[5] - 1) / 5;
    arrayData[5] -= 0.005;
  },
  yearCheck: function yearCheck(arrayData, arrayNode, arrayMap) {
    this.buildHouse(arrayData);
    this.gatherFood(arrayData, arrayMap);
  },
  gatherAI: function gatherAI(arrayData, arrayMap) {
    var numOfPlot = this.numOfItem(arrayMap, 5);
    var food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];
    var remain = arrayData[0] - this.numOfItem(arrayMap, 5);

    if (food <= arrayData[0] * 8) {
      this.gatherCrop(arrayData, arrayMap, remain);
      food = numOfPlot * 20 - arrayData[0] * 4 + arrayData[2];

      if (food <= arrayData[0] * 4) {
        this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 2));
      }
    } else if (food <= arrayData[0] * 16) {
      this.gatherCrop(arrayData, arrayMap, Math.floor(remain / 6));
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 3));
    } else {
      this.gatherResource(arrayData, arrayMap, Math.floor(remain / 2));
      this.gatherTam(arrayData, arrayMap, Math.floor(remain / 2));
    }

    if (arrayData[0] > 50) {
      this.gatherMeat(arrayData, arrayMap, Math.floor(remain / 10));
    }
  },
  // check if the next tile human heading to is water or somewhere it should not be
  canHumanMove: function canHumanMove(actionNum) {
    var currX = Math.floor(this.humanNode.x / 32);
    var currY = Math.floor(this.humanNode.y / 32);

    if (actionNum == 0) {
      // up
      currY++;
    } else if (actionNum == 1) {
      //down
      currY--;
    } else if (actionNum == 2) {
      //left
      currX--;
    } else {
      //right
      currX++;
    }

    if (this.mapKey[currY][currX] == 0) {
      // add other keys if necessary
      return false;
    } else {
      return true;
    }
  },
  humanMove: function humanMove() {
    var state = '';
    var action = Math.floor(Math.random() * 4);

    if (this.canHumanMove(action)) {
      if (action == 0 && this.humanNode.y <= 640 - 16 - 32) {
        // up
        state = 'human_up';
        this.sp.x = 0;
        this.sp.y = 32;
      } else if (action == 1 && this.humanNode.y >= 16 + 32) {
        // down
        state = 'human_down';
        this.sp.x = 0;
        this.sp.y = -32;
      } else if (action == 2 && this.humanNode.x >= 16 + 32) {
        // left
        state = 'human_left';
        this.sp.x = -32;
        this.sp.y = 0;
      } else if (action == 3 && this.humanNode.x <= 640 - 16 - 32) {
        // right
        state = 'human_right';
        this.sp.x = 32;
        this.sp.y = 0;
      }
    } else {
      this.sp.x = 0;
      this.sp.y = 0;
    }

    if (this.sp.x) {
      this.humanNode.x += this.sp.x;
    } else if (this.sp.y) {
      this.humanNode.y += this.sp.y;
    }

    if (state) {
      this.setState(state);
    }
  },
  progressBarUpdate: function progressBarUpdate() {
    this.progressBar.progress = this.gameData[7] / this.gameData[8];
    /*if (progress < 1) {
        progress += 0.005;
        this.progressBar.progress = progress;
    
    } else {
        this.progressBar.progress = 1;       
    }*/
  },
  readUserData: function readUserData() {
    console.log('game=' + com.gameOver); //console.log('firstTime ' + cc.sys.localStorage.getItem('globalMapKey') == null);//may never be true

    var value = wx.getStorageSync('globalMapKey');
    console.log('restart ' + com.restart);

    if (value.length == 0 || com.restart || com.gameOver) {
      console.log('new game');
      com.gameOver = false;
      com.restart = false;
    } else {
      //globalMapKey = cc.sys.localStorage.getItem('globalMapKey');
      //globalGameData = cc.sys.localStorage.getItem('globalGameData');
      try {
        var value = wx.getStorageSync('globalMapKey');

        if (value) {
          // Do something with return value
          globalMapKey = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get map key storage error');
      }

      try {
        var value = wx.getStorageSync('globalGameData');

        if (value) {
          // Do something with return value
          globalGameData = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get game data storage error');
      }

      try {
        var value = wx.getStorageSync('globalYear');

        if (value) {
          // Do something with return value
          globalYear = value;
        }
      } catch (e) {
        // Do something when catch error
        console.log('get year storage error');
      }

      console.log('globalMapKey');
      console.log(globalMapKey);
      console.log('globalGameData');
      console.log(globalGameData);
      console.log('globalYear');
      console.log(globalYear); // var keyArray = globalMapKey.split(",");
      // for (let i = 0; i < this.sizeY; i++) {
      //     for (let j = 0; j < this.sizeX; j++) {
      //         this.mapKey[i][j] = parseInt(keyArray[i * this.sizeX + j]);
      //     }
      // }

      this.mapKey = globalMapKey; // var splitArray = globalGameData.split(",");
      // for (let i = 0; i < this.gameData.length; i++) {
      //     if (i == 6 || i == 7 || i == 8 || i == 9 || i == 10) {
      //         for (j = 0; j < this.gameData[i].length; j++) {
      //             this.gameData[i][j] = parseFloat(splitArray[i + j]);
      //         }
      //     } else {
      //         this.gameData[i] = parseFloat(splitArray[i]);
      //     }
      // }

      this.gameData = globalGameData;
      this.time = globalYear;
    }
  },
  gameOverUpdate: function gameOverUpdate() {
    if (this.gameData[0] <= 0 && this.gameOverOrNot == false) {
      console.log('dead');
      this.gameOver.active = true;
      this.gameOverOrNot = true;
      this.saveUserData();
      this.gameOverTime = this.time;
      this.gameOverString.string = '游戏结束\n您的子民灭绝了\n' + '您的文明持续了\n' + this.gameOverTime + '年';
    }
  },
  saveUserData: function saveUserData() {
    com.gameOver = this.gameOverOrNot;
    globalMapKey = this.mapKey; //cc.sys.localStorage.setItem('globalMapKey', globalMapKey);

    try {
      wx.setStorageSync('globalMapKey', globalMapKey);
    } catch (e) {
      console.log('set map key storage error');
    }

    console.log('saveUserData globalMapKey:');
    console.log(globalMapKey);
    globalGameData = this.gameData; //cc.sys.localStorage.setItem('globalGameData', globalGameData);

    try {
      wx.setStorageSync('globalGameData', globalGameData);
    } catch (e) {
      console.log('set game data storage error');
    }

    console.log('saveUserData globalGameData');
    console.log(globalGameData);
    globalYear = this.time;

    try {
      wx.setStorageSync('globalYear', globalYear);
    } catch (e) {
      console.log('set year storage error');
    }
  },
  update: function update(dt) {
    if (this.gameOverOrNot) {
      return;
    }

    this.frame++;
    this.logframe++;

    if (this.frame % 60 == 0) {
      this.powerUpdate(this.gameData);
    }

    if (this.frame == 270) {
      this.gatherAI(this.gameData, this.mapKey);
    } else if (this.frame == 300) {
      if (this.checkNodeExist(this.mapKey, 2)) {
        this.buildHouse(this.gameData);
      }
    } else if (this.frame == 330) {
      this.populationUpdate(this.gameData);
      this.foodUpdate(this.gameData, this.mapKey);
      this.techUpdate(this.gameData);
    } else if (this.frame >= 360) {
      this.landupdate(this.gameData, this.nodeKey, this.mapKey);
      this.changeWeather(this.gameData);
      this.frame = 0;
      this.time++;
    }

    this.humanTimer++;

    if (this.humanTimer > 60) {
      this.humanMove();
      this.humanTimer = 0;
    }

    if (this.logframe % 2700 == 0) {
      this.log.string = '';
      this.logframe = 0;
    }

    this.LevelText.string = '等级: ' + this.gameData[11];
    this.populationText.string = '人口: ' + this.gameData[0];
    this.foodText.string = '食物: ' + Math.round(this.gameData[2]); //this.techText.string = '科技: ' + this.gameData[4].toFixed(3);

    this.techText.string = '科技: ' + Math.round(this.gameData[4] * 1000) / 1000; //this.weatherText.string = '天气: ' + this.gameData[5].toFixed(1);

    this.resourceText.string = '资源: ' + this.gameData[3];
    this.powerText.string = this.gameData[7] + '/' + this.gameData[8];
    this.progressBarUpdate();
    this.gameOverUpdate();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHQvYmFja2dyb3VuZC5qcyJdLCJuYW1lcyI6WyJnbG9iYWxNYXBLZXkiLCJnbG9iYWxHYW1lRGF0YSIsImdsb2JhbFllYXIiLCJjb20iLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJodW1hbk5vZGUiLCJOb2RlIiwiaHVtYW5UaW1lciIsImF1ZGlvQmdtIiwiQXVkaW9DbGlwIiwiYXVkaW9DbGljayIsIm1hcE5vZGUiLCJ3YXRlciIsIlByZWZhYiIsInNhbmQiLCJncmFzcyIsInRvd24iLCJjcm9wIiwid2hlYXQiLCJ2b2NhbiIsInN0b25lIiwidHJlZSIsImZydWl0IiwiYmVycnkiLCJjaGlja2VuIiwiZG9nIiwiY293Iiwic2hlZXAiLCJsaW9uIiwicG9pc29uIiwicG9wdWxhdGlvblRleHQiLCJMYWJlbCIsImZvb2RUZXh0IiwicmVzb3VyY2VUZXh0IiwidGVjaFRleHQiLCJMZXZlbFRleHQiLCJwb3dlclRleHQiLCJtYXBLZXkiLCJub2RlS2V5IiwicHJlZmFiS2V5IiwiZ2FtZURhdGEiLCJzaXplWCIsInNpemVZIiwidGltZSIsImZyYW1lIiwiYnV0dG9uMSIsIkJ1dHRvbiIsImJ1dHRvbjIiLCJidXR0b24zIiwiYnV0dG9uNCIsImJ1dHRvbjUiLCJidXR0b242IiwibG9nIiwiZ2FtZU92ZXJTdHJpbmciLCJnYW1lT3ZlciIsImdhbWVPdmVyT3JOb3QiLCJnYW1lT3ZlclRpbWUiLCJsb2dmcmFtZSIsInByb2dyZXNzQmFyIiwidHlwZSIsIlByb2dyZXNzQmFyIiwib25Mb2FkIiwiYXVkaW9FbmdpbmUiLCJwbGF5IiwiaW5pdEFycmF5Iiwid29ybGRHZW4iLCJyZWFkVXNlckRhdGEiLCJjb25zb2xlIiwibG9hZE1hcCIsImFjdGl2ZSIsInNwIiwidjIiLCJzdGF0ZSIsImh1bWFuQW5pIiwiZ2V0Q29tcG9uZW50IiwiQW5pbWF0aW9uIiwic2V0U3RhdGUiLCJhcnJheSIsInJvdyIsImNvbHVtZSIsImkiLCJqIiwiYXJyYXlNYXAiLCJsZW5ndGgiLCJpdGVtIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiYXJyYXlOb2RlIiwiaW5pdE5vZGUiLCJudW0iLCJ5IiwieCIsInNpemUiLCJpbnN0YW50aWF0ZSIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJuYW1lIiwiYWRkQ2hpbGQiLCJudW1PZkl0ZW0iLCJjaGVja05vZGVFeGlzdCIsImZpbmROb2RlIiwibnVtYmVyIiwiaWZGaW5kIiwiYXJyYXlUb1JldHVybiIsImNvdW50IiwiaW5Cb3VuZCIsInJlcGxhY2VOb2RlQnlDb29yZGluYXRlIiwibmV3TnVtIiwibm9kZVRvRGVzdG9yeSIsImdldENoaWxkQnlOYW1lIiwiZGVzdHJveSIsInJlcGxhY2VOb2RlQnlLaW5kIiwib3JpZ2VuTnVtIiwibGlzdE9mSXRlbSIsImluZGV4IiwicmVwbGFjZUFsbCIsInJlcGxhY2VBcnJheSIsInN1ckNoZWNrIiwibnVtVG9SZXBsYWNlIiwic3VyUmVwbGFjZVNpbmdsZU9mVHlwZSIsInJlcGxhY2VOdW0iLCJtb3ZlWCIsIm1vdmVZIiwibmV3WCIsIm5ld1kiLCJzdXJSZXBsYWNlU2luZ2xlIiwiY2xpY2tCYWNrSG9tZUJ1dHRvbiIsInNhdmVVc2VyRGF0YSIsInN0b3BBbGwiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImNsaWNrU2hhcmVCdXR0b24iLCJjYW52YXMiLCJ0b1RlbXBGaWxlUGF0aCIsImRlc3RXaWR0aCIsImRlc3RIZWlnaHQiLCJzdWNjZXNzIiwicmVzIiwid3giLCJzaGFyZUFwcE1lc3NhZ2UiLCJ0aXRsZSIsImltYWdlVXJsIiwidGVtcEZpbGVQYXRoIiwiZmFpbCIsImNsaWNrQnV0dG9uMSIsInN0cmluZyIsImFjdGlvbjEiLCJjbGlja0J1dHRvbjIiLCJhY3Rpb24yIiwiY2xpY2tCdXR0b24zIiwiYWN0aW9uMyIsImNsaWNrQnV0dG9uNCIsImFjdGlvbjQiLCJjbGlja0J1dHRvbjUiLCJhY3Rpb241IiwiY2xpY2tCdXR0b242IiwiYWN0aW9uNiIsImdlbkdyb3VuZCIsInBvdyIsInJhbmRvbU51bSIsImdlblN0b25lIiwibnVtYmVyc09mQWN0aW9uIiwiZ2VuVm9jYW5vIiwidm9jYW5vRXgiLCJkZXNlcnRpZmljYXRpb24iLCJlYXJ0aHF1YWtlIiwic3Rvcm0iLCJmb29kRG91YmxlIiwicmFpbiIsIndpbmQiLCJkcm91Z2h0IiwiZ2VuQmVycnkiLCJnZW5UcmVlIiwiZ2VuR3Jhc3MiLCJnZW5Qb2lzb24iLCJnZW5Dcm9wIiwiZ2VuRG9nIiwiZ2VuQ2hpY2tlbiIsImdlblNoZWVwIiwiZ2VuQ293IiwiZ2VuTGlvbiIsImdlblBlb3BsZSIsImFycmF5RGF0YSIsIm9yaUhvdXNlIiwiY2VpbCIsInJhbmROdW0iLCJ3b3JkIiwiaG91c2UiLCJwb3dlclVwZGF0ZSIsImdhdGhlckJlcnJ5IiwiZ2F0aGVyUG9pc29uIiwiZ2F0aGVyRnJ1aXQiLCJnYXRoZXJDcm9wIiwiZ2F0aGVyY291bnQiLCJudW1GcnVpdCIsIm51bUJlcnJ5IiwibnVtUG9pc29uIiwiZ2F0aGVyVHJlZSIsImdhdGhlckZydWl0VHJlZSIsImdhdGhlclN0b25lIiwiZ2F0aGVyUmVzb3VyY2UiLCJudW1UcmVlIiwibnVtRnJ1aXRUcmVlIiwibnVtU3RvbmUiLCJraWxsQ2hpY2tlbiIsImtpbGxEb2ciLCJkZWFkIiwia2lsbENvdyIsImtpbGxTaGVlcCIsImtpbGxMaW9uIiwiZ2F0aGVyTWVhdCIsIndvbGYiLCJ0YW1lQ2hpY2tlbiIsInRhbWVDb3ciLCJ0YW1lU2hlZXAiLCJnYXRoZXJUYW0iLCJpZlRhbWVkIiwiYnVpbGRIb3VzZSIsImZvb2RVcGRhdGUiLCJudW1PZlBsb3QiLCJncm93Q3JvcCIsImdyb3dGcnVpdCIsInJlc291cmNlRGVzdG9yeSIsIml0ZW1MaXN0IiwibGFuZHVwZGF0ZSIsInRlY2hVcGRhdGUiLCJyb3VuZCIsInBvcHVsYXRpb25VcGRhdGUiLCJjaGFuZ2VXZWF0aGVyIiwieWVhckNoZWNrIiwiZ2F0aGVyRm9vZCIsImdhdGhlckFJIiwiZm9vZCIsInJlbWFpbiIsImNhbkh1bWFuTW92ZSIsImFjdGlvbk51bSIsImN1cnJYIiwiY3VyclkiLCJodW1hbk1vdmUiLCJhY3Rpb24iLCJwcm9ncmVzc0JhclVwZGF0ZSIsInByb2dyZXNzIiwidmFsdWUiLCJnZXRTdG9yYWdlU3luYyIsInJlc3RhcnQiLCJlIiwiZ2FtZU92ZXJVcGRhdGUiLCJzZXRTdG9yYWdlU3luYyIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFDLElBQUlBLFlBQVksR0FBRyxFQUFuQjtBQUNELElBQUlDLGNBQWMsR0FBRyxFQUFyQjtBQUNBLElBQUlDLFVBQVUsR0FBRyxDQUFqQjs7QUFFQSxJQUFJQyxHQUFHLEdBQUdDLE9BQU8sQ0FBQyxNQUFELENBQWpCOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsU0FBUyxFQUFFSixFQUFFLENBQUNLLElBRE47QUFFUkMsSUFBQUEsVUFBVSxFQUFFLENBRko7QUFHUkMsSUFBQUEsUUFBUSxFQUFFUCxFQUFFLENBQUNRLFNBSEw7QUFJUkMsSUFBQUEsVUFBVSxFQUFFVCxFQUFFLENBQUNRLFNBSlA7QUFLUkUsSUFBQUEsT0FBTyxFQUFFVixFQUFFLENBQUNLLElBTEo7QUFNUk0sSUFBQUEsS0FBSyxFQUFFWCxFQUFFLENBQUNZLE1BTkY7QUFNVTtBQUNsQkMsSUFBQUEsSUFBSSxFQUFFYixFQUFFLENBQUNZLE1BUEQ7QUFPUztBQUNqQkUsSUFBQUEsS0FBSyxFQUFFZCxFQUFFLENBQUNZLE1BUkY7QUFRVTtBQUNsQkcsSUFBQUEsSUFBSSxFQUFFZixFQUFFLENBQUNZLE1BVEQ7QUFTUztBQUNqQkksSUFBQUEsSUFBSSxFQUFFaEIsRUFBRSxDQUFDWSxNQVZEO0FBVVM7QUFDakJLLElBQUFBLEtBQUssRUFBRWpCLEVBQUUsQ0FBQ1ksTUFYRjtBQVdVO0FBQ2xCTSxJQUFBQSxLQUFLLEVBQUVsQixFQUFFLENBQUNZLE1BWkY7QUFZVTtBQUNsQk8sSUFBQUEsS0FBSyxFQUFFbkIsRUFBRSxDQUFDWSxNQWJGO0FBYVU7QUFDbEJRLElBQUFBLElBQUksRUFBRXBCLEVBQUUsQ0FBQ1ksTUFkRDtBQWNTO0FBQ2pCUyxJQUFBQSxLQUFLLEVBQUVyQixFQUFFLENBQUNZLE1BZkY7QUFlVTtBQUNsQlUsSUFBQUEsS0FBSyxFQUFFdEIsRUFBRSxDQUFDWSxNQWhCRjtBQWdCVTtBQUNsQlcsSUFBQUEsT0FBTyxFQUFFdkIsRUFBRSxDQUFDWSxNQWpCSjtBQWlCWTtBQUNwQlksSUFBQUEsR0FBRyxFQUFFeEIsRUFBRSxDQUFDWSxNQWxCQTtBQWtCUTtBQUNoQmEsSUFBQUEsR0FBRyxFQUFFekIsRUFBRSxDQUFDWSxNQW5CQTtBQW1CUTtBQUNoQmMsSUFBQUEsS0FBSyxFQUFFMUIsRUFBRSxDQUFDWSxNQXBCRjtBQW9CVTtBQUNsQmUsSUFBQUEsSUFBSSxFQUFFM0IsRUFBRSxDQUFDWSxNQXJCRDtBQXFCUztBQUNqQmdCLElBQUFBLE1BQU0sRUFBRTVCLEVBQUUsQ0FBQ1ksTUF0Qkg7QUFzQlc7QUFDbkJpQixJQUFBQSxjQUFjLEVBQUU3QixFQUFFLENBQUM4QixLQXZCWDtBQXdCUkMsSUFBQUEsUUFBUSxFQUFFL0IsRUFBRSxDQUFDOEIsS0F4Qkw7QUF5QlJFLElBQUFBLFlBQVksRUFBRWhDLEVBQUUsQ0FBQzhCLEtBekJUO0FBMEJSRyxJQUFBQSxRQUFRLEVBQUVqQyxFQUFFLENBQUM4QixLQTFCTDtBQTJCUkksSUFBQUEsU0FBUyxFQUFFbEMsRUFBRSxDQUFDOEIsS0EzQk47QUE0QlJLLElBQUFBLFNBQVMsRUFBRW5DLEVBQUUsQ0FBQzhCLEtBNUJOO0FBNkJSTSxJQUFBQSxNQUFNLEVBQUUsRUE3QkE7QUE4QlJDLElBQUFBLE9BQU8sRUFBRSxFQTlCRDtBQStCUkMsSUFBQUEsU0FBUyxFQUFFLEVBL0JIO0FBZ0NSQyxJQUFBQSxRQUFRLEVBQUUsRUFoQ0Y7QUFpQ1JDLElBQUFBLEtBQUssRUFBRSxFQWpDQztBQWtDUkMsSUFBQUEsS0FBSyxFQUFFLEVBbENDO0FBbUNSQyxJQUFBQSxJQUFJLEVBQUUsQ0FuQ0U7QUFtQ0M7QUFDVEMsSUFBQUEsS0FBSyxFQUFFLENBcENDO0FBcUNSQyxJQUFBQSxPQUFPLEVBQUU1QyxFQUFFLENBQUM2QyxNQXJDSjtBQXNDUkMsSUFBQUEsT0FBTyxFQUFFOUMsRUFBRSxDQUFDNkMsTUF0Q0o7QUF1Q1JFLElBQUFBLE9BQU8sRUFBRS9DLEVBQUUsQ0FBQzZDLE1BdkNKO0FBd0NSRyxJQUFBQSxPQUFPLEVBQUVoRCxFQUFFLENBQUM2QyxNQXhDSjtBQXlDUkksSUFBQUEsT0FBTyxFQUFFakQsRUFBRSxDQUFDNkMsTUF6Q0o7QUEwQ1JLLElBQUFBLE9BQU8sRUFBRWxELEVBQUUsQ0FBQzZDLE1BMUNKO0FBMkNSTSxJQUFBQSxHQUFHLEVBQUVuRCxFQUFFLENBQUM4QixLQTNDQTtBQTRDUnNCLElBQUFBLGNBQWMsRUFBRXBELEVBQUUsQ0FBQzhCLEtBNUNYO0FBNkNSdUIsSUFBQUEsUUFBUSxFQUFDckQsRUFBRSxDQUFDSyxJQTdDSjtBQThDUmlELElBQUFBLGFBQWEsRUFBRSxLQTlDUDtBQStDUkMsSUFBQUEsWUFBWSxFQUFFLENBL0NOO0FBZ0RSQyxJQUFBQSxRQUFRLEVBQUUsQ0FoREY7QUFpRFJDLElBQUFBLFdBQVcsRUFBRTtBQUNULGlCQUFTLElBREE7QUFFVEMsTUFBQUEsSUFBSSxFQUFFMUQsRUFBRSxDQUFDMkQ7QUFGQTtBQWpETCxHQUhQO0FBMERMQyxFQUFBQSxNQTFESyxvQkEwREk7QUFDTDVELElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLdkQsUUFBekIsRUFBbUMsSUFBbkMsRUFBeUMsQ0FBekM7QUFDQSxTQUFLK0IsU0FBTCxHQUFpQixDQUFDLEtBQUszQixLQUFOLEVBQWEsS0FBS0UsSUFBbEIsRUFBd0IsS0FBS0MsS0FBN0IsRUFBb0MsS0FBS0MsSUFBekMsRUFBK0MsS0FBS0MsSUFBcEQsRUFBMEQsS0FBS0MsS0FBL0QsRUFBc0UsS0FBS0MsS0FBM0UsRUFBa0YsS0FBS0MsS0FBdkYsRUFBOEYsS0FBS0MsSUFBbkcsRUFBeUcsS0FBS0MsS0FBOUcsRUFBcUgsS0FBS0MsS0FBMUgsRUFBaUksS0FBS0MsT0FBdEksRUFBK0ksS0FBS0MsR0FBcEosRUFBeUosS0FBS0MsR0FBOUosRUFBbUssS0FBS0MsS0FBeEssRUFBK0ssS0FBS0MsSUFBcEwsRUFBMEwsS0FBS0MsTUFBL0wsQ0FBakIsQ0FGSyxDQUdMOztBQUNBLFNBQUtXLFFBQUwsR0FBZ0IsQ0FBQyxFQUFELEVBQUssQ0FBTCxFQUFRLEdBQVIsRUFBYSxDQUFiLEVBQWdCLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsQ0FBdEIsRUFBdUMsR0FBdkMsRUFBNEMsR0FBNUMsRUFBaUQsQ0FBakQsRUFBb0QsR0FBcEQsRUFBeUQsQ0FBekQsQ0FBaEIsQ0FKSyxDQUtMO0FBQ0E7O0FBQ0EsU0FBS3dCLFNBQUwsQ0FBZSxLQUFLM0IsTUFBcEIsRUFBNEIsS0FBS0ksS0FBakMsRUFBd0MsS0FBS0MsS0FBN0M7QUFDQSxTQUFLc0IsU0FBTCxDQUFlLEtBQUsxQixPQUFwQixFQUE2QixLQUFLRyxLQUFsQyxFQUF5QyxLQUFLQyxLQUE5QztBQUNBLFNBQUt1QixRQUFMLENBQWMsS0FBSzVCLE1BQW5CLEVBVEssQ0FVTDtBQUNBOztBQUNBLFNBQUs2QixZQUFMO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGVBQWUsS0FBS0csYUFBaEMsRUFiSyxDQWNMO0FBQ0E7O0FBQ0EsU0FBS2EsT0FBTCxDQUFhLEtBQUs5QixPQUFsQixFQUEyQixLQUFLRCxNQUFoQztBQUNBLFNBQUtpQixRQUFMLENBQWNlLE1BQWQsR0FBdUIsS0FBdkI7QUFDQSxTQUFLQyxFQUFMLEdBQVVyRSxFQUFFLENBQUNzRSxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBVjtBQUNBLFNBQUtDLEtBQUwsR0FBYSxFQUFiO0FBQ0EsU0FBS0MsUUFBTCxHQUFnQixLQUFLcEUsU0FBTCxDQUFlcUUsWUFBZixDQUE0QnpFLEVBQUUsQ0FBQzBFLFNBQS9CLENBQWhCO0FBQ0gsR0EvRUk7QUFpRkw7QUFDQUMsRUFBQUEsUUFsRkssb0JBa0ZJSixLQWxGSixFQWtGVztBQUNaLFFBQUksS0FBS0EsS0FBTCxJQUFjQSxLQUFsQixFQUF5QjtBQUNyQixXQUFLQSxLQUFMLEdBQWFBLEtBQWI7QUFDSDs7QUFDRCxTQUFLQyxRQUFMLENBQWNWLElBQWQsQ0FBbUIsS0FBS1MsS0FBeEI7QUFDSCxHQXZGSTtBQXlGTDtBQUNBUixFQUFBQSxTQUFTLEVBQUUsbUJBQVVhLEtBQVYsRUFBaUJDLEdBQWpCLEVBQXNCQyxNQUF0QixFQUE4QjtBQUNyQyxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdGLEdBQXBCLEVBQXlCRSxDQUFDLEVBQTFCLEVBQThCO0FBQzFCSCxNQUFBQSxLQUFLLENBQUNHLENBQUQsQ0FBTCxHQUFXLEVBQVg7O0FBQ0EsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRixNQUFwQixFQUE0QkUsQ0FBQyxFQUE3QixFQUFpQztBQUM3QkosUUFBQUEsS0FBSyxDQUFDRyxDQUFELENBQUwsQ0FBU0MsQ0FBVCxJQUFjLElBQWQ7QUFDSDtBQUNKO0FBQ0osR0FqR0k7QUFtR0w7QUFDQWhCLEVBQUFBLFFBQVEsRUFBRSxrQkFBVWlCLFFBQVYsRUFBb0I7QUFDMUI7QUFDQSxTQUFLLElBQUlGLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdFLFFBQVEsQ0FBQ0MsTUFBN0IsRUFBcUNILENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHQyxRQUFRLENBQUNGLENBQUQsQ0FBUixDQUFZRyxNQUFoQyxFQUF3Q0YsQ0FBQyxFQUF6QyxFQUE2QztBQUN6QyxZQUFJRyxJQUFJLEdBQUcsQ0FBWDtBQUNBRixRQUFBQSxRQUFRLENBQUNGLENBQUQsQ0FBUixDQUFZQyxDQUFaLElBQWlCRyxJQUFqQjtBQUNIO0FBQ0osS0FQeUIsQ0FRMUI7OztBQUNBLFNBQUssSUFBSUosRUFBQyxHQUFHRSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsQ0FBbEIsR0FBdUJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBdkIsR0FBd0QsQ0FBckUsRUFBd0VQLEVBQUMsR0FBR0UsUUFBUSxDQUFDQyxNQUFULEdBQWtCLENBQWxCLEdBQXVCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQXZCLEdBQXdELENBQXBJLEVBQXVJUCxFQUFDLEVBQXhJLEVBQTRJO0FBQ3hJLFdBQUssSUFBSUMsRUFBQyxHQUFHQyxRQUFRLENBQUNGLEVBQUQsQ0FBUixDQUFZRyxNQUFaLEdBQXFCLENBQXJCLEdBQTBCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQTFCLEdBQTJELENBQXhFLEVBQTJFTixFQUFDLEdBQUdDLFFBQVEsQ0FBQ0YsRUFBRCxDQUFSLENBQVlHLE1BQVosR0FBcUIsQ0FBckIsR0FBMEJFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBMUIsR0FBMkQsQ0FBMUksRUFBNklOLEVBQUMsRUFBOUksRUFBa0o7QUFDOUlDLFFBQUFBLFFBQVEsQ0FBQ0YsRUFBRCxDQUFSLENBQVlDLEVBQVosSUFBaUIsQ0FBakI7QUFDSDtBQUNKLEtBYnlCLENBYzFCOzs7QUFDQSxTQUFLLElBQUlELEdBQUMsR0FBR0UsUUFBUSxDQUFDQyxNQUFULEdBQWtCLENBQWxCLEdBQXVCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQXZCLEdBQXdELENBQXJFLEVBQXdFUCxHQUFDLEdBQUdFLFFBQVEsQ0FBQ0MsTUFBVCxHQUFrQixDQUFsQixHQUF1QkUsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUF2QixHQUF3RCxDQUFwSSxFQUF1SVAsR0FBQyxFQUF4SSxFQUE0STtBQUN4SSxXQUFLLElBQUlDLEdBQUMsR0FBR0MsUUFBUSxDQUFDRixHQUFELENBQVIsQ0FBWUcsTUFBWixHQUFxQixDQUFyQixHQUEwQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUExQixHQUEyRCxDQUF4RSxFQUEyRU4sR0FBQyxHQUFHQyxRQUFRLENBQUNGLEdBQUQsQ0FBUixDQUFZRyxNQUFaLEdBQXFCLENBQXJCLEdBQTBCRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQTFCLEdBQTJELENBQTFJLEVBQTZJTixHQUFDLEVBQTlJLEVBQWtKO0FBQzlJQyxRQUFBQSxRQUFRLENBQUNGLEdBQUQsQ0FBUixDQUFZQyxHQUFaLElBQWlCLENBQWpCO0FBQ0g7QUFDSjs7QUFDREMsSUFBQUEsUUFBUSxDQUFDQSxRQUFRLENBQUNDLE1BQVQsR0FBa0IsQ0FBbkIsQ0FBUixDQUE4QkQsUUFBUSxDQUFDLENBQUQsQ0FBUixDQUFZQyxNQUFaLEdBQXFCLENBQW5ELElBQXdELENBQXhEO0FBQ0gsR0F6SEk7QUEySEw7QUFDQWYsRUFBQUEsT0FBTyxFQUFFLGlCQUFVb0IsU0FBVixFQUFxQk4sUUFBckIsRUFBK0I7QUFDcEMsU0FBSyxJQUFJRixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRSxRQUFRLENBQUNDLE1BQTdCLEVBQXFDSCxDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLFdBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0MsUUFBUSxDQUFDRixDQUFELENBQVIsQ0FBWUcsTUFBaEMsRUFBd0NGLENBQUMsRUFBekMsRUFBNkM7QUFDekNPLFFBQUFBLFNBQVMsQ0FBQ1IsQ0FBRCxDQUFULENBQWFDLENBQWIsSUFBa0IsS0FBS1EsUUFBTCxDQUFjUCxRQUFRLENBQUNGLENBQUQsQ0FBUixDQUFZQyxDQUFaLENBQWQsRUFBOEJELENBQTlCLEVBQWlDQyxDQUFqQyxFQUFvQyxFQUFwQyxDQUFsQjtBQUNIO0FBQ0o7QUFDSixHQWxJSTtBQW9JTDtBQUNBUSxFQUFBQSxRQUFRLEVBQUUsa0JBQVVDLEdBQVYsRUFBZUMsQ0FBZixFQUFrQkMsQ0FBbEIsRUFBcUJDLElBQXJCLEVBQTJCO0FBQ2pDLFFBQUlULElBQUksR0FBRyxJQUFYO0FBQ0FBLElBQUFBLElBQUksR0FBR25GLEVBQUUsQ0FBQzZGLFdBQUgsQ0FBZSxLQUFLdkQsU0FBTCxDQUFlbUQsR0FBZixDQUFmLENBQVA7QUFDQSxRQUFJSyxRQUFRLEdBQUc5RixFQUFFLENBQUNzRSxFQUFILENBQU1xQixDQUFDLEdBQUdDLElBQUosR0FBV0EsSUFBSSxHQUFHLENBQXhCLEVBQTJCRixDQUFDLEdBQUdFLElBQUosR0FBV0EsSUFBSSxHQUFHLENBQTdDLENBQWY7QUFDQVQsSUFBQUEsSUFBSSxDQUFDWSxXQUFMLENBQWlCRCxRQUFqQjtBQUNBWCxJQUFBQSxJQUFJLENBQUNhLElBQUwsR0FBWU4sQ0FBQyxHQUFHLElBQUosR0FBV0MsQ0FBdkI7QUFDQSxTQUFLakYsT0FBTCxDQUFhdUYsUUFBYixDQUFzQmQsSUFBdEI7QUFDQSxXQUFPQSxJQUFQO0FBQ0gsR0E3SUk7QUErSUw7QUFDQWUsRUFBQUEsU0FBUyxFQUFFLG1CQUFVdEIsS0FBVixFQUFpQmEsR0FBakIsRUFBc0I7QUFDN0IsUUFBSSxLQUFLVSxjQUFMLENBQW9CdkIsS0FBcEIsRUFBMkJhLEdBQTNCLENBQUosRUFBcUM7QUFDakMsYUFBTyxLQUFLVyxRQUFMLENBQWN4QixLQUFkLEVBQXFCYSxHQUFyQixFQUEwQlAsTUFBakM7QUFDSDs7QUFDRCxXQUFPLENBQVA7QUFDSCxHQXJKSTtBQXVKTDtBQUNBaUIsRUFBQUEsY0FBYyxFQUFFLHdCQUFVdkIsS0FBVixFQUFpQnlCLE1BQWpCLEVBQXlCO0FBQ3JDLFFBQUlDLE1BQU0sR0FBRyxLQUFiOztBQUNBLFNBQUssSUFBSXZCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdILEtBQUssQ0FBQ00sTUFBMUIsRUFBa0NILENBQUMsRUFBbkMsRUFBdUM7QUFDbkMsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSixLQUFLLENBQUNHLENBQUQsQ0FBTCxDQUFTRyxNQUE3QixFQUFxQ0YsQ0FBQyxFQUF0QyxFQUEwQztBQUN0QyxZQUFJSixLQUFLLENBQUNHLENBQUQsQ0FBTCxDQUFTQyxDQUFULEtBQWVxQixNQUFuQixFQUEyQjtBQUN2QkMsVUFBQUEsTUFBTSxHQUFHLElBQVQ7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsV0FBT0EsTUFBUDtBQUNILEdBbEtJO0FBb0tMO0FBQ0FGLEVBQUFBLFFBQVEsRUFBRSxrQkFBVXhCLEtBQVYsRUFBaUJ5QixNQUFqQixFQUF5QjtBQUMvQixRQUFJLEtBQUtGLGNBQUwsQ0FBb0J2QixLQUFwQixFQUEyQnlCLE1BQTNCLENBQUosRUFBd0M7QUFDcEMsVUFBSUUsYUFBYSxHQUFHLEVBQXBCO0FBQ0EsVUFBSUMsS0FBSyxHQUFHLENBQVo7O0FBQ0EsV0FBSyxJQUFJekIsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsS0FBSyxDQUFDTSxNQUExQixFQUFrQ0gsQ0FBQyxFQUFuQyxFQUF1QztBQUNuQyxhQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLENBQVNHLE1BQTdCLEVBQXFDRixDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLGNBQUlKLEtBQUssQ0FBQ0csQ0FBRCxDQUFMLENBQVNDLENBQVQsS0FBZXFCLE1BQW5CLEVBQTJCO0FBQ3ZCRSxZQUFBQSxhQUFhLENBQUNDLEtBQUQsQ0FBYixHQUF1QixDQUFDekIsQ0FBRCxFQUFJQyxDQUFKLENBQXZCO0FBQ0F3QixZQUFBQSxLQUFLO0FBQ1I7QUFDSjtBQUNKOztBQUNELGFBQU9ELGFBQVA7QUFDSDtBQUNKLEdBbkxJO0FBcUxMO0FBQ0FFLEVBQUFBLE9BQU8sRUFBRSxpQkFBVWYsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ3JCLFFBQUlELENBQUMsR0FBRyxDQUFKLElBQVNBLENBQUMsSUFBSSxLQUFLakQsS0FBbkIsSUFBNEJrRCxDQUFDLEdBQUcsQ0FBaEMsSUFBcUNBLENBQUMsSUFBSSxLQUFLbkQsS0FBbkQsRUFBMEQ7QUFDdEQsYUFBTyxLQUFQO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsYUFBTyxJQUFQO0FBQ0g7QUFDSixHQTVMSTtBQThMTDtBQUNBa0UsRUFBQUEsdUJBQXVCLEVBQUUsaUNBQVVuQixTQUFWLEVBQXFCTixRQUFyQixFQUErQlMsQ0FBL0IsRUFBa0NDLENBQWxDLEVBQXFDZ0IsTUFBckMsRUFBNkM7QUFDbEUsUUFBSUMsYUFBYSxHQUFHLEtBQUtsRyxPQUFMLENBQWFtRyxjQUFiLENBQTRCbkIsQ0FBQyxHQUFHLElBQUosR0FBV0MsQ0FBdkMsQ0FBcEI7QUFDQWlCLElBQUFBLGFBQWEsQ0FBQ0UsT0FBZDtBQUNBdkIsSUFBQUEsU0FBUyxDQUFDRyxDQUFELENBQVQsQ0FBYUMsQ0FBYixJQUFrQixLQUFLSCxRQUFMLENBQWNtQixNQUFkLEVBQXNCakIsQ0FBdEIsRUFBeUJDLENBQXpCLEVBQTRCLEVBQTVCLENBQWxCO0FBQ0FWLElBQUFBLFFBQVEsQ0FBQ1MsQ0FBRCxDQUFSLENBQVlDLENBQVosSUFBaUJnQixNQUFqQjtBQUNILEdBcE1JO0FBc01MO0FBQ0FJLEVBQUFBLGlCQUFpQixFQUFFLDJCQUFVeEIsU0FBVixFQUFxQk4sUUFBckIsRUFBK0IrQixTQUEvQixFQUEwQ0wsTUFBMUMsRUFBa0Q7QUFDakUsUUFBSSxLQUFLUixjQUFMLENBQW9CbEIsUUFBcEIsRUFBOEIrQixTQUE5QixDQUFKLEVBQThDO0FBQzFDLFVBQUlDLFVBQVUsR0FBRyxLQUFLYixRQUFMLENBQWNuQixRQUFkLEVBQXdCK0IsU0FBeEIsQ0FBakI7QUFDQSxVQUFJRSxLQUFLLEdBQUk5QixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkIsVUFBVSxDQUFDL0IsTUFBdEMsQ0FBYjtBQUNBLFdBQUt3Qix1QkFBTCxDQUE2Qm5CLFNBQTdCLEVBQXdDTixRQUF4QyxFQUFrRGdDLFVBQVUsQ0FBQ0MsS0FBRCxDQUFWLENBQWtCLENBQWxCLENBQWxELEVBQXdFRCxVQUFVLENBQUNDLEtBQUQsQ0FBVixDQUFrQixDQUFsQixDQUF4RSxFQUE4RlAsTUFBOUY7QUFDQSxhQUFPLENBQUNNLFVBQVUsQ0FBQ0MsS0FBRCxDQUFWLENBQWtCLENBQWxCLENBQUQsRUFBdUJELFVBQVUsQ0FBQ0MsS0FBRCxDQUFWLENBQWtCLENBQWxCLENBQXZCLENBQVA7QUFDSDtBQUNKLEdBOU1JO0FBZ05MO0FBQ0FDLEVBQUFBLFVBQVUsRUFBRSxvQkFBVTVCLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCK0IsU0FBL0IsRUFBMENMLE1BQTFDLEVBQWtEO0FBQzFELFFBQUksS0FBS1IsY0FBTCxDQUFvQmxCLFFBQXBCLEVBQThCK0IsU0FBOUIsQ0FBSixFQUE4QztBQUMxQyxVQUFJSSxZQUFZLEdBQUcsS0FBS2hCLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IrQixTQUF4QixDQUFuQjs7QUFDQSxXQUFLLElBQUlqQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHcUMsWUFBWSxDQUFDbEMsTUFBakMsRUFBeUNILENBQUMsRUFBMUMsRUFBOEM7QUFDMUMsYUFBSzJCLHVCQUFMLENBQTZCbkIsU0FBN0IsRUFBd0NOLFFBQXhDLEVBQWtEbUMsWUFBWSxDQUFDckMsQ0FBRCxDQUFaLENBQWdCLENBQWhCLENBQWxELEVBQXNFcUMsWUFBWSxDQUFDckMsQ0FBRCxDQUFaLENBQWdCLENBQWhCLENBQXRFLEVBQTBGNEIsTUFBMUY7QUFDSDtBQUNKO0FBQ0osR0F4Tkk7QUEwTkw7QUFDQVUsRUFBQUEsUUFBUSxFQUFFLGtCQUFVekMsS0FBVixFQUFpQmMsQ0FBakIsRUFBb0JDLENBQXBCLEVBQXVCMkIsWUFBdkIsRUFBcUM7QUFDM0MsU0FBSyxJQUFJdkMsQ0FBQyxHQUFHLENBQUMsQ0FBZCxFQUFpQkEsQ0FBQyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO0FBQ3pCLFdBQUssSUFBSUMsQ0FBQyxHQUFHLENBQUMsQ0FBZCxFQUFpQkEsQ0FBQyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQTZCO0FBQ3pCLFlBQUksS0FBS3lCLE9BQUwsQ0FBYWYsQ0FBQyxHQUFHWCxDQUFqQixFQUFvQlksQ0FBQyxHQUFHWCxDQUF4QixDQUFKLEVBQWdDO0FBQzVCLGNBQUlKLEtBQUssQ0FBQ2MsQ0FBQyxHQUFHWCxDQUFMLENBQUwsQ0FBYVksQ0FBQyxHQUFHWCxDQUFqQixLQUF1QnNDLFlBQTNCLEVBQXlDO0FBQ3JDLG1CQUFPLElBQVA7QUFDSDtBQUNKO0FBQ0o7QUFDSjs7QUFDRCxXQUFPLEtBQVA7QUFDSCxHQXRPSTtBQXdPTDtBQUNBQyxFQUFBQSxzQkFBc0IsRUFBRSxnQ0FBVWhDLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCUyxDQUEvQixFQUFrQ0MsQ0FBbEMsRUFBcUNxQixTQUFyQyxFQUFnRFEsVUFBaEQsRUFBNEQ7QUFDaEY7QUFDQSxRQUFJQyxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQTVDO0FBQ0EsUUFBSW9DLEtBQUssR0FBR3RDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBNUM7QUFDQSxRQUFJcUMsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBZjtBQUNBLFFBQUlHLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQWY7O0FBQ0EsUUFBSSxLQUFLTCxRQUFMLENBQWMsS0FBS2pGLE1BQW5CLEVBQTJCc0QsQ0FBM0IsRUFBOEJDLENBQTlCLEVBQWlDcUIsU0FBakMsQ0FBSixFQUFpRDtBQUM3QztBQUNBLGFBQU8vQixRQUFRLENBQUMyQyxJQUFELENBQVIsQ0FBZUQsSUFBZixLQUF3QlgsU0FBeEIsSUFBcUMsQ0FBQyxLQUFLUCxPQUFMLENBQWFtQixJQUFiLEVBQW1CRCxJQUFuQixDQUE3QyxFQUF1RTtBQUNuRUYsUUFBQUEsS0FBSyxHQUFHckMsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF4QztBQUNBb0MsUUFBQUEsS0FBSyxHQUFHdEMsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF4QztBQUNBcUMsUUFBQUEsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBWDtBQUNBRyxRQUFBQSxJQUFJLEdBQUdsQyxDQUFDLEdBQUdnQyxLQUFYO0FBQ0g7O0FBQ0QsV0FBS2hCLHVCQUFMLENBQTZCbkIsU0FBN0IsRUFBd0NOLFFBQXhDLEVBQWtEMkMsSUFBbEQsRUFBd0RELElBQXhELEVBQThESCxVQUE5RDtBQUNIO0FBQ0osR0F6UEk7QUEyUEw7QUFDQUssRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVV0QyxTQUFWLEVBQXFCTixRQUFyQixFQUErQlMsQ0FBL0IsRUFBa0NDLENBQWxDLEVBQXFDNkIsVUFBckMsRUFBaUQ7QUFDL0Q7QUFDQSxRQUFJQyxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQTVDO0FBQ0EsUUFBSW9DLEtBQUssR0FBR3RDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBNUM7QUFDQSxRQUFJcUMsSUFBSSxHQUFHaEMsQ0FBQyxHQUFHOEIsS0FBZjtBQUNBLFFBQUlHLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQWY7O0FBQ0EsV0FBUUQsS0FBSyxJQUFJLENBQVQsSUFBY0MsS0FBSyxJQUFJLENBQXhCLElBQThCLENBQUMsS0FBS2pCLE9BQUwsQ0FBYW1CLElBQWIsRUFBbUJELElBQW5CLENBQXRDLEVBQWdFO0FBQzVERixNQUFBQSxLQUFLLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXhDO0FBQ0FvQyxNQUFBQSxLQUFLLEdBQUd0QyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXhDO0FBQ0FxQyxNQUFBQSxJQUFJLEdBQUdoQyxDQUFDLEdBQUc4QixLQUFYO0FBQ0FHLE1BQUFBLElBQUksR0FBR2xDLENBQUMsR0FBR2dDLEtBQVg7QUFDSDs7QUFDRCxTQUFLaEIsdUJBQUwsQ0FBNkJuQixTQUE3QixFQUF3Q04sUUFBeEMsRUFBa0QyQyxJQUFsRCxFQUF3REQsSUFBeEQsRUFBOERILFVBQTlEO0FBQ0gsR0F6UUk7QUEyUUxNLEVBQUFBLG1CQUFtQixFQUFFLCtCQUFZO0FBQzdCNUQsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVkscUJBQVo7QUFDQSxTQUFLNEUsWUFBTDtBQUNBL0gsSUFBQUEsRUFBRSxDQUFDNkQsV0FBSCxDQUFlbUUsT0FBZjtBQUNBaEksSUFBQUEsRUFBRSxDQUFDaUksUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBRUgsR0FqUkk7QUFtUkxDLEVBQUFBLGdCQUFnQixFQUFFLDRCQUFZO0FBQzFCQyxJQUFBQSxNQUFNLENBQUNDLGNBQVAsQ0FBc0I7QUFDbEJDLE1BQUFBLFNBQVMsRUFBRSxHQURPO0FBRWxCQyxNQUFBQSxVQUFVLEVBQUUsR0FGTTtBQUdsQkMsTUFBQUEsT0FIa0IsbUJBR1RDLEdBSFMsRUFHSjtBQUNWdkUsUUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksYUFBWixFQUEwQnNGLEdBQTFCO0FBQ0FDLFFBQUFBLEVBQUUsQ0FBQ0MsZUFBSCxDQUFtQjtBQUNmQyxVQUFBQSxLQUFLLEVBQUUsV0FEUTtBQUVmQyxVQUFBQSxRQUFRLEVBQUVKLEdBQUcsQ0FBQ0ssWUFGQztBQUdmTixVQUFBQSxPQUhlLG1CQUdQQyxHQUhPLEVBR0gsQ0FBRSxDQUhDO0FBSWZNLFVBQUFBLElBSmUsa0JBSVQsQ0FBRTtBQUpPLFNBQW5CO0FBTUg7QUFYaUIsS0FBdEI7QUFhSCxHQWpTSTtBQW9TTDtBQUVBO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QmhKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsS0FBS0EsUUFBTCxDQUFjLENBQWQsQ0FBdkIsRUFBeUM7QUFDckMsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsSUFBbUIsQ0FBbkI7QUFDQSxTQUFLMkcsT0FBTDtBQUVILEdBaFRJO0FBa1RMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0Qm5KLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsRUFBdkIsRUFBMkI7QUFDdkIsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsS0FBa0IsRUFBbEI7QUFDQSxTQUFLNkcsT0FBTDtBQUVILEdBNVRJO0FBOFRMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QnJKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsRUFBdkIsRUFBMkI7QUFDdkIsV0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixpQkFBaUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTVDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLMUcsUUFBTCxDQUFjLENBQWQsS0FBa0IsRUFBbEI7QUFDQSxTQUFLK0csT0FBTDtBQUVILEdBeFVJO0FBMFVMO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QnZKLElBQUFBLEVBQUUsQ0FBQzZELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckQsVUFBekIsRUFBcUMsS0FBckMsRUFBNEMsQ0FBNUM7O0FBQ0EsUUFBSSxLQUFLOEIsUUFBTCxDQUFjLENBQWQsSUFBbUIsS0FBSyxLQUFLQSxRQUFMLENBQWMsRUFBZCxDQUE1QixFQUErQztBQUMzQyxXQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGlCQUFpQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBNUM7QUFDQTtBQUNIOztBQUNELFNBQUsxRyxRQUFMLENBQWMsQ0FBZCxLQUFrQixLQUFLLEtBQUtBLFFBQUwsQ0FBYyxFQUFkLENBQXZCO0FBQ0EsU0FBS2lILE9BQUw7QUFFSCxHQXBWSTtBQXNWTDtBQUNBQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEJ6SixJQUFBQSxFQUFFLENBQUM2RCxXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS3JELFVBQXpCLEVBQXFDLEtBQXJDLEVBQTRDLENBQTVDOztBQUNBLFFBQUksS0FBSzhCLFFBQUwsQ0FBYyxDQUFkLElBQW1CLEVBQXZCLEVBQTJCO0FBQ3ZCLFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsaUJBQWlCLEtBQUs5RixHQUFMLENBQVM4RixNQUE1QztBQUNBO0FBQ0g7O0FBQ0QsU0FBSzFHLFFBQUwsQ0FBYyxDQUFkLEtBQWtCLEVBQWxCO0FBQ0EsU0FBS21ILE9BQUw7QUFFSCxHQWhXSTtBQWtXTDtBQUNBQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEIzSixJQUFBQSxFQUFFLENBQUM2RCxXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS3JELFVBQXpCLEVBQXFDLEtBQXJDLEVBQTRDLENBQTVDOztBQUNBLFFBQUksS0FBSzhCLFFBQUwsQ0FBYyxDQUFkLElBQW1CLEVBQXZCLEVBQTJCO0FBQ3ZCLFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsaUJBQWlCLEtBQUs5RixHQUFMLENBQVM4RixNQUE1QztBQUNBO0FBQ0g7O0FBQ0QsU0FBSzFHLFFBQUwsQ0FBYyxDQUFkLEtBQW1CLEVBQW5CO0FBQ0EsU0FBS3FILE9BQUw7QUFFSCxHQTVXSTtBQThXTDtBQUNBVixFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFLVyxTQUFMLEdBTGlCLENBS0M7QUFFckIsR0F0WEk7QUF3WEw7QUFDQVQsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUk5RCxNQUFNLEdBQUdGLElBQUksQ0FBQ0UsTUFBTCxFQUFiOztBQUNBLFFBQUlBLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQzFDLFVBQUl3SCxTQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQWhCOztBQUNBLGNBQVF5RSxTQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQVEsZUFBS0YsU0FBTCxHQUFSLENBQTBCOztBQUN0Qjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLRyxRQUFMLENBQWMsS0FBS3pILFFBQW5CLEVBQVIsQ0FBc0M7O0FBQ2xDO0FBSlI7QUFNSCxLQVJELE1BUU8sSUFBSStDLE1BQU0sR0FBR0YsSUFBSSxDQUFDMEUsR0FBTCxDQUFTLEdBQVQsRUFBYyxLQUFLdkgsUUFBTCxDQUFjLENBQWQsQ0FBZCxDQUFiLEVBQThDO0FBQUU7QUFDbkQsVUFBSTBILGVBQWUsR0FBRyxDQUF0Qjs7QUFDQSxVQUFJRixVQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkUsZUFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsVUFBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtHLFNBQUwsR0FBUixDQUEwQjs7QUFDdEI7O0FBQ0osYUFBSyxDQUFMO0FBQVEsZUFBS0MsUUFBTCxDQUFjLEtBQUsvSCxNQUFuQixFQUFSLENBQW9DOztBQUNoQztBQUpSO0FBTUgsS0FUTSxNQVNBO0FBQUU7QUFDTCxVQUFJNkgsZ0JBQWUsR0FBRyxDQUF0Qjs7QUFDQSxVQUFJRixXQUFTLEdBQUczRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkUsZ0JBQTNCLENBQWhCOztBQUNBLGNBQVFGLFdBQVI7QUFDSSxhQUFLLENBQUw7QUFBUSxlQUFLSyxlQUFMLENBQXFCLEtBQUsvSCxPQUExQixFQUFtQyxLQUFLRCxNQUF4QyxFQUFSLENBQXlEOztBQUNyRDs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLaUksVUFBTCxDQUFnQixLQUFLaEksT0FBckIsRUFBOEIsS0FBS0QsTUFBbkMsRUFBUixDQUFvRDs7QUFDaEQ7QUFKUjtBQU1IO0FBQ0osR0E1Wkk7QUE4Wkw7QUFDQWtILEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFJaEUsTUFBTSxHQUFHRixJQUFJLENBQUNFLE1BQUwsRUFBYjs7QUFDQSxRQUFJQSxNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxHQUFULEVBQWMsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWQsQ0FBYixFQUE4QztBQUMxQyxVQUFJMEgsZUFBZSxHQUFHLENBQXRCO0FBQ0EsVUFBSUYsU0FBUyxHQUFHM0UsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQjJFLGVBQTNCLENBQWhCOztBQUNBLGNBQVFGLFNBQVI7QUFDSSxhQUFLLENBQUw7QUFBUSxlQUFLTyxLQUFMLENBQVcsS0FBSy9ILFFBQWhCLEVBQVIsQ0FBbUM7O0FBQy9COztBQUNKLGFBQUssQ0FBTDtBQUFRLGVBQUtnSSxVQUFMLENBQWdCLEtBQUtoSSxRQUFyQixFQUFSLENBQXdDOztBQUNwQztBQUpSO0FBTUgsS0FURCxNQVNPLElBQUkrQyxNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxHQUFULEVBQWMsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWQsQ0FBYixFQUE4QztBQUFFO0FBQ25ELFVBQUkwSCxpQkFBZSxHQUFHLENBQXRCOztBQUNBLFVBQUlGLFdBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxpQkFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsV0FBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtTLElBQUwsQ0FBVSxLQUFLakksUUFBZixFQUFSLENBQWtDOztBQUM5Qjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLa0ksSUFBTCxDQUFVLEtBQUtwSSxPQUFmLEVBQXdCLEtBQUtELE1BQTdCLEVBQVIsQ0FBOEM7O0FBQzFDO0FBSlI7QUFNSCxLQVRNLE1BU0E7QUFBRTtBQUNMLFVBQUk2SCxpQkFBZSxHQUFHLENBQXRCLENBREcsQ0FDc0I7O0FBQ3pCLFVBQUlGLFdBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxpQkFBM0IsQ0FBaEI7O0FBQ0EsY0FBUUYsV0FBUjtBQUNJLGFBQUssQ0FBTDtBQUFRLGVBQUtXLE9BQUwsQ0FBYSxLQUFLbkksUUFBbEIsRUFBUixDQUFxQzs7QUFDakM7O0FBQ0osYUFBSyxDQUFMO0FBQVE7QUFDSjs7QUFDSixhQUFLLENBQUw7QUFBUTtBQUNKO0FBTlI7QUFRSDtBQUNKLEdBcmNJO0FBdWNMO0FBQ0FpSCxFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBSWxFLE1BQU0sR0FBR0YsSUFBSSxDQUFDRSxNQUFMLEVBQWI7O0FBQ0EsUUFBSUEsTUFBTSxHQUFHRixJQUFJLENBQUMwRSxHQUFMLENBQVMsR0FBVCxFQUFjLEtBQUt2SCxRQUFMLENBQWMsQ0FBZCxDQUFkLENBQWIsRUFBOEM7QUFDMUMsVUFBSTBILGVBQWUsR0FBRyxDQUF0QjtBQUNBLFVBQUlGLFNBQVMsR0FBRzNFLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IyRSxlQUEzQixDQUFoQjs7QUFDQSxjQUFRRixTQUFSO0FBQ0ksYUFBSyxDQUFMO0FBQVEsZUFBS1ksUUFBTCxHQUFSLENBQXlCOztBQUNyQjs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLQyxPQUFMLEdBQVIsQ0FBd0I7O0FBQ3BCOztBQUNKLGFBQUssQ0FBTDtBQUFRLGVBQUtDLFFBQUwsR0FBUixDQUF5Qjs7QUFDckI7QUFOUjtBQVFILEtBWEQsTUFXTyxJQUFJdkYsTUFBTSxHQUFHRixJQUFJLENBQUMwRSxHQUFMLENBQVMsR0FBVCxFQUFjLEtBQUt2SCxRQUFMLENBQWMsQ0FBZCxDQUFkLENBQWIsRUFBOEM7QUFBRTtBQUNuRCxXQUFLdUksU0FBTCxHQURpRCxDQUM5QjtBQUN0QixLQUZNLE1BRUE7QUFBRTtBQUNMLFdBQUtDLE9BQUwsR0FERyxDQUNhO0FBQ25CO0FBQ0osR0FoZUk7QUFrZUw7QUFDQXJCLEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFJcEUsTUFBTSxHQUFHRixJQUFJLENBQUNFLE1BQUwsRUFBYjs7QUFDQSxRQUFJQSxNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxHQUFULEVBQWMsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWQsQ0FBYixFQUE4QztBQUMxQyxVQUFJMEgsZUFBZSxHQUFHLENBQXRCO0FBQ0EsVUFBSUYsU0FBUyxHQUFHM0UsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQjJFLGVBQTNCLENBQWhCOztBQUNBLGNBQVFGLFNBQVI7QUFDSSxhQUFLLENBQUw7QUFBUSxlQUFLaUIsTUFBTCxDQUFZLEtBQUt6SSxRQUFqQixFQUFSLENBQW9DOztBQUNoQzs7QUFDSixhQUFLLENBQUw7QUFBUSxlQUFLMEksVUFBTCxHQUFSLENBQTJCOztBQUN2QjtBQUpSO0FBTUgsS0FURCxNQVNPLElBQUkzRixNQUFNLEdBQUdGLElBQUksQ0FBQzBFLEdBQUwsQ0FBUyxJQUFULEVBQWUsS0FBS3ZILFFBQUwsQ0FBYyxDQUFkLENBQWYsQ0FBYixFQUErQztBQUFFO0FBQ3BELFdBQUsySSxRQUFMLEdBRGtELENBQ2pDO0FBQ3BCLEtBRk0sTUFFQSxJQUFJNUYsTUFBTSxHQUFHRixJQUFJLENBQUMwRSxHQUFMLENBQVMsR0FBVCxFQUFjLEtBQUt2SCxRQUFMLENBQWMsQ0FBZCxDQUFkLENBQWIsRUFBOEM7QUFBRTtBQUNuRCxXQUFLNEksTUFBTCxHQURpRCxDQUNsQztBQUNsQixLQUZNLE1BRUE7QUFBRTtBQUNMLFdBQUtDLE9BQUwsQ0FBYSxLQUFLN0ksUUFBbEIsRUFERyxDQUMwQjtBQUNoQztBQUNKLEdBM2ZJO0FBNmZMO0FBQ0FxSCxFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakIsU0FBS3lCLFNBQUwsQ0FBZSxLQUFLOUksUUFBcEIsRUFEaUIsQ0FFakI7QUFDSCxHQWpnQkk7QUFtZ0JMO0FBRUE4SSxFQUFBQSxTQUFTLEVBQUUsbUJBQVVDLFNBQVYsRUFBcUI7QUFDNUIsUUFBSUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLEVBQW5CLEVBQXVCO0FBQ25CQSxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FBLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixXQUFXLEtBQUs5RixHQUFMLENBQVM4RixNQUF0QztBQUNBLFdBQUsxRyxRQUFMLENBQWMsQ0FBZCxLQUFvQixDQUFwQjtBQUNILEtBTEQsTUFLTztBQUNILFdBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isa0JBQWtCLEtBQUs5RixHQUFMLENBQVM4RixNQUE3QztBQUNIO0FBRUosR0EvZ0JJO0FBaWhCTDtBQUNBWSxFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkIsUUFBSS9ELFFBQVEsR0FBRyxLQUFLaUIsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJELENBQWY7O0FBQ0EsUUFBSSxLQUFLaUYsUUFBTCxDQUFjLEtBQUtqRixNQUFuQixFQUEyQjBELFFBQVEsQ0FBQyxDQUFELENBQW5DLEVBQXdDQSxRQUFRLENBQUMsQ0FBRCxDQUFoRCxFQUFxRCxDQUFyRCxLQUEyRCxLQUEvRCxFQUFzRTtBQUNsRUEsTUFBQUEsUUFBUSxHQUFHLEtBQUtpQixpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQsQ0FBWDtBQUNIOztBQUNELFNBQUssSUFBSTJDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsSUFBSSxJQUFJSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQTVCLEVBQTJEUCxDQUFDLEVBQTVELEVBQWdFO0FBQzVELFdBQUt3QyxzQkFBTCxDQUE0QixLQUFLbEYsT0FBakMsRUFBMEMsS0FBS0QsTUFBL0MsRUFBdUQwRCxRQUFRLENBQUMsQ0FBRCxDQUEvRCxFQUFvRUEsUUFBUSxDQUFDLENBQUQsQ0FBNUUsRUFBaUYsQ0FBakYsRUFBb0YsQ0FBcEY7QUFDSDs7QUFDRCxRQUFJLENBQUMsS0FBS0ssY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBTCxFQUEwQztBQUN0QyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0g7O0FBQ0QsU0FBS0csUUFBTCxDQUFjLENBQWQsS0FBb0IsRUFBcEI7QUFDQTJCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE1BQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBd0IsU0FBeEIsR0FBb0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxHQWhpQkk7QUFraUJMZSxFQUFBQSxRQUFRLEVBQUUsa0JBQVVzQixTQUFWLEVBQXFCO0FBRTNCLFFBQUksS0FBS25GLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBa0osTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixJQUFoQjtBQUNBcEgsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksY0FBWjtBQUNBbUksTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBQSxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsV0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixpQ0FBekIsR0FBNkQsS0FBS1MsR0FBTCxDQUFTOEYsTUFBeEY7QUFDSCxLQVBELE1BT087QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixnQkFBZ0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTNDO0FBRUg7QUFDSixHQS9pQkk7QUFpakJMO0FBQ0FpQixFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkIsUUFBSSxLQUFLL0QsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0EsV0FBS2UsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGNBQXpCLEdBQTBDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXJFO0FBQ0gsS0FIRCxNQUdPLElBQUksS0FBSzlDLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDNUMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxDQUFyRDtBQUNBLFdBQUtlLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixjQUF6QixHQUEwQyxLQUFLUyxHQUFMLENBQVM4RixNQUFyRTtBQUNILEtBSE0sTUFHQTtBQUNILFVBQUksS0FBSzlDLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLEtBQXVDLEtBQTNDLEVBQWtEO0FBQzlDLGFBQUtlLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsZ0JBQWdCLEtBQUs5RixHQUFMLENBQVM4RixNQUEzQztBQUNILE9BRkQsTUFFTztBQUNILGFBQUtsQyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQSxhQUFLZSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSDtBQUNKO0FBQ0osR0Fqa0JJO0FBbWtCTDtBQUNBa0IsRUFBQUEsUUFBUSxFQUFFLGtCQUFVbEYsUUFBVixFQUFvQjtBQUMxQixRQUFJLEtBQUtrQixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFVBQUk2RSxVQUFVLEdBQUcsS0FBS2IsUUFBTCxDQUFjbkIsUUFBZCxFQUF3QixDQUF4QixDQUFqQjtBQUNBLFVBQUlpQyxLQUFLLEdBQUk5QixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCMkIsVUFBVSxDQUFDL0IsTUFBdEMsQ0FBYjs7QUFDQSxXQUFLLElBQUlILENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBcEQsRUFBdURQLENBQUMsRUFBeEQsRUFBNEQ7QUFDeEQsYUFBSzhDLGdCQUFMLENBQXNCLEtBQUt4RixPQUEzQixFQUFvQyxLQUFLRCxNQUF6QyxFQUFpRDZFLFVBQVUsQ0FBQ0MsS0FBRCxDQUFWLENBQWtCLENBQWxCLENBQWpELEVBQXVFRCxVQUFVLENBQUNDLEtBQUQsQ0FBVixDQUFrQixDQUFsQixDQUF2RSxFQUE2RixDQUE3RjtBQUNIOztBQUNELFdBQUsvRCxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsU0FBekIsR0FBcUMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBaEU7QUFDSCxLQVBELE1BT087QUFDSCxXQUFLaUIsU0FBTDs7QUFDQSxVQUFJLEtBQUsvRCxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLGFBQUtlLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixTQUF6QixHQUFxQyxLQUFLUyxHQUFMLENBQVM4RixNQUFoRTtBQUNIO0FBQ0o7QUFDSixHQWxsQkk7QUFvbEJMO0FBQ0FvQixFQUFBQSxVQUFVLEVBQUUsb0JBQVU5RSxTQUFWLEVBQXFCTixRQUFyQixFQUErQjtBQUN2QyxTQUFLLElBQUlGLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsRUFBM0IsSUFBaUMsQ0FBckQsRUFBd0RQLENBQUMsRUFBekQsRUFBNkQ7QUFDekQsVUFBSVcsQ0FBQyxHQUFHTixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCTCxRQUFRLENBQUNDLE1BQXBDLENBQVI7QUFDQSxVQUFJUyxDQUFDLEdBQUdQLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0JMLFFBQVEsQ0FBQyxDQUFELENBQVIsQ0FBWUMsTUFBdkMsQ0FBUjtBQUNBLFVBQUlxRyxRQUFRLEdBQUcsS0FBS3JGLFNBQUwsQ0FBZWpCLFFBQWYsRUFBd0IsQ0FBeEIsQ0FBZjs7QUFDQSxXQUFLLElBQUlGLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0JpRyxRQUFoQixHQUEyQixDQUF0QyxDQUFwQixFQUE4RHhHLEdBQUMsRUFBL0QsRUFBbUU7QUFDL0QsWUFBSSxLQUFLbUIsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixJQUE4QixDQUFsQyxFQUFxQztBQUNqQyxlQUFLc0Msc0JBQUwsQ0FBNEJoQyxTQUE1QixFQUF1Q04sUUFBdkMsRUFBaURTLENBQWpELEVBQW9EQyxDQUFwRCxFQUF1RCxDQUF2RCxFQUEwRCxDQUExRDtBQUNBLGVBQUtwRCxRQUFMLENBQWMsQ0FBZCxLQUFtQjZDLElBQUksQ0FBQ29HLElBQUwsQ0FBVXBHLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUExQixDQUFuQjs7QUFDQSxjQUFJLEtBQUsvQyxRQUFMLENBQWMsQ0FBZCxLQUFvQixDQUF4QixFQUEyQjtBQUN2QixpQkFBS0EsUUFBTCxDQUFjLENBQWQsSUFBbUIsQ0FBbkI7QUFDSDtBQUNKO0FBRUo7QUFDSjs7QUFDRDJCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxTQUFLWixRQUFMLENBQWMsQ0FBZCxLQUFvQixFQUFwQjtBQUNBLFNBQUtZLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixlQUF6QixHQUEyQyxLQUFLUyxHQUFMLENBQVM4RixNQUF0RTtBQUNILEdBeG1CSTtBQTBtQkw7QUFDQW1CLEVBQUFBLGVBQWUsRUFBRSx5QkFBVTdFLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCO0FBQzVDLFFBQUl3RyxPQUFPLEdBQUdyRyxJQUFJLENBQUNFLE1BQUwsRUFBZDs7QUFDQSxRQUFJLEtBQUthLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSXRCLEtBQUssR0FBRyxLQUFLc0YsUUFBTCxDQUFjLEtBQUtoRSxNQUFuQixFQUEyQixDQUEzQixDQUFaOztBQUNBLFdBQUssSUFBSTJDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXdkUsS0FBSyxDQUFDb0UsTUFBTixHQUFlLEVBQTFCLENBQXBCLEVBQW1ESCxDQUFDLEVBQXBELEVBQXdEO0FBQ3BEMEcsUUFBQUEsT0FBTyxHQUFHckcsSUFBSSxDQUFDRSxNQUFMLEVBQVY7O0FBQ0EsWUFBSW1HLE9BQU8sR0FBRyxHQUFkLEVBQW1CO0FBQ2YsZUFBSzFFLGlCQUFMLENBQXVCeEIsU0FBdkIsRUFBa0NOLFFBQWxDLEVBQTRDLENBQTVDLEVBQStDLENBQS9DO0FBQ0g7QUFDSjtBQUNKOztBQUNELFFBQUksS0FBS2tCLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSXBCLElBQUksR0FBRyxLQUFLb0YsUUFBTCxDQUFjLEtBQUtoRSxNQUFuQixFQUEyQixDQUEzQixDQUFYOztBQUNBLFdBQUssSUFBSTJDLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXckUsSUFBSSxDQUFDa0UsTUFBTCxHQUFjLEVBQXpCLENBQXBCLEVBQWtESCxHQUFDLEVBQW5ELEVBQXVEO0FBQ25EMEcsUUFBQUEsT0FBTyxHQUFHckcsSUFBSSxDQUFDRSxNQUFMLEVBQVY7O0FBQ0EsWUFBSW1HLE9BQU8sR0FBRyxHQUFkLEVBQW1CO0FBQ2YsZUFBSzFFLGlCQUFMLENBQXVCeEIsU0FBdkIsRUFBa0NBLFNBQWxDLEVBQTZDLENBQTdDLEVBQWdELENBQWhEO0FBQ0g7QUFDSjtBQUNKOztBQUNEckIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFNBQUtaLFFBQUwsQ0FBYyxDQUFkLEtBQW9CLEVBQXBCO0FBQ0EsU0FBS1ksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGlCQUF6QixHQUE2QyxLQUFLUyxHQUFMLENBQVM4RixNQUF4RTtBQUNILEdBbG9CSTtBQW9vQkw7QUFFQTtBQUNBc0IsRUFBQUEsVUFBVSxFQUFFLG9CQUFVaEksUUFBVixFQUFvQjtBQUM1QkEsSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWY7QUFDQTJCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE1BQVo7QUFDQVosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsb0JBQXpCLEdBQWdELEtBQUtTLEdBQUwsQ0FBUzhGLE1BQTNFO0FBQ0gsR0E1b0JJO0FBOG9CTDtBQUNBcUIsRUFBQUEsS0FBSyxFQUFFLGVBQVUvSCxRQUFWLEVBQW9CO0FBQ3ZCLFFBQUltSixJQUFJLEdBQUcsRUFBWDtBQUNBbkosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLElBQWY7O0FBQ0EsUUFBSTZDLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUNyQi9DLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxHQUFmO0FBQ0FtSixNQUFBQSxJQUFJLEdBQUcsU0FBUDtBQUNBbkosTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDSCxLQUpELE1BSU87QUFDSEEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWY7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQW1KLE1BQUFBLElBQUksR0FBRyxNQUFQO0FBQ0g7O0FBQ0R4SCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLE9BQXpCLEdBQW1DZ0osSUFBbkMsR0FBMEMsSUFBMUMsR0FBaUQsS0FBS3ZJLEdBQUwsQ0FBUzhGLE1BQTVFO0FBQ0gsR0E3cEJJO0FBK3BCTDtBQUNBdUIsRUFBQUEsSUFBSSxFQUFFLGNBQVVqSSxRQUFWLEVBQW9CO0FBQ3RCQSxJQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWU2QyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBL0I7QUFDQXBCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQVosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsUUFBekIsR0FBb0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxHQXJxQkk7QUF1cUJMO0FBQ0F5QixFQUFBQSxPQUFPLEVBQUUsaUJBQVVuSSxRQUFWLEVBQW9CO0FBQ3pCQSxJQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWU2QyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBL0I7QUFDQXBCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLElBQVo7QUFDQVosSUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQWY7QUFDQSxTQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSCxHQTdxQkk7QUErcUJMO0FBQ0F3QixFQUFBQSxJQUFJLEVBQUUsY0FBVWxGLFNBQVYsRUFBcUJOLFFBQXJCLEVBQStCO0FBQ2pDLFFBQUksS0FBS2tCLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSWhCLElBQUksR0FBRyxLQUFLZ0YsUUFBTCxDQUFjbkIsUUFBZCxFQUF3QixDQUF4QixDQUFYOztBQUNBLFdBQUssSUFBSUYsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0ssSUFBSSxDQUFDQyxLQUFMLENBQVdqRSxJQUFJLENBQUM4RCxNQUFMLEdBQWMsRUFBekIsQ0FBcEIsRUFBa0RILENBQUMsRUFBbkQsRUFBdUQ7QUFDbkQsWUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGVBQUt5QixpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNIO0FBQ0o7QUFDSjs7QUFDRCxRQUFJLEtBQUtrQixjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFVBQUluQixLQUFLLEdBQUcsS0FBS21GLFFBQUwsQ0FBY25CLFFBQWQsRUFBd0IsQ0FBeEIsQ0FBWjs7QUFDQSxXQUFLLElBQUlGLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUdLLElBQUksQ0FBQ0MsS0FBTCxDQUFXcEUsS0FBSyxDQUFDaUUsTUFBTixHQUFlLEVBQTFCLENBQXBCLEVBQW1ESCxHQUFDLEVBQXBELEVBQXdEO0FBQ3BELFlBQUlLLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUNyQixlQUFLeUIsaUJBQUwsQ0FBdUJ4QixTQUF2QixFQUFrQ04sUUFBbEMsRUFBNEMsQ0FBNUMsRUFBK0MsQ0FBL0M7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsUUFBSSxLQUFLa0IsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxVQUFJdUosS0FBSyxHQUFHLEtBQUt2RixRQUFMLENBQWNuQixRQUFkLEVBQXdCLENBQXhCLENBQVo7O0FBQ0EsV0FBSyxJQUFJRixHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHSyxJQUFJLENBQUNDLEtBQUwsQ0FBV3NHLEtBQUssQ0FBQ3pHLE1BQU4sR0FBZSxFQUExQixDQUFwQixFQUFtREgsR0FBQyxFQUFwRCxFQUF3RDtBQUNwRCxZQUFJSyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBcEIsRUFBeUI7QUFDckIsZUFBS3lCLGlCQUFMLENBQXVCeEIsU0FBdkIsRUFBa0NOLFFBQWxDLEVBQTRDLENBQTVDLEVBQStDLENBQS9DO0FBQ0g7QUFDSjtBQUNKOztBQUNELFFBQUksS0FBS2tCLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsVUFBSWpCLEtBQUssR0FBRyxLQUFLaUYsUUFBTCxDQUFjbkIsUUFBZCxFQUF3QixDQUF4QixDQUFaOztBQUNBLFdBQUssSUFBSUYsR0FBQyxHQUFHLENBQWIsRUFBZ0JBLEdBQUMsR0FBR0ssSUFBSSxDQUFDQyxLQUFMLENBQVdsRSxLQUFLLENBQUMrRCxNQUFOLEdBQWUsRUFBMUIsQ0FBcEIsRUFBbURILEdBQUMsRUFBcEQsRUFBd0Q7QUFDcEQsWUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGVBQUt5QixpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNIO0FBQ0o7QUFDSjs7QUFDRGYsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFNBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixTQUF6QixHQUFxQyxLQUFLUyxHQUFMLENBQVM4RixNQUFoRTtBQUNILEdBbnRCSTtBQXF0Qkw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0EwQixFQUFBQSxRQUFRLEVBQUUsb0JBQVk7QUFDbEIsUUFBSSxLQUFLeEUsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxNQUFaO0FBQ0EsV0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixZQUFZLEtBQUs5RixHQUFMLENBQVM4RixNQUF2QztBQUNILEtBSkQsTUFJTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG1CQUFtQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBOUM7QUFDSDtBQUNKLEdBcHdCSTtBQXN3Qkw7QUFDQTZCLEVBQUFBLFNBQVMsRUFBRSxxQkFBWTtBQUNuQixRQUFJLEtBQUszRSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsRUFBckQ7QUFDQThCLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE9BQVo7QUFDQSxXQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsVUFBekIsR0FBc0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBakU7QUFDSCxLQUpELE1BSU87QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixtQkFBbUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTlDO0FBQ0g7QUFDSixHQS93Qkk7QUFpeEJMO0FBQ0E4QixFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakIsUUFBSSxLQUFLNUUsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxNQUFaO0FBQ0EsV0FBS1osUUFBTCxDQUFjLENBQWQsS0FBb0IsRUFBcEI7QUFDQSxXQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsU0FBekIsR0FBcUMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBaEU7QUFDSCxLQUxELE1BS087QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixrQkFBa0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTdDO0FBQ0g7QUFDSixHQTN4Qkk7QUE2eEJMO0FBQ0EyQixFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakIsUUFBSSxLQUFLekUsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsS0FBdUMsS0FBM0MsRUFBa0Q7QUFDOUMsV0FBS2UsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixrQkFBa0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTdDO0FBQ0E7QUFDSDs7QUFDRCxTQUFLbEMsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0E4QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQTBCLFNBQTFCLEdBQXNDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWpFO0FBQ0gsR0F0eUJJO0FBd3lCTDRCLEVBQUFBLFFBQVEsRUFBRSxvQkFBWTtBQUNsQixTQUFLOUQsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0E4QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQTBCLFlBQTFCLEdBQXlDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXBFO0FBQ0gsR0E1eUJJO0FBOHlCTDtBQUVBZ0MsRUFBQUEsVUFBVSxFQUFFLHNCQUFZO0FBQ3BCLFFBQUksS0FBSzlFLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxFQUFyRDtBQUNBOEIsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFdBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUEwQixXQUExQixHQUF3QyxLQUFLUyxHQUFMLENBQVM4RixNQUFuRTtBQUNILEtBSkQsTUFJTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG9CQUFvQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBL0M7QUFDSDtBQUNKLEdBeHpCSTtBQTB6QkwrQixFQUFBQSxNQUFNLEVBQUUsZ0JBQVVNLFNBQVYsRUFBcUI7QUFDekIsUUFBSSxLQUFLbkYsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0FrSixNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNBcEgsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksS0FBWjtBQUNBLFdBQUtBLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsTUFBTSxLQUFLdkcsSUFBWCxHQUFrQixJQUFsQixHQUF5QixXQUF6QixHQUF1QyxLQUFLUyxHQUFMLENBQVM4RixNQUFsRTtBQUNILEtBTEQsTUFLTztBQUNILFdBQUs5RixHQUFMLENBQVM4RixNQUFULEdBQWtCLG9CQUFvQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBL0M7QUFDSDtBQUNKLEdBbjBCSTtBQXEwQkxrQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDaEIsUUFBSSxLQUFLaEYsY0FBTCxDQUFvQixLQUFLL0QsTUFBekIsRUFBaUMsQ0FBakMsQ0FBSixFQUF5QztBQUNyQyxXQUFLMkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELEVBQXJEO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxLQUFaO0FBQ0EsV0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLFdBQXpCLEdBQXVDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQWxFO0FBQ0gsS0FKRCxNQUlPO0FBQ0gsV0FBSzlGLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isb0JBQW9CLEtBQUs5RixHQUFMLENBQVM4RixNQUEvQztBQUNIO0FBQ0osR0E3MEJJO0FBKzBCTGlDLEVBQUFBLFFBQVEsRUFBRSxvQkFBWTtBQUNsQixRQUFJLEtBQUsvRSxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLFdBQUsyRSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsRUFBckQ7QUFDQThCLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLEtBQVo7QUFDQSxXQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsVUFBekIsR0FBc0MsS0FBS1MsR0FBTCxDQUFTOEYsTUFBakU7QUFDSCxLQUpELE1BSU87QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixvQkFBb0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQS9DO0FBQ0g7QUFDSixHQXYxQkk7QUF5MUJMbUMsRUFBQUEsT0FBTyxFQUFFLGlCQUFVRSxTQUFWLEVBQXFCO0FBQzFCLFFBQUksS0FBS25GLGNBQUwsQ0FBb0IsS0FBSy9ELE1BQXpCLEVBQWlDLENBQWpDLENBQUosRUFBeUM7QUFDckMsV0FBSzJFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxDQUFsRCxFQUFxRCxFQUFyRDtBQUNBa0osTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQXBILE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE1BQVo7QUFDQSxXQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsY0FBekIsR0FBMEMsS0FBS1MsR0FBTCxDQUFTOEYsTUFBckU7QUFDSCxLQUxELE1BS087QUFDSCxXQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixvQkFBb0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQS9DO0FBQ0g7QUFDSixHQWwyQkk7QUFvMkJMO0FBQ0E7QUFDQTJDLEVBQUFBLFdBQVcsRUFBRSxxQkFBVXJKLFFBQVYsRUFBb0I7QUFDN0JBLElBQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBYyxLQUFLQSxRQUFRLENBQUMsQ0FBRCxDQUFSLEdBQWMsSUFBakM7O0FBQ0EsUUFBSUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlQSxRQUFRLENBQUMsRUFBRCxDQUEzQixFQUFpQztBQUM3QjtBQUNBQSxNQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWUsRUFBZjtBQUNBQSxNQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWVBLFFBQVEsQ0FBQyxFQUFELENBQXZCO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxFQUFELENBQVIsR0FBZUEsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlLEdBQTlCO0FBQ0FBLE1BQUFBLFFBQVEsQ0FBQyxFQUFELENBQVI7QUFDSCxLQU5ELE1BTU8sSUFBSUEsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjLENBQWxCLEVBQXFCO0FBQ3hCQSxNQUFBQSxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWUsRUFBZjtBQUNBQSxNQUFBQSxRQUFRLENBQUMsRUFBRCxDQUFSLEdBQWVBLFFBQVEsQ0FBQyxFQUFELENBQVIsR0FBZSxHQUE5Qjs7QUFDQSxVQUFJQSxRQUFRLENBQUMsRUFBRCxDQUFSLElBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCQSxRQUFBQSxRQUFRLENBQUMsRUFBRCxDQUFSLElBQWdCLEdBQWhCO0FBQ0g7O0FBQ0RBLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBY0EsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlQSxRQUFRLENBQUMsQ0FBRCxDQUFyQztBQUNBQSxNQUFBQSxRQUFRLENBQUMsRUFBRCxDQUFSOztBQUNBLFVBQUlBLFFBQVEsQ0FBQyxFQUFELENBQVIsR0FBZSxDQUFuQixFQUFzQjtBQUNsQkEsUUFBQUEsUUFBUSxDQUFDLEVBQUQsQ0FBUixHQUFlLENBQWY7QUFDSDtBQUNKOztBQUNELFFBQUlBLFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZUEsUUFBUSxDQUFDLENBQUQsQ0FBM0IsRUFBZ0M7QUFDNUJBLE1BQUFBLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBY0EsUUFBUSxDQUFDLENBQUQsQ0FBdEI7QUFDSDtBQUNKLEdBNzNCSTtBQTgzQkw7QUFDQXNKLEVBQUFBLFdBQVcsRUFBRSxxQkFBVVAsU0FBVixFQUFxQjtBQUM5QixTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELEVBQWxELEVBQXNELENBQXREO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FwSCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxjQUFaO0FBQ0FtSSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsU0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsZ0JBQWdCLEtBQUs5RixHQUFMLENBQVM4RixNQUEzQztBQUNILEdBcjRCSTtBQXU0Qkw7QUFDQTZDLEVBQUFBLFlBQVksRUFBRSxzQkFBVVIsU0FBVixFQUFxQjtBQUMvQixTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELEVBQWxELEVBQXNELENBQXREO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FwSCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxlQUFaO0FBQ0FtSSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsU0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IseUJBQXlCLEtBQUs5RixHQUFMLENBQVM4RixNQUFwRDtBQUNILEdBOTRCSTtBQWc1Qkw7QUFDQThDLEVBQUFBLFdBQVcsRUFBRSxxQkFBVVQsU0FBVixFQUFxQjtBQUM5QixTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FwSCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxlQUFaO0FBQ0FtSSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0EsU0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsdUJBQXVCLEtBQUs5RixHQUFMLENBQVM4RixNQUFsRDtBQUNILEdBdjVCSTtBQXk1QkwrQyxFQUFBQSxVQUFVLEVBQUUsb0JBQVVWLFNBQVYsRUFBcUJyRyxRQUFyQixFQUErQlEsR0FBL0IsRUFBb0M7QUFDNUN2QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsUUFBSThJLFdBQVcsR0FBR3hHLEdBQWxCO0FBQ0EsUUFBSXlHLFFBQVEsR0FBRyxLQUFLaEcsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFmO0FBQ0EsUUFBSWtILFFBQVEsR0FBRyxLQUFLakcsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFmO0FBQ0EsUUFBSW1ILFNBQVMsR0FBRyxLQUFLbEcsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFoQjs7QUFDQSxRQUFJaUgsUUFBUSxHQUFHLENBQVgsSUFBZ0JDLFFBQVEsR0FBRyxDQUEzQixJQUFnQ0MsU0FBUyxHQUFHLENBQWhELEVBQW1EO0FBQy9DZCxNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0g7O0FBQ0QsUUFBSTdGLEdBQUcsR0FBR3lHLFFBQVEsR0FBR0MsUUFBWCxHQUFzQkMsU0FBaEMsRUFBMkM7QUFDdkNILE1BQUFBLFdBQVcsR0FBR0UsUUFBUSxHQUFHQyxTQUFYLEdBQXVCRixRQUFyQztBQUNIOztBQUNELFNBQUssSUFBSW5ILENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdrSCxXQUFwQixFQUFpQ2xILENBQUMsRUFBbEMsRUFBc0M7QUFDbENiLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGdCQUFaOztBQUNBLFVBQUkrSSxRQUFRLEdBQUcsQ0FBZixFQUFrQjtBQUNkLGFBQUtILFdBQUwsQ0FBaUJULFNBQWpCO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsWUFBSWMsU0FBUyxJQUFJLENBQWpCLEVBQW9CO0FBQ2hCLGVBQUtQLFdBQUwsQ0FBaUJQLFNBQWpCO0FBQ0gsU0FGRCxNQUVPLElBQUlhLFFBQVEsSUFBSSxDQUFoQixFQUFtQjtBQUN0QixlQUFLTCxZQUFMLENBQWtCUixTQUFsQjtBQUNILFNBRk0sTUFFQTtBQUNILGNBQUlsRyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBcEIsRUFBeUI7QUFDckIsaUJBQUt1RyxXQUFMLENBQWlCUCxTQUFqQjtBQUNILFdBRkQsTUFFTztBQUNILGlCQUFLUSxZQUFMLENBQWtCUixTQUFsQjtBQUNIO0FBQ0o7QUFDSjtBQUNKO0FBQ0osR0F2N0JJO0FBeTdCTGUsRUFBQUEsVUFBVSxFQUFFLG9CQUFVZixTQUFWLEVBQXFCO0FBQzdCLFNBQUt2RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQWtKLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQUEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBcEgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksNEJBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGtCQUFrQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBN0M7QUFFSCxHQWg4Qkk7QUFrOEJMcUQsRUFBQUEsZUFBZSxFQUFFLHlCQUFVaEIsU0FBVixFQUFxQjtBQUNsQyxTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FBLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQUEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBcEgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksa0NBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLHVCQUF1QixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBbEQ7QUFFSCxHQTE4Qkk7QUE0OEJMc0QsRUFBQUEsV0FBVyxFQUFFLHFCQUFVakIsU0FBVixFQUFxQjtBQUM5QixTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELENBQWxELEVBQXFELENBQXJEO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FBLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDZCQUFaO0FBQ0EsU0FBS0EsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixrQkFBa0IsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTdDO0FBQ0gsR0FsOUJJO0FBbzlCTHVELEVBQUFBLGNBQWMsRUFBRSx3QkFBVWxCLFNBQVYsRUFBcUJyRyxRQUFyQixFQUErQlEsR0FBL0IsRUFBb0M7QUFDaER2QixJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxpQkFBWjtBQUNBLFFBQUk4SSxXQUFXLEdBQUd4RyxHQUFsQjtBQUNBLFFBQUlnSCxPQUFPLEdBQUcsS0FBS3ZHLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBZDtBQUNBLFFBQUl5SCxZQUFZLEdBQUcsS0FBS3hHLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBbkI7QUFDQSxRQUFJMEgsUUFBUSxHQUFHLEtBQUt6RyxTQUFMLENBQWVqQixRQUFmLEVBQXlCLENBQXpCLENBQWY7O0FBQ0EsUUFBSXdILE9BQU8sR0FBRyxDQUFWLElBQWVDLFlBQVksR0FBRyxDQUE5QixJQUFtQ0MsUUFBUSxHQUFHLENBQWxELEVBQXFELENBQ3BEOztBQUNELFFBQUlsSCxHQUFHLEdBQUdnSCxPQUFPLEdBQUdFLFFBQVYsR0FBcUJELFlBQS9CLEVBQTZDO0FBQ3pDVCxNQUFBQSxXQUFXLEdBQUdRLE9BQU8sR0FBR0UsUUFBVixHQUFxQkQsWUFBbkM7QUFDSDs7QUFDRCxTQUFLLElBQUkzSCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHa0gsV0FBcEIsRUFBaUNsSCxDQUFDLEVBQWxDLEVBQXNDO0FBQ2xDYixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxvQkFBWjs7QUFDQSxVQUFJd0osUUFBUSxHQUFHLENBQWYsRUFBa0I7QUFDZCxhQUFLSixXQUFMLENBQWlCakIsU0FBakI7QUFDSCxPQUZELE1BRU87QUFDSCxZQUFJbUIsT0FBTyxJQUFJLENBQWYsRUFBa0I7QUFDZCxlQUFLSCxlQUFMLENBQXFCaEIsU0FBckI7QUFDSCxTQUZELE1BRU87QUFDSCxlQUFLZSxVQUFMLENBQWdCZixTQUFoQjtBQUNIO0FBQ0o7QUFDSjtBQUNKLEdBMytCSTtBQTYrQkxzQixFQUFBQSxXQUFXLEVBQUUscUJBQVV0QixTQUFWLEVBQXFCO0FBQzlCLFNBQUt2RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQWtKLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGNBQVo7QUFDQW1JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQix5QkFBeUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQXBEO0FBQ0gsR0FuL0JJO0FBcS9CTDRELEVBQUFBLE9BQU8sRUFBRSxpQkFBVXZCLFNBQVYsRUFBcUI7QUFDMUIsU0FBS3ZFLGlCQUFMLENBQXVCLEtBQUsxRSxPQUE1QixFQUFxQyxLQUFLRCxNQUExQyxFQUFrRCxFQUFsRCxFQUFzRCxDQUF0RDtBQUNBa0osSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQSxRQUFJd0IsSUFBSSxHQUFHMUgsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFYO0FBQ0FnRyxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCd0IsSUFBaEI7QUFDQXhCLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFVBQVo7O0FBQ0EsUUFBSTJKLElBQUksSUFBSSxDQUFaLEVBQWU7QUFDWHhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixRQUFRLE1BQVIsR0FBaUI2RCxJQUFqQixHQUF3QixTQUF4QixHQUFvQyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxLQUhELE1BR087QUFDSHFDLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixRQUFRLE1BQVIsR0FBaUI2RCxJQUFqQixHQUF3QixjQUF4QixHQUF5QyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBcEU7QUFDSDtBQUNKLEdBbmdDSTtBQXFnQ0w4RCxFQUFBQSxPQUFPLEVBQUUsaUJBQVV6QixTQUFWLEVBQXFCO0FBQzFCLFNBQUt2RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQSxRQUFJMEssSUFBSSxHQUFHMUgsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFYO0FBQ0FnRyxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCd0IsSUFBaEI7QUFDQXhCLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFVBQVo7O0FBQ0EsUUFBSTJKLElBQUksSUFBSSxDQUFaLEVBQWU7QUFDWHhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixRQUFRLE1BQVIsR0FBaUI2RCxJQUFqQixHQUF3QixTQUF4QixHQUFvQyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxLQUhELE1BR087QUFDSHFDLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixRQUFRLE1BQVIsR0FBaUI2RCxJQUFqQixHQUF3QixlQUF4QixHQUEwQyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBckU7QUFDSDs7QUFDRCxTQUFLOUYsR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixRQUFRLE1BQVIsR0FBaUI2RCxJQUFqQixHQUF3QixTQUF4QixHQUFvQyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSCxHQW5oQ0k7QUFxaENMK0QsRUFBQUEsU0FBUyxFQUFFLG1CQUFVMUIsU0FBVixFQUFxQjtBQUM1QixTQUFLdkUsaUJBQUwsQ0FBdUIsS0FBSzFFLE9BQTVCLEVBQXFDLEtBQUtELE1BQTFDLEVBQWtELEVBQWxELEVBQXNELENBQXREO0FBQ0FrSixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0FwSCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxZQUFaO0FBQ0FtSSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsU0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IscUJBQXFCLEtBQUs5RixHQUFMLENBQVM4RixNQUFoRDtBQUNILEdBM2hDSTtBQTZoQ0xnRSxFQUFBQSxRQUFRLEVBQUUsa0JBQVUzQixTQUFWLEVBQXFCO0FBQzNCLFNBQUt2RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsRUFBbEQsRUFBc0QsQ0FBdEQ7QUFDQWtKLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLEtBQW1CLENBQW5CO0FBQ0EsUUFBSXdCLElBQUksR0FBRzFILElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsQ0FBWDtBQUNBZ0csSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQndCLElBQWhCO0FBQ0F4QixJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLEVBQWhCO0FBQ0FwSCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxXQUFaOztBQUNBLFFBQUkySixJQUFJLElBQUksQ0FBWixFQUFlO0FBQ1h4QixNQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQWhCO0FBQ0EsV0FBS25JLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsU0FBUyxNQUFULEdBQWtCNkQsSUFBbEIsR0FBeUIsV0FBekIsR0FBdUMsS0FBSzNKLEdBQUwsQ0FBUzhGLE1BQWxFO0FBQ0gsS0FIRCxNQUdPLElBQUk2RCxJQUFJLEdBQUcsQ0FBWCxFQUFjO0FBQ2pCeEIsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBLFdBQUtuSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGlCQUFpQixLQUFLOUYsR0FBTCxDQUFTOEYsTUFBNUM7QUFDSCxLQUhNLE1BR0E7QUFDSHFDLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsRUFBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixlQUFlNkQsSUFBZixHQUFzQixXQUF0QixHQUFvQyxLQUFLM0osR0FBTCxDQUFTOEYsTUFBL0Q7QUFDSDtBQUVKLEdBL2lDSTtBQWlqQ0xpRSxFQUFBQSxVQUFVLEVBQUUsb0JBQVU1QixTQUFWLEVBQXFCckcsUUFBckIsRUFBK0JRLEdBQS9CLEVBQW9DO0FBQzVDdkIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksYUFBWjtBQUNBLFFBQUk4SSxXQUFXLEdBQUd4RyxHQUFsQjtBQUNBLFFBQUlsRSxPQUFPLEdBQUcsS0FBSzJFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsSUFBK0JxRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixDQUE3QztBQUNBLFFBQUk1SixLQUFLLEdBQUcsS0FBS3dFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsSUFBK0JxRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixDQUEzQztBQUNBLFFBQUk3SixHQUFHLEdBQUcsS0FBS3lFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsSUFBK0JxRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixDQUF6QztBQUNBLFFBQUk2QixJQUFJLEdBQUcsS0FBS2pILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBWDtBQUNBLFFBQUl0RCxJQUFJLEdBQUcsS0FBS3VFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBWDs7QUFDQSxRQUFJMUQsT0FBTyxHQUFHLENBQVYsSUFBZUcsS0FBSyxHQUFHLENBQXZCLElBQTRCRCxHQUFHLEdBQUcsQ0FBbEMsSUFBdUMwTCxJQUFJLEdBQUcsQ0FBOUMsSUFBbUR4TCxJQUFJLEdBQUcsQ0FBOUQsRUFBaUU7QUFDN0QsV0FBS3dCLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0Isb0JBQW9CLEtBQUs5RixHQUFMLENBQVM4RixNQUEvQztBQUNIOztBQUNELFFBQUl4RCxHQUFHLEdBQUdMLElBQUksQ0FBQ0MsS0FBTCxDQUFXOUQsT0FBTyxHQUFHRyxLQUFLLEdBQUcsQ0FBbEIsR0FBc0JELEdBQUcsR0FBRyxDQUE1QixHQUFnQzBMLElBQUksR0FBRyxDQUF2QyxHQUEyQ3hMLElBQUksR0FBRyxDQUE3RCxDQUFWLEVBQTJFO0FBQ3ZFc0ssTUFBQUEsV0FBVyxHQUFHN0csSUFBSSxDQUFDQyxLQUFMLENBQVc5RCxPQUFPLEdBQUdHLEtBQUssR0FBRyxDQUFsQixHQUFzQkQsR0FBRyxHQUFHLENBQTVCLEdBQWdDMEwsSUFBSSxHQUFHLENBQXZDLEdBQTJDeEwsSUFBSSxHQUFHLENBQTdELENBQWQ7QUFDSDs7QUFDRCxTQUFLLElBQUlvRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHa0gsV0FBcEIsRUFBaUNsSCxDQUFDLEVBQWxDLEVBQXNDO0FBQ2xDYixNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxnQkFBWjs7QUFDQSxVQUFJNUIsT0FBTyxHQUFHLENBQWQsRUFBaUI7QUFDYixhQUFLcUwsV0FBTCxDQUFpQnRCLFNBQWpCOztBQUNBLFlBQUlsRyxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBaEIsSUFBdUJnRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixJQUFrQixDQUE3QyxFQUFnRDtBQUM1Q0EsVUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDSDtBQUNKLE9BTEQsTUFLTyxJQUFJNUosS0FBSyxHQUFHLENBQVosRUFBZTtBQUNsQixhQUFLc0wsU0FBTCxDQUFlMUIsU0FBZjs7QUFDQSxZQUFJbEcsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLElBQWhCLElBQXdCZ0csU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsSUFBa0IsQ0FBOUMsRUFBaUQ7QUFDN0NBLFVBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLEtBQW1CLENBQW5CO0FBQ0g7QUFDSixPQUxNLE1BS0EsSUFBSTdKLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDaEIsYUFBS3NMLE9BQUwsQ0FBYXpCLFNBQWI7O0FBQ0EsWUFBSWxHLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixJQUFoQixJQUF3QmdHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLElBQWtCLENBQTlDLEVBQWlEO0FBQzdDQSxVQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNIO0FBQ0osT0FMTSxNQUtBLElBQUk2QixJQUFJLEdBQUcsQ0FBWCxFQUFjO0FBQ2pCLGFBQUtOLE9BQUwsQ0FBYXZCLFNBQWI7QUFDSCxPQUZNLE1BRUE7QUFDSCxhQUFLMkIsUUFBTCxDQUFjM0IsU0FBZDtBQUNIO0FBQ0o7QUFDSixHQXRsQ0k7QUF3bENMOEIsRUFBQUEsV0FBVyxFQUFFLHFCQUFVOUIsU0FBVixFQUFxQjtBQUM5QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGFBQVo7QUFDQW1JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLHNCQUF6QixHQUFrRCxLQUFLUyxHQUFMLENBQVM4RixNQUE3RTtBQUNILEdBN2xDSTtBQStsQ0xvRSxFQUFBQSxPQUFPLEVBQUUsaUJBQVUvQixTQUFWLEVBQXFCO0FBQzFCQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixLQUFtQixDQUFuQjtBQUNBQSxJQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCbEcsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixDQUFoQjtBQUNBcEIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksU0FBWjtBQUNBLFFBQUkySixJQUFJLEdBQUcxSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQVg7O0FBQ0EsUUFBSXdILElBQUksSUFBSSxDQUFaLEVBQWU7QUFDWHhCLE1BQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGdCQUF6QixHQUE0QyxLQUFLUyxHQUFMLENBQVM4RixNQUF2RTtBQUNILEtBSEQsTUFHTztBQUNIcUMsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixFQUFoQjtBQUNBLFdBQUtuSSxHQUFMLENBQVM4RixNQUFULEdBQWtCLE1BQU0sS0FBS3ZHLElBQVgsR0FBa0IsSUFBbEIsR0FBeUIsc0JBQXpCLEdBQWtELEtBQUtTLEdBQUwsQ0FBUzhGLE1BQTdFO0FBQ0g7QUFDSixHQTNtQ0k7QUE2bUNMcUUsRUFBQUEsU0FBUyxFQUFFLG1CQUFVaEMsU0FBVixFQUFxQjtBQUM1QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsS0FBbUIsQ0FBbkI7QUFDQXBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFdBQVo7QUFDQW1JLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxTQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLHNCQUF6QixHQUFrRCxLQUFLUyxHQUFMLENBQVM4RixNQUE3RTtBQUNILEdBbG5DSTtBQW9uQ0xzRSxFQUFBQSxTQUFTLEVBQUUsbUJBQVVqQyxTQUFWLEVBQXFCckcsUUFBckIsRUFBK0JRLEdBQS9CLEVBQW9DO0FBQzNDdkIsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksWUFBWjtBQUNBLFFBQUlxSyxPQUFPLEdBQUcsS0FBZCxDQUYyQyxDQUczQztBQUNBO0FBQ0E7O0FBQ0EsU0FBSyxJQUFJekksQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR1UsR0FBcEIsRUFBeUJWLENBQUMsRUFBMUIsRUFBOEI7QUFDMUIsVUFBSXhELE9BQU8sR0FBRyxLQUFLMkUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnFHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTdDO0FBQ0EsVUFBSTVKLEtBQUssR0FBRyxLQUFLd0UsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnFHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQTNDO0FBQ0EsVUFBSTdKLEdBQUcsR0FBRyxLQUFLeUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnFHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQXpDOztBQUNBLFVBQUkvSixPQUFPLEdBQUcsQ0FBVixJQUFlNkQsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQW5DLEVBQXdDO0FBQ3BDLGFBQUs4SCxXQUFMLENBQWlCOUIsU0FBakI7QUFDQWtDLFFBQUFBLE9BQU8sR0FBRyxJQUFWO0FBQ0gsT0FIRCxNQUdPLElBQUk5TCxLQUFLLEdBQUcsQ0FBUixJQUFhMEQsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTdCLElBQW9DLEtBQUsvQyxRQUFMLENBQWMsQ0FBZCxLQUFvQixHQUE1RCxFQUFpRTtBQUNwRSxhQUFLK0ssU0FBTCxDQUFlaEMsU0FBZjtBQUNBa0MsUUFBQUEsT0FBTyxHQUFHLElBQVY7QUFDSCxPQUhNLE1BR0EsSUFBSS9MLEdBQUcsR0FBRyxDQUFOLElBQVcyRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBM0IsSUFBa0MsS0FBSy9DLFFBQUwsQ0FBYyxDQUFkLEtBQW9CLEdBQTFELEVBQStEO0FBQ2xFLGFBQUs4SyxPQUFMLENBQWEvQixTQUFiO0FBQ0FrQyxRQUFBQSxPQUFPLEdBQUcsSUFBVjtBQUNIO0FBQ0o7QUFDRDs7Ozs7Ozs7QUFRSCxHQWpwQ0k7QUFtcENMO0FBRUFDLEVBQUFBLFVBQVUsRUFBRSxvQkFBVWxMLFFBQVYsRUFBb0I7QUFDNUIsUUFBSUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWYsSUFBc0JBLFFBQVEsQ0FBQyxDQUFELENBQVIsR0FBY0EsUUFBUSxDQUFDLENBQUQsQ0FBUixHQUFjLENBQXRELEVBQXlEO0FBQ3JELFdBQUt3RSxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQUcsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEdBQWY7QUFDQUEsTUFBQUEsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLENBQWY7QUFDQSxXQUFLWSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGVBQWUsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQTFDO0FBQ0gsS0FMRCxNQUtPLENBRU47QUFDSixHQTlwQ0k7QUFncUNMeUUsRUFBQUEsVUFBVSxFQUFFLG9CQUFVcEMsU0FBVixFQUFxQnJHLFFBQXJCLEVBQStCO0FBQ3ZDLFFBQUkwSSxTQUFTLEdBQUcsS0FBS3pILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBaEI7QUFDQXFHLElBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0JxQyxTQUFTLEdBQUcsRUFBWixHQUFpQnJDLFNBQVMsQ0FBQyxDQUFELENBQTFCLEdBQWdDQSxTQUFTLENBQUMsQ0FBRCxDQUF6QyxHQUErQ0EsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQTlFOztBQUNBLFFBQUlBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFuQixFQUFzQjtBQUNsQkEsTUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQWY7QUFDSDs7QUFDRHBILElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFdBQVdpQyxJQUFJLENBQUNDLEtBQUwsQ0FBV2lHLFNBQVMsQ0FBQyxDQUFELENBQXBCLENBQXZCO0FBQ0gsR0F2cUNJO0FBeXFDTDtBQUNBc0MsRUFBQUEsUUFBUSxFQUFFLG9CQUFZO0FBQ2xCLFNBQUs3RyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQThCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFdBQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLFlBQVksS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQXZDO0FBQ0gsR0E5cUNJO0FBZ3JDTDtBQUNBNEUsRUFBQUEsU0FBUyxFQUFFLHFCQUFZO0FBQ25CLFNBQUs5RyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QsQ0FBbEQsRUFBcUQsQ0FBckQ7QUFDQThCLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLE9BQVo7QUFDQSxTQUFLQSxHQUFMLENBQVM4RixNQUFULEdBQWtCLGFBQWEsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQXhDO0FBQ0gsR0FyckNJO0FBdXJDTDZFLEVBQUFBLGVBQWUsRUFBRSx5QkFBVXhDLFNBQVYsRUFBcUJyRyxRQUFyQixFQUErQjtBQUM1QyxRQUFJMUQsT0FBTyxHQUFHLENBQUMsS0FBSzJFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsSUFBK0JxRyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsQ0FBYixDQUFoQyxFQUFpRCxFQUFqRCxFQUFxRCxHQUFyRCxDQUFkO0FBQ0EsUUFBSTVKLEtBQUssR0FBRyxDQUFDLEtBQUt3RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLEVBQXpCLElBQStCcUcsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhLENBQWIsQ0FBaEMsRUFBaUQsRUFBakQsRUFBcUQsSUFBckQsQ0FBWjtBQUNBLFFBQUk3SixHQUFHLEdBQUcsQ0FBQyxLQUFLeUUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixJQUErQnFHLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxDQUFiLENBQWhDLEVBQWlELEVBQWpELEVBQXFELElBQXJELENBQVY7QUFDQSxRQUFJNkIsSUFBSSxHQUFHLENBQUMsS0FBS2pILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBRCxFQUErQixFQUEvQixFQUFtQyxJQUFuQyxDQUFYO0FBQ0EsUUFBSXRELElBQUksR0FBRyxDQUFDLEtBQUt1RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLEVBQXpCLENBQUQsRUFBK0IsRUFBL0IsRUFBbUMsR0FBbkMsQ0FBWDtBQUNBLFFBQUkzRCxLQUFLLEdBQUcsQ0FBQyxLQUFLNEUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixFQUF6QixDQUFELEVBQStCLEVBQS9CLEVBQW1DLEdBQW5DLENBQVo7QUFDQSxRQUFJckQsTUFBTSxHQUFHLENBQUMsS0FBS3NFLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsRUFBekIsQ0FBRCxFQUErQixFQUEvQixFQUFtQyxHQUFuQyxDQUFiO0FBQ0EsUUFBSTdELElBQUksR0FBRyxDQUFDLEtBQUs4RSxTQUFMLENBQWVqQixRQUFmLEVBQXlCLENBQXpCLENBQUQsRUFBOEIsQ0FBOUIsRUFBaUMsSUFBakMsQ0FBWDtBQUNBLFFBQUk1RCxLQUFLLEdBQUcsQ0FBQyxLQUFLNkUsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFELEVBQThCLENBQTlCLEVBQWlDLElBQWpDLENBQVo7QUFDQSxRQUFJOEksUUFBUSxHQUFHLENBQUN4TSxPQUFELEVBQVVHLEtBQVYsRUFBaUJELEdBQWpCLEVBQXNCMEwsSUFBdEIsRUFBNEJ4TCxJQUE1QixFQUFrQ0wsS0FBbEMsRUFBeUNNLE1BQXpDLEVBQWlEUixJQUFqRCxFQUF1REMsS0FBdkQsQ0FBZjs7QUFDQSxTQUFLLElBQUkwRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHZ0osUUFBUSxDQUFDN0ksTUFBN0IsRUFBcUNILENBQUMsRUFBdEMsRUFBMEM7QUFDdEMsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHK0ksUUFBUSxDQUFDaEosQ0FBRCxDQUFSLENBQVksQ0FBWixDQUFwQixFQUFvQ0MsQ0FBQyxFQUFyQyxFQUF5QztBQUNyQyxZQUFJSSxJQUFJLENBQUNFLE1BQUwsS0FBZ0J5SSxRQUFRLENBQUNoSixDQUFELENBQVIsQ0FBWSxDQUFaLENBQXBCLEVBQW9DO0FBQ2hDLGVBQUtnQyxpQkFBTCxDQUF1QixLQUFLMUUsT0FBNUIsRUFBcUMsS0FBS0QsTUFBMUMsRUFBa0QyTCxRQUFRLENBQUNoSixDQUFELENBQVIsQ0FBWSxDQUFaLENBQWxELEVBQWtFLENBQWxFO0FBQ0g7QUFDSjtBQUNKO0FBQ0osR0F6c0NJO0FBMnNDTGlKLEVBQUFBLFVBQVUsRUFBRSxvQkFBVTFDLFNBQVYsRUFBcUIvRixTQUFyQixFQUFnQ04sUUFBaEMsRUFBMEM7QUFDbEQsU0FBSzZJLGVBQUwsQ0FBcUJ4QyxTQUFyQixFQUFnQ3JHLFFBQWhDOztBQUNBLFNBQUssSUFBSUYsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLbUIsU0FBTCxDQUFlakIsUUFBZixFQUF5QixDQUF6QixDQUFwQixFQUFpREYsQ0FBQyxFQUFsRCxFQUFzRDtBQUNsRCxXQUFLNkksUUFBTDtBQUNIOztBQUNELFNBQUssSUFBSTdJLEdBQUMsR0FBRyxDQUFiLEVBQWdCQSxHQUFDLEdBQUcsS0FBS21CLFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBcEIsRUFBaURGLEdBQUMsRUFBbEQsRUFBc0Q7QUFDbEQsVUFBSUssSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCLGFBQUt1SSxTQUFMO0FBQ0g7QUFFSjs7QUFDRCxRQUFJRixTQUFTLEdBQUcsS0FBS3pILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBaEI7O0FBQ0EsV0FBTzBJLFNBQVMsR0FBR3JDLFNBQVMsQ0FBQyxDQUFELENBQTVCLEVBQWlDO0FBQzdCLFdBQUt2RSxpQkFBTCxDQUF1QnhCLFNBQXZCLEVBQWtDTixRQUFsQyxFQUE0QyxDQUE1QyxFQUErQyxDQUEvQztBQUNBMEksTUFBQUEsU0FBUyxJQUFJLENBQWI7QUFDQXpKLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDJCQUFaO0FBQ0g7QUFDSixHQTV0Q0k7QUE4dENMOEssRUFBQUEsVUFBVSxFQUFFLG9CQUFVM0MsU0FBVixFQUFxQjtBQUM3QkEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixLQUFoQjtBQUNBcEgsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksV0FBV2lDLElBQUksQ0FBQzhJLEtBQUwsQ0FBVzVDLFNBQVMsQ0FBQyxDQUFELENBQXBCLENBQXZCLEVBRjZCLENBRzdCO0FBQ0gsR0FsdUNJO0FBb3VDTDZDLEVBQUFBLGdCQUFnQixFQUFFLDBCQUFVN0MsU0FBVixFQUFxQjtBQUNuQyxRQUFJNkIsSUFBSSxHQUFHLEtBQUtqSCxTQUFMLENBQWUsS0FBSzlELE1BQXBCLEVBQTRCLEVBQTVCLENBQVg7QUFDQSxRQUFJVCxJQUFJLEdBQUcsS0FBS3VFLFNBQUwsQ0FBZSxLQUFLOUQsTUFBcEIsRUFBNEIsRUFBNUIsQ0FBWDs7QUFDQSxTQUFLLElBQUkyQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHb0ksSUFBcEIsRUFBMEJwSSxDQUFDLEVBQTNCLEVBQStCO0FBQzNCLFVBQUl1RyxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWVBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUE5QixJQUFtQ2xHLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUF2RCxFQUE0RDtBQUN4RGdHLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxhQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQix5QkFBeUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQXBEO0FBQ0g7QUFDSjs7QUFDRCxTQUFLLElBQUlsRSxHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHcEQsSUFBcEIsRUFBMEJvRCxHQUFDLEVBQTNCLEVBQStCO0FBQzNCLFVBQUl1RyxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWVBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUE5QixJQUFtQ2xHLElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUF2RCxFQUE0RDtBQUN4RGdHLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsQ0FBaEI7QUFDQSxhQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQix5QkFBeUIsS0FBSzlGLEdBQUwsQ0FBUzhGLE1BQXBEO0FBQ0g7QUFDSjs7QUFDRCxRQUFJcUMsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFwQixFQUF1QjtBQUNuQixXQUFLbkksR0FBTCxDQUFTOEYsTUFBVCxHQUFrQixNQUFNLEtBQUt2RyxJQUFYLEdBQWtCLElBQWxCLEdBQXlCLGNBQXpCLEdBQTBDLEtBQUtTLEdBQUwsQ0FBUzhGLE1BQXJFOztBQUNBLFVBQUlxQyxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBbkIsRUFBc0I7QUFDbEJBLFFBQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZWxHLElBQUksQ0FBQ29HLElBQUwsQ0FBVUYsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLENBQWYsR0FBbUIsQ0FBN0IsQ0FBZixDQURrQixDQUVsQjtBQUNILE9BSEQsTUFHTztBQUNIQSxRQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWVsRyxJQUFJLENBQUNDLEtBQUwsQ0FBV2lHLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFmLEdBQW1CLENBQTlCLENBQWY7QUFDSDs7QUFDRCxVQUFJQSxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLENBQXBCLEVBQXVCO0FBQ25CQSxRQUFBQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBZjtBQUNIO0FBQ0o7QUFDSixHQS92Q0k7QUFpd0NMOEMsRUFBQUEsYUFBYSxFQUFFLHVCQUFVOUMsU0FBVixFQUFxQjtBQUNoQ0EsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixDQUFDQSxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBaEIsSUFBcUIsQ0FBckM7QUFDQUEsSUFBQUEsU0FBUyxDQUFDLENBQUQsQ0FBVCxJQUFnQixLQUFoQjtBQUNILEdBcHdDSTtBQXN3Q0wrQyxFQUFBQSxTQUFTLEVBQUUsbUJBQVUvQyxTQUFWLEVBQXFCL0YsU0FBckIsRUFBZ0NOLFFBQWhDLEVBQTBDO0FBQ2pELFNBQUt3SSxVQUFMLENBQWdCbkMsU0FBaEI7QUFDQSxTQUFLZ0QsVUFBTCxDQUFnQmhELFNBQWhCLEVBQTJCckcsUUFBM0I7QUFDSCxHQXp3Q0k7QUEyd0NMc0osRUFBQUEsUUFBUSxFQUFFLGtCQUFVakQsU0FBVixFQUFxQnJHLFFBQXJCLEVBQStCO0FBQ3JDLFFBQUkwSSxTQUFTLEdBQUcsS0FBS3pILFNBQUwsQ0FBZWpCLFFBQWYsRUFBeUIsQ0FBekIsQ0FBaEI7QUFDQSxRQUFJdUosSUFBSSxHQUFHYixTQUFTLEdBQUcsRUFBWixHQUFpQnJDLFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxDQUFoQyxHQUFvQ0EsU0FBUyxDQUFDLENBQUQsQ0FBeEQ7QUFDQSxRQUFJbUQsTUFBTSxHQUFHbkQsU0FBUyxDQUFDLENBQUQsQ0FBVCxHQUFlLEtBQUtwRixTQUFMLENBQWVqQixRQUFmLEVBQXlCLENBQXpCLENBQTVCOztBQUNBLFFBQUl1SixJQUFJLElBQUlsRCxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBM0IsRUFBOEI7QUFDMUIsV0FBS1UsVUFBTCxDQUFnQlYsU0FBaEIsRUFBMkJyRyxRQUEzQixFQUFxQ3dKLE1BQXJDO0FBQ0FELE1BQUFBLElBQUksR0FBR2IsU0FBUyxHQUFHLEVBQVosR0FBaUJyQyxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBaEMsR0FBb0NBLFNBQVMsQ0FBQyxDQUFELENBQXBEOztBQUNBLFVBQUlrRCxJQUFJLElBQUlsRCxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsQ0FBM0IsRUFBOEI7QUFDMUIsYUFBSzRCLFVBQUwsQ0FBZ0I1QixTQUFoQixFQUEyQnJHLFFBQTNCLEVBQXFDRyxJQUFJLENBQUNDLEtBQUwsQ0FBV29KLE1BQU0sR0FBRyxDQUFwQixDQUFyQztBQUNIO0FBQ0osS0FORCxNQU1PLElBQUlELElBQUksSUFBSWxELFNBQVMsQ0FBQyxDQUFELENBQVQsR0FBZSxFQUEzQixFQUErQjtBQUNsQyxXQUFLVSxVQUFMLENBQWdCVixTQUFoQixFQUEyQnJHLFFBQTNCLEVBQXFDRyxJQUFJLENBQUNDLEtBQUwsQ0FBV29KLE1BQU0sR0FBRyxDQUFwQixDQUFyQztBQUNBLFdBQUtqQyxjQUFMLENBQW9CbEIsU0FBcEIsRUFBK0JyRyxRQUEvQixFQUF5Q0csSUFBSSxDQUFDQyxLQUFMLENBQVdvSixNQUFNLEdBQUcsQ0FBcEIsQ0FBekM7QUFDQSxXQUFLbEIsU0FBTCxDQUFlakMsU0FBZixFQUEwQnJHLFFBQTFCLEVBQW9DRyxJQUFJLENBQUNDLEtBQUwsQ0FBV29KLE1BQU0sR0FBRyxDQUFwQixDQUFwQztBQUNILEtBSk0sTUFJQTtBQUNILFdBQUtqQyxjQUFMLENBQW9CbEIsU0FBcEIsRUFBK0JyRyxRQUEvQixFQUF5Q0csSUFBSSxDQUFDQyxLQUFMLENBQVdvSixNQUFNLEdBQUcsQ0FBcEIsQ0FBekM7QUFDQSxXQUFLbEIsU0FBTCxDQUFlakMsU0FBZixFQUEwQnJHLFFBQTFCLEVBQW9DRyxJQUFJLENBQUNDLEtBQUwsQ0FBV29KLE1BQU0sR0FBRyxDQUFwQixDQUFwQztBQUNIOztBQUNELFFBQUluRCxTQUFTLENBQUMsQ0FBRCxDQUFULEdBQWUsRUFBbkIsRUFBdUI7QUFDbkIsV0FBSzRCLFVBQUwsQ0FBZ0I1QixTQUFoQixFQUEyQnJHLFFBQTNCLEVBQXFDRyxJQUFJLENBQUNDLEtBQUwsQ0FBV29KLE1BQU0sR0FBRyxFQUFwQixDQUFyQztBQUNIO0FBQ0osR0FoeUNJO0FBa3lDTDtBQUNBQyxFQUFBQSxZQW55Q0ssd0JBbXlDUUMsU0FueUNSLEVBbXlDbUI7QUFDcEIsUUFBSUMsS0FBSyxHQUFHeEosSUFBSSxDQUFDQyxLQUFMLENBQVcsS0FBS2pGLFNBQUwsQ0FBZXVGLENBQWYsR0FBbUIsRUFBOUIsQ0FBWjtBQUNBLFFBQUlrSixLQUFLLEdBQUd6SixJQUFJLENBQUNDLEtBQUwsQ0FBVyxLQUFLakYsU0FBTCxDQUFlc0YsQ0FBZixHQUFtQixFQUE5QixDQUFaOztBQUVBLFFBQUlpSixTQUFTLElBQUksQ0FBakIsRUFBb0I7QUFBRTtBQUNsQkUsTUFBQUEsS0FBSztBQUNSLEtBRkQsTUFFTyxJQUFJRixTQUFTLElBQUksQ0FBakIsRUFBb0I7QUFBRTtBQUN6QkUsTUFBQUEsS0FBSztBQUNSLEtBRk0sTUFFQSxJQUFJRixTQUFTLElBQUksQ0FBakIsRUFBb0I7QUFBRTtBQUN6QkMsTUFBQUEsS0FBSztBQUNSLEtBRk0sTUFFQTtBQUFFO0FBQ0xBLE1BQUFBLEtBQUs7QUFDUjs7QUFFRCxRQUFJLEtBQUt4TSxNQUFMLENBQVl5TSxLQUFaLEVBQW1CRCxLQUFuQixLQUE2QixDQUFqQyxFQUFvQztBQUFFO0FBQ2xDLGFBQU8sS0FBUDtBQUNILEtBRkQsTUFFTztBQUNILGFBQU8sSUFBUDtBQUNIO0FBQ0osR0F0ekNJO0FBd3pDTEUsRUFBQUEsU0FBUyxFQUFFLHFCQUFXO0FBQ2xCLFFBQUl2SyxLQUFLLEdBQUcsRUFBWjtBQUNBLFFBQUl3SyxNQUFNLEdBQUczSixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLENBQWI7O0FBQ0EsUUFBSSxLQUFLb0osWUFBTCxDQUFrQkssTUFBbEIsQ0FBSixFQUErQjtBQUMzQixVQUFJQSxNQUFNLElBQUksQ0FBVixJQUFlLEtBQUszTyxTQUFMLENBQWVzRixDQUFmLElBQW9CLE1BQU0sRUFBTixHQUFXLEVBQWxELEVBQXNEO0FBQ2xEO0FBQ0FuQixRQUFBQSxLQUFLLEdBQUcsVUFBUjtBQUNBLGFBQUtGLEVBQUwsQ0FBUXNCLENBQVIsR0FBWSxDQUFaO0FBQ0EsYUFBS3RCLEVBQUwsQ0FBUXFCLENBQVIsR0FBWSxFQUFaO0FBQ0gsT0FMRCxNQUtPLElBQUlxSixNQUFNLElBQUksQ0FBVixJQUFlLEtBQUszTyxTQUFMLENBQWVzRixDQUFmLElBQW9CLEtBQUssRUFBNUMsRUFBZ0Q7QUFDbkQ7QUFDQW5CLFFBQUFBLEtBQUssR0FBRyxZQUFSO0FBQ0EsYUFBS0YsRUFBTCxDQUFRc0IsQ0FBUixHQUFZLENBQVo7QUFDQSxhQUFLdEIsRUFBTCxDQUFRcUIsQ0FBUixHQUFZLENBQUMsRUFBYjtBQUNILE9BTE0sTUFLQSxJQUFJcUosTUFBTSxJQUFJLENBQVYsSUFBZSxLQUFLM08sU0FBTCxDQUFldUYsQ0FBZixJQUFvQixLQUFLLEVBQTVDLEVBQWdEO0FBQ25EO0FBQ0FwQixRQUFBQSxLQUFLLEdBQUcsWUFBUjtBQUNBLGFBQUtGLEVBQUwsQ0FBUXNCLENBQVIsR0FBWSxDQUFDLEVBQWI7QUFDQSxhQUFLdEIsRUFBTCxDQUFRcUIsQ0FBUixHQUFZLENBQVo7QUFDSCxPQUxNLE1BS0EsSUFBSXFKLE1BQU0sSUFBSSxDQUFWLElBQWUsS0FBSzNPLFNBQUwsQ0FBZXVGLENBQWYsSUFBb0IsTUFBTSxFQUFOLEdBQVcsRUFBbEQsRUFBc0Q7QUFDekQ7QUFDQXBCLFFBQUFBLEtBQUssR0FBRyxhQUFSO0FBQ0EsYUFBS0YsRUFBTCxDQUFRc0IsQ0FBUixHQUFZLEVBQVo7QUFDQSxhQUFLdEIsRUFBTCxDQUFRcUIsQ0FBUixHQUFZLENBQVo7QUFDSDtBQUNKLEtBdEJELE1Bc0JPO0FBQ0gsV0FBS3JCLEVBQUwsQ0FBUXNCLENBQVIsR0FBWSxDQUFaO0FBQ0EsV0FBS3RCLEVBQUwsQ0FBUXFCLENBQVIsR0FBWSxDQUFaO0FBQ0g7O0FBRUQsUUFBSSxLQUFLckIsRUFBTCxDQUFRc0IsQ0FBWixFQUFlO0FBQ1gsV0FBS3ZGLFNBQUwsQ0FBZXVGLENBQWYsSUFBb0IsS0FBS3RCLEVBQUwsQ0FBUXNCLENBQTVCO0FBQ0gsS0FGRCxNQUVPLElBQUksS0FBS3RCLEVBQUwsQ0FBUXFCLENBQVosRUFBZTtBQUNsQixXQUFLdEYsU0FBTCxDQUFlc0YsQ0FBZixJQUFvQixLQUFLckIsRUFBTCxDQUFRcUIsQ0FBNUI7QUFDSDs7QUFFRCxRQUFJbkIsS0FBSixFQUFXO0FBQ1AsV0FBS0ksUUFBTCxDQUFjSixLQUFkO0FBQ0g7QUFDSixHQS8xQ0k7QUFpMkNMeUssRUFBQUEsaUJBQWlCLEVBQUUsNkJBQVc7QUFFMUIsU0FBS3ZMLFdBQUwsQ0FBaUJ3TCxRQUFqQixHQUE0QixLQUFLMU0sUUFBTCxDQUFjLENBQWQsSUFBbUIsS0FBS0EsUUFBTCxDQUFjLENBQWQsQ0FBL0M7QUFDQTs7Ozs7OztBQU9OLEdBMzJDTztBQTYyQ0wwQixFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEJDLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFVBQVVyRCxHQUFHLENBQUN1RCxRQUExQixFQURzQixDQUV0Qjs7QUFDQSxRQUFJNkwsS0FBSyxHQUFHeEcsRUFBRSxDQUFDeUcsY0FBSCxDQUFrQixjQUFsQixDQUFaO0FBQ0FqTCxJQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxhQUFhckQsR0FBRyxDQUFDc1AsT0FBN0I7O0FBQ0EsUUFBSUYsS0FBSyxDQUFDaEssTUFBTixJQUFnQixDQUFoQixJQUFxQnBGLEdBQUcsQ0FBQ3NQLE9BQXpCLElBQW9DdFAsR0FBRyxDQUFDdUQsUUFBNUMsRUFBc0Q7QUFDbERhLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFVBQVo7QUFDQXJELE1BQUFBLEdBQUcsQ0FBQ3VELFFBQUosR0FBZSxLQUFmO0FBQ0F2RCxNQUFBQSxHQUFHLENBQUNzUCxPQUFKLEdBQWMsS0FBZDtBQUNILEtBSkQsTUFJTztBQUNIO0FBQ0E7QUFDQSxVQUFJO0FBQ0EsWUFBSUYsS0FBSyxHQUFHeEcsRUFBRSxDQUFDeUcsY0FBSCxDQUFrQixjQUFsQixDQUFaOztBQUNBLFlBQUlELEtBQUosRUFBVztBQUNUO0FBQ0F2UCxVQUFBQSxZQUFZLEdBQUd1UCxLQUFmO0FBQ0Q7QUFDSixPQU5ELENBTUUsT0FBT0csQ0FBUCxFQUFVO0FBQ1I7QUFDQW5MLFFBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDJCQUFaO0FBQ0g7O0FBQ0QsVUFBSTtBQUNBLFlBQUkrTCxLQUFLLEdBQUd4RyxFQUFFLENBQUN5RyxjQUFILENBQWtCLGdCQUFsQixDQUFaOztBQUNBLFlBQUlELEtBQUosRUFBVztBQUNUO0FBQ0F0UCxVQUFBQSxjQUFjLEdBQUdzUCxLQUFqQjtBQUNEO0FBQ0osT0FORCxDQU1FLE9BQU9HLENBQVAsRUFBVTtBQUNSO0FBQ0FuTCxRQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSw2QkFBWjtBQUNIOztBQUNELFVBQUk7QUFDQSxZQUFJK0wsS0FBSyxHQUFHeEcsRUFBRSxDQUFDeUcsY0FBSCxDQUFrQixZQUFsQixDQUFaOztBQUNBLFlBQUlELEtBQUosRUFBVztBQUNUO0FBQ0FyUCxVQUFBQSxVQUFVLEdBQUdxUCxLQUFiO0FBQ0Q7QUFDSixPQU5ELENBTUUsT0FBT0csQ0FBUCxFQUFVO0FBQ1I7QUFDQW5MLFFBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLHdCQUFaO0FBQ0g7O0FBRURlLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLGNBQVo7QUFDQWUsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVl4RCxZQUFaO0FBQ0F1RSxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWSxnQkFBWjtBQUNBZSxNQUFBQSxPQUFPLENBQUNmLEdBQVIsQ0FBWXZELGNBQVo7QUFDQXNFLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLFlBQVo7QUFDQWUsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVl0RCxVQUFaLEVBdkNHLENBeUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFLdUMsTUFBTCxHQUFjekMsWUFBZCxDQS9DRyxDQWlESDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFLNEMsUUFBTCxHQUFnQjNDLGNBQWhCO0FBQ0EsV0FBSzhDLElBQUwsR0FBWTdDLFVBQVo7QUFDSDtBQUNKLEdBcDdDSTtBQXM3Q0x5UCxFQUFBQSxjQUFjLEVBQUUsMEJBQVk7QUFDeEIsUUFBSSxLQUFLL00sUUFBTCxDQUFjLENBQWQsS0FBb0IsQ0FBcEIsSUFBeUIsS0FBS2UsYUFBTCxJQUFzQixLQUFuRCxFQUEwRDtBQUN0RFksTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksTUFBWjtBQUNBLFdBQUtFLFFBQUwsQ0FBY2UsTUFBZCxHQUF1QixJQUF2QjtBQUNBLFdBQUtkLGFBQUwsR0FBcUIsSUFBckI7QUFDQSxXQUFLeUUsWUFBTDtBQUNBLFdBQUt4RSxZQUFMLEdBQW9CLEtBQUtiLElBQXpCO0FBQ0EsV0FBS1UsY0FBTCxDQUFvQjZGLE1BQXBCLEdBQTZCLG9CQUFvQixXQUFwQixHQUFrQyxLQUFLMUYsWUFBdkMsR0FBc0QsR0FBbkY7QUFDTjtBQUNELEdBLzdDSTtBQWk4Q0x3RSxFQUFBQSxZQUFZLEVBQUUsd0JBQVk7QUFDdEJqSSxJQUFBQSxHQUFHLENBQUN1RCxRQUFKLEdBQWUsS0FBS0MsYUFBcEI7QUFDQTNELElBQUFBLFlBQVksR0FBRyxLQUFLeUMsTUFBcEIsQ0FGc0IsQ0FHdEI7O0FBQ0EsUUFBSTtBQUNBc0csTUFBQUEsRUFBRSxDQUFDNkcsY0FBSCxDQUFrQixjQUFsQixFQUFrQzVQLFlBQWxDO0FBQ0gsS0FGRCxDQUVFLE9BQU8wUCxDQUFQLEVBQVU7QUFDUm5MLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDJCQUFaO0FBQ0g7O0FBQ0RlLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLDRCQUFaO0FBQ0FlLElBQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZeEQsWUFBWjtBQUVBQyxJQUFBQSxjQUFjLEdBQUcsS0FBSzJDLFFBQXRCLENBWnNCLENBYXRCOztBQUNBLFFBQUk7QUFDQW1HLE1BQUFBLEVBQUUsQ0FBQzZHLGNBQUgsQ0FBa0IsZ0JBQWxCLEVBQW9DM1AsY0FBcEM7QUFDSCxLQUZELENBRUUsT0FBT3lQLENBQVAsRUFBVTtBQUNSbkwsTUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksNkJBQVo7QUFDSDs7QUFDRGUsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVksNkJBQVo7QUFDQWUsSUFBQUEsT0FBTyxDQUFDZixHQUFSLENBQVl2RCxjQUFaO0FBRUFDLElBQUFBLFVBQVUsR0FBRyxLQUFLNkMsSUFBbEI7O0FBQ0EsUUFBSTtBQUNBZ0csTUFBQUEsRUFBRSxDQUFDNkcsY0FBSCxDQUFrQixZQUFsQixFQUFnQzFQLFVBQWhDO0FBQ0gsS0FGRCxDQUVFLE9BQU93UCxDQUFQLEVBQVU7QUFDUm5MLE1BQUFBLE9BQU8sQ0FBQ2YsR0FBUixDQUFZLHdCQUFaO0FBQ0g7QUFHSixHQS85Q0k7QUFpK0NMcU0sRUFBQUEsTUFqK0NLLGtCQWkrQ0VDLEVBaitDRixFQWkrQ007QUFDUCxRQUFJLEtBQUtuTSxhQUFULEVBQXdCO0FBQ3BCO0FBQ0g7O0FBQ0QsU0FBS1gsS0FBTDtBQUNBLFNBQUthLFFBQUw7O0FBQ0EsUUFBSSxLQUFLYixLQUFMLEdBQWEsRUFBYixJQUFtQixDQUF2QixFQUEwQjtBQUN0QixXQUFLaUosV0FBTCxDQUFpQixLQUFLckosUUFBdEI7QUFDSDs7QUFDRCxRQUFJLEtBQUtJLEtBQUwsSUFBYyxHQUFsQixFQUF1QjtBQUNuQixXQUFLNEwsUUFBTCxDQUFjLEtBQUtoTSxRQUFuQixFQUE2QixLQUFLSCxNQUFsQztBQUNILEtBRkQsTUFFTyxJQUFJLEtBQUtPLEtBQUwsSUFBYyxHQUFsQixFQUF1QjtBQUMxQixVQUFJLEtBQUt3RCxjQUFMLENBQW9CLEtBQUsvRCxNQUF6QixFQUFpQyxDQUFqQyxDQUFKLEVBQXlDO0FBQ3JDLGFBQUtxTCxVQUFMLENBQWdCLEtBQUtsTCxRQUFyQjtBQUNIO0FBQ0osS0FKTSxNQUlBLElBQUksS0FBS0ksS0FBTCxJQUFjLEdBQWxCLEVBQXVCO0FBQzFCLFdBQUt3TCxnQkFBTCxDQUFzQixLQUFLNUwsUUFBM0I7QUFDQSxXQUFLbUwsVUFBTCxDQUFnQixLQUFLbkwsUUFBckIsRUFBK0IsS0FBS0gsTUFBcEM7QUFDQSxXQUFLNkwsVUFBTCxDQUFnQixLQUFLMUwsUUFBckI7QUFDSCxLQUpNLE1BSUEsSUFBSSxLQUFLSSxLQUFMLElBQWMsR0FBbEIsRUFBdUI7QUFDMUIsV0FBS3FMLFVBQUwsQ0FBZ0IsS0FBS3pMLFFBQXJCLEVBQStCLEtBQUtGLE9BQXBDLEVBQTZDLEtBQUtELE1BQWxEO0FBQ0EsV0FBS2dNLGFBQUwsQ0FBbUIsS0FBSzdMLFFBQXhCO0FBQ0EsV0FBS0ksS0FBTCxHQUFhLENBQWI7QUFDQSxXQUFLRCxJQUFMO0FBQ0g7O0FBQ0QsU0FBS3BDLFVBQUw7O0FBQ0EsUUFBSSxLQUFLQSxVQUFMLEdBQWtCLEVBQXRCLEVBQTBCO0FBQ3RCLFdBQUt3TyxTQUFMO0FBQ0EsV0FBS3hPLFVBQUwsR0FBa0IsQ0FBbEI7QUFDSDs7QUFDRCxRQUFJLEtBQUtrRCxRQUFMLEdBQWdCLElBQWhCLElBQXdCLENBQTVCLEVBQStCO0FBQzNCLFdBQUtMLEdBQUwsQ0FBUzhGLE1BQVQsR0FBa0IsRUFBbEI7QUFDQSxXQUFLekYsUUFBTCxHQUFnQixDQUFoQjtBQUNIOztBQUVELFNBQUt0QixTQUFMLENBQWUrRyxNQUFmLEdBQXdCLFNBQVMsS0FBSzFHLFFBQUwsQ0FBYyxFQUFkLENBQWpDO0FBQ0EsU0FBS1YsY0FBTCxDQUFvQm9ILE1BQXBCLEdBQTZCLFNBQVMsS0FBSzFHLFFBQUwsQ0FBYyxDQUFkLENBQXRDO0FBQ0EsU0FBS1IsUUFBTCxDQUFja0gsTUFBZCxHQUF1QixTQUFTN0QsSUFBSSxDQUFDOEksS0FBTCxDQUFXLEtBQUszTCxRQUFMLENBQWMsQ0FBZCxDQUFYLENBQWhDLENBckNPLENBc0NQOztBQUNBLFNBQUtOLFFBQUwsQ0FBY2dILE1BQWQsR0FBdUIsU0FBUzdELElBQUksQ0FBQzhJLEtBQUwsQ0FBVyxLQUFLM0wsUUFBTCxDQUFjLENBQWQsSUFBbUIsSUFBOUIsSUFBc0MsSUFBdEUsQ0F2Q08sQ0F3Q1A7O0FBQ0EsU0FBS1AsWUFBTCxDQUFrQmlILE1BQWxCLEdBQTJCLFNBQVMsS0FBSzFHLFFBQUwsQ0FBYyxDQUFkLENBQXBDO0FBQ0EsU0FBS0osU0FBTCxDQUFlOEcsTUFBZixHQUF3QixLQUFLMUcsUUFBTCxDQUFjLENBQWQsSUFBbUIsR0FBbkIsR0FBeUIsS0FBS0EsUUFBTCxDQUFjLENBQWQsQ0FBakQ7QUFDQSxTQUFLeU0saUJBQUw7QUFDQSxTQUFLTSxjQUFMO0FBQ0g7QUE5Z0RJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIu+7v3ZhciBnbG9iYWxNYXBLZXkgPSBbXTtcclxudmFyIGdsb2JhbEdhbWVEYXRhID0gW107XHJcbnZhciBnbG9iYWxZZWFyID0gMDtcclxuXHJcbnZhciBjb20gPSByZXF1aXJlKCdkYXRhJyk7IFxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGh1bWFuTm9kZTogY2MuTm9kZSxcclxuICAgICAgICBodW1hblRpbWVyOiAwLFxyXG4gICAgICAgIGF1ZGlvQmdtOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgYXVkaW9DbGljazogY2MuQXVkaW9DbGlwLFxyXG4gICAgICAgIG1hcE5vZGU6IGNjLk5vZGUsXHJcbiAgICAgICAgd2F0ZXI6IGNjLlByZWZhYiwgLy93YXRlciAwXHJcbiAgICAgICAgc2FuZDogY2MuUHJlZmFiLCAvL3NhbmQgMVxyXG4gICAgICAgIGdyYXNzOiBjYy5QcmVmYWIsIC8vZ3Jhc3MgMlxyXG4gICAgICAgIHRvd246IGNjLlByZWZhYiwgLy90b3duIDNcclxuICAgICAgICBjcm9wOiBjYy5QcmVmYWIsIC8vY3JvcCA0XHJcbiAgICAgICAgd2hlYXQ6IGNjLlByZWZhYiwgLy93aGVhdCA1XHJcbiAgICAgICAgdm9jYW46IGNjLlByZWZhYiwgLy92b2NhbiA2XHJcbiAgICAgICAgc3RvbmU6IGNjLlByZWZhYiwgLy9zdG9uZSA3XHJcbiAgICAgICAgdHJlZTogY2MuUHJlZmFiLCAvLyB0cmVlIDhcclxuICAgICAgICBmcnVpdDogY2MuUHJlZmFiLCAvL2ZydWl0IDlcclxuICAgICAgICBiZXJyeTogY2MuUHJlZmFiLCAvL2JlcnJ5IDEwXHJcbiAgICAgICAgY2hpY2tlbjogY2MuUHJlZmFiLCAvL2NoaWNrZW4gMTFcclxuICAgICAgICBkb2c6IGNjLlByZWZhYiwgLy9kb2cgMTJcclxuICAgICAgICBjb3c6IGNjLlByZWZhYiwgLy9jb3cgMTNcclxuICAgICAgICBzaGVlcDogY2MuUHJlZmFiLCAvL3NoZWVwIDE0XHJcbiAgICAgICAgbGlvbjogY2MuUHJlZmFiLCAvLyBsaW9uIDE1XHJcbiAgICAgICAgcG9pc29uOiBjYy5QcmVmYWIsIC8vYmVycnkgMTZcclxuICAgICAgICBwb3B1bGF0aW9uVGV4dDogY2MuTGFiZWwsXHJcbiAgICAgICAgZm9vZFRleHQ6IGNjLkxhYmVsLFxyXG4gICAgICAgIHJlc291cmNlVGV4dDogY2MuTGFiZWwsXHJcbiAgICAgICAgdGVjaFRleHQ6IGNjLkxhYmVsLFxyXG4gICAgICAgIExldmVsVGV4dDogY2MuTGFiZWwsXHJcbiAgICAgICAgcG93ZXJUZXh0OiBjYy5MYWJlbCxcclxuICAgICAgICBtYXBLZXk6IFtdLFxyXG4gICAgICAgIG5vZGVLZXk6IFtdLFxyXG4gICAgICAgIHByZWZhYktleTogW10sXHJcbiAgICAgICAgZ2FtZURhdGE6IFtdLFxyXG4gICAgICAgIHNpemVYOiAyMCxcclxuICAgICAgICBzaXplWTogMjAsXHJcbiAgICAgICAgdGltZTogMCwgLy8geWVhciBudW1cclxuICAgICAgICBmcmFtZTogMCxcclxuICAgICAgICBidXR0b24xOiBjYy5CdXR0b24sXHJcbiAgICAgICAgYnV0dG9uMjogY2MuQnV0dG9uLFxyXG4gICAgICAgIGJ1dHRvbjM6IGNjLkJ1dHRvbixcclxuICAgICAgICBidXR0b240OiBjYy5CdXR0b24sXHJcbiAgICAgICAgYnV0dG9uNTogY2MuQnV0dG9uLFxyXG4gICAgICAgIGJ1dHRvbjY6IGNjLkJ1dHRvbixcclxuICAgICAgICBsb2c6IGNjLkxhYmVsLFxyXG4gICAgICAgIGdhbWVPdmVyU3RyaW5nOiBjYy5MYWJlbCxcclxuICAgICAgICBnYW1lT3ZlcjpjYy5Ob2RlLFxyXG4gICAgICAgIGdhbWVPdmVyT3JOb3Q6IGZhbHNlLFxyXG4gICAgICAgIGdhbWVPdmVyVGltZTogMCxcclxuICAgICAgICBsb2dmcmFtZTogMCxcclxuICAgICAgICBwcm9ncmVzc0Jhcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Qcm9ncmVzc0JhcixcclxuXHRcdH0sXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMuYXVkaW9CZ20sIHRydWUsIDEpO1xyXG4gICAgICAgIHRoaXMucHJlZmFiS2V5ID0gW3RoaXMud2F0ZXIsIHRoaXMuc2FuZCwgdGhpcy5ncmFzcywgdGhpcy50b3duLCB0aGlzLmNyb3AsIHRoaXMud2hlYXQsIHRoaXMudm9jYW4sIHRoaXMuc3RvbmUsIHRoaXMudHJlZSwgdGhpcy5mcnVpdCwgdGhpcy5iZXJyeSwgdGhpcy5jaGlja2VuLCB0aGlzLmRvZywgdGhpcy5jb3csIHRoaXMuc2hlZXAsIHRoaXMubGlvbiwgdGhpcy5wb2lzb25dO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgMCAgICAgICAgICAxICAgICAgICAgIDIgICAgICAgICAgIDMgICAgICAgICAgNCAgICAgICAgICA1ICAgICAgICAgICA2ICAgICAgICAgICA3ICAgICAgICAgICA4ICAgICAgICAgIDkgICAgICAgICAgIDEwICAgICAgICAgIDExICAgICAgICAgICAgMTIgICAgICAgIDEzICAgICAgICAgMTQgICAgICAgICAgMTUgICAgICAgIDE2XHJcbiAgICAgICAgdGhpcy5nYW1lRGF0YSA9IFsxMCwgMCwgMzAwLCAwLCAxLCAxLCBbMCwgMCwgMCwgMCwgMF0sIDEwMCwgMTAwLCAwLCAxMDAsIDBdO1xyXG4gICAgICAgIC8vZ2FtZURhdGEgW3BvcHVsYXRpb24sIGhvdXNlLCBmb29kLCByZXNvdXJjZSwgdGVjaCwgbXVsdGlwbGllciwgW2NoaWNrZW4sIGRvZywgY293LCBzaGVlcCwgbGlvbl0sIHBvd2VyLCBwb3dlck1heCwgY3VycmVudEV4cCwgRXhwTmVlZCwgR29kTGV2ZWxdXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgMCAgICAgICAgICAxICAgICAgMiAgICAgICAzICAgICAgIDQgICAgICAgNSAgICAgICAgICAgICAgICAgICAgIDYgICAgICAgICAgICAgICAgICAgICA3ICAgICAgIDggICAgICAgICAgIDkgICAgICAgIDEwICAgICAgICAxMVxyXG4gICAgICAgIHRoaXMuaW5pdEFycmF5KHRoaXMubWFwS2V5LCB0aGlzLnNpemVYLCB0aGlzLnNpemVZKTtcclxuICAgICAgICB0aGlzLmluaXRBcnJheSh0aGlzLm5vZGVLZXksIHRoaXMuc2l6ZVgsIHRoaXMuc2l6ZVkpO1xyXG4gICAgICAgIHRoaXMud29ybGRHZW4odGhpcy5tYXBLZXkpO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coJ3Jlc3RhcnRPck5vdCcpO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coY29tLnJlc3RhcnQpO1xyXG4gICAgICAgIHRoaXMucmVhZFVzZXJEYXRhKCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhbWVPdmVyID0nICsgdGhpcy5nYW1lT3Zlck9yTm90KTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKHRoaXMubWFwS2V5KTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgIHRoaXMubG9hZE1hcCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5KTtcclxuICAgICAgICB0aGlzLmdhbWVPdmVyLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuc3AgPSBjYy52MigwLCAwKTsgXHJcbiAgICAgICAgdGhpcy5zdGF0ZSA9ICcnO1xyXG4gICAgICAgIHRoaXMuaHVtYW5BbmkgPSB0aGlzLmh1bWFuTm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gc2V0IHN0YXRlIGZvciBodW1hbiBtb3ZpbmdcclxuICAgIHNldFN0YXRlKHN0YXRlKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUgIT0gc3RhdGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zdGF0ZSA9IHN0YXRlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmh1bWFuQW5pLnBsYXkodGhpcy5zdGF0ZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vaW5pdGlhbCBhbiBlbXB0eSBhcnJheVxyXG4gICAgaW5pdEFycmF5OiBmdW5jdGlvbiAoYXJyYXksIHJvdywgY29sdW1lKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3c7IGkrKykge1xyXG4gICAgICAgICAgICBhcnJheVtpXSA9IFtdO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGNvbHVtZTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheVtpXVtqXSA9IG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZ2VuZXJhdGUgd29ybGQgbWFwXHJcbiAgICB3b3JsZEdlbjogZnVuY3Rpb24gKGFycmF5TWFwKSB7XHJcbiAgICAgICAgLy9zZXR0aW5nIGEgc2VhIGJhY2tncm91bmRcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5TWFwLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgYXJyYXlNYXBbaV0ubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBpdGVtID0gMDtcclxuICAgICAgICAgICAgICAgIGFycmF5TWFwW2ldW2pdID0gaXRlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL2FkZCBzYW5kIGFzIHRoZSBpc2xhbmRcclxuICAgICAgICBmb3IgKGxldCBpID0gYXJyYXlNYXAubGVuZ3RoIC8gMiAtIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSkgLSAxOyBpIDwgYXJyYXlNYXAubGVuZ3RoIC8gMiArIChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSkgKyAxOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IGFycmF5TWFwW2ldLmxlbmd0aCAvIDIgLSAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNSkpIC0gMTsgaiA8IGFycmF5TWFwW2ldLmxlbmd0aCAvIDIgKyAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNSkpICsgMTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheU1hcFtpXVtqXSA9IDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy9hZGQgYSBzaW5nbGUgZ3Jhc3NsYW5kXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IGFycmF5TWFwLmxlbmd0aCAvIDIgLSAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMikpIC0gMTsgaSA8IGFycmF5TWFwLmxlbmd0aCAvIDIgKyAoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMikpICsgMTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSBhcnJheU1hcFtpXS5sZW5ndGggLyAyIC0gKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIpKSAtIDE7IGogPCBhcnJheU1hcFtpXS5sZW5ndGggLyAyICsgKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIpKSArIDE7IGorKykge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlNYXBbaV1bal0gPSAyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFycmF5TWFwW2FycmF5TWFwLmxlbmd0aCAvIDJdW2FycmF5TWFwWzBdLmxlbmd0aCAvIDJdID0gMlxyXG4gICAgfSxcclxuXHJcbiAgICAvL2xvYWQgbWFwIGZyb20ga2V5XHJcbiAgICBsb2FkTWFwOiBmdW5jdGlvbiAoYXJyYXlOb2RlLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXlNYXAubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBhcnJheU1hcFtpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlOb2RlW2ldW2pdID0gdGhpcy5pbml0Tm9kZShhcnJheU1hcFtpXVtqXSwgaSwgaiwgMzIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL2FkZCBub2RlIGFzIGNoaWxkXHJcbiAgICBpbml0Tm9kZTogZnVuY3Rpb24gKG51bSwgeSwgeCwgc2l6ZSkge1xyXG4gICAgICAgIGxldCBpdGVtID0gbnVsbDtcclxuICAgICAgICBpdGVtID0gY2MuaW5zdGFudGlhdGUodGhpcy5wcmVmYWJLZXlbbnVtXSk7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uID0gY2MudjIoeCAqIHNpemUgKyBzaXplIC8gMiwgeSAqIHNpemUgKyBzaXplIC8gMik7XHJcbiAgICAgICAgaXRlbS5zZXRQb3NpdGlvbihwb3NpdGlvbik7XHJcbiAgICAgICAgaXRlbS5uYW1lID0geSArICcwMCcgKyB4O1xyXG4gICAgICAgIHRoaXMubWFwTm9kZS5hZGRDaGlsZChpdGVtKTtcclxuICAgICAgICByZXR1cm4gaXRlbTtcclxuICAgIH0sXHJcblxyXG4gICAgLy9udW1iZXIgb2YgaXRlbVxyXG4gICAgbnVtT2ZJdGVtOiBmdW5jdGlvbiAoYXJyYXksIG51bSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KGFycmF5LCBudW0pKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmZpbmROb2RlKGFycmF5LCBudW0pLmxlbmd0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZmluZCBpZiB0aGUgbm9kZSBleGlzdFxyXG4gICAgY2hlY2tOb2RlRXhpc3Q6IGZ1bmN0aW9uIChhcnJheSwgbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IGlmRmluZCA9IGZhbHNlO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBhcnJheVtpXS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGFycmF5W2ldW2pdID09IG51bWJlcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmRmluZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGlmRmluZDtcclxuICAgIH0sXHJcblxyXG4gICAgLy9maW5kIHRoZSBub2RlIHdpdGggdGhlIGtleSBhbmQgcmV0dXJuIGFuIGFycmF5XHJcbiAgICBmaW5kTm9kZTogZnVuY3Rpb24gKGFycmF5LCBudW1iZXIpIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdChhcnJheSwgbnVtYmVyKSkge1xyXG4gICAgICAgICAgICBsZXQgYXJyYXlUb1JldHVybiA9IFtdO1xyXG4gICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGFycmF5W2ldLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFycmF5W2ldW2pdID09IG51bWJlcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcnJheVRvUmV0dXJuW2NvdW50XSA9IFtpLCBqXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGFycmF5VG9SZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NoZWNrIGlmIHRoZSBjdXJyZW50IGxvY2F0aW9uIGlzIGluIGJvdW5kXHJcbiAgICBpbkJvdW5kOiBmdW5jdGlvbiAoeSwgeCkge1xyXG4gICAgICAgIGlmICh5IDwgMCB8fCB5ID49IHRoaXMuc2l6ZVkgfHwgeCA8IDAgfHwgeCA+PSB0aGlzLnNpemVYKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9yZXBsYWNlIHdpdGggbm9kZSBieSBjb3JyZWRpbmF0ZVxyXG4gICAgcmVwbGFjZU5vZGVCeUNvb3JkaW5hdGU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwLCB5LCB4LCBuZXdOdW0pIHtcclxuICAgICAgICBsZXQgbm9kZVRvRGVzdG9yeSA9IHRoaXMubWFwTm9kZS5nZXRDaGlsZEJ5TmFtZSh5ICsgJzAwJyArIHgpO1xyXG4gICAgICAgIG5vZGVUb0Rlc3RvcnkuZGVzdHJveSgpO1xyXG4gICAgICAgIGFycmF5Tm9kZVt5XVt4XSA9IHRoaXMuaW5pdE5vZGUobmV3TnVtLCB5LCB4LCAzMik7XHJcbiAgICAgICAgYXJyYXlNYXBbeV1beF0gPSBuZXdOdW07XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcmVwbGFjZXcgYSBzaW5nbGUgYmxvY2sgb2Ygb3JnZW5OdW0gdHlwZSB0byBuZXdOdW1cclxuICAgIHJlcGxhY2VOb2RlQnlLaW5kOiBmdW5jdGlvbiAoYXJyYXlOb2RlLCBhcnJheU1hcCwgb3JpZ2VuTnVtLCBuZXdOdW0pIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdChhcnJheU1hcCwgb3JpZ2VuTnVtKSkge1xyXG4gICAgICAgICAgICBsZXQgbGlzdE9mSXRlbSA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIG9yaWdlbk51bSk7XHJcbiAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlDb29yZGluYXRlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIGxpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXSwgbmV3TnVtKTtcclxuICAgICAgICAgICAgcmV0dXJuIFtsaXN0T2ZJdGVtW2luZGV4XVswXSwgbGlzdE9mSXRlbVtpbmRleF1bMV1dO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9yZXBsYWNlIGFsbCBub2RlIHdpdGggXHJcbiAgICByZXBsYWNlQWxsOiBmdW5jdGlvbiAoYXJyYXlOb2RlLCBhcnJheU1hcCwgb3JpZ2VuTnVtLCBuZXdOdW0pIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdChhcnJheU1hcCwgb3JpZ2VuTnVtKSkge1xyXG4gICAgICAgICAgICBsZXQgcmVwbGFjZUFycmF5ID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgb3JpZ2VuTnVtKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXBsYWNlQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUNvb3JkaW5hdGUoYXJyYXlOb2RlLCBhcnJheU1hcCwgcmVwbGFjZUFycmF5W2ldWzBdLCByZXBsYWNlQXJyYXlbaV1bMV0sIG5ld051bSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vY2hlY2sgc3Vycm91bmRpbmcgYmxvY2tzXHJcbiAgICBzdXJDaGVjazogZnVuY3Rpb24gKGFycmF5LCB5LCB4LCBudW1Ub1JlcGxhY2UpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gLTE7IGkgPCAyOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IC0xOyBqIDwgMjsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5pbkJvdW5kKHkgKyBpLCB4ICsgaikpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoYXJyYXlbeSArIGldW3ggKyBqXSA9PSBudW1Ub1JlcGxhY2UpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgLy9yZXBsYWNlIHggbnVtYmVyIG9mIGJsb2NrIHdpdGggJ29yaWdlbk51bScgdHlwZSB0aGF0IHN1cnJvdW5kICh4LHkpIGJsb2NrIHdpdGggJ3JlcGxhY2VOdW0nIHR5cGVcclxuICAgIHN1clJlcGxhY2VTaW5nbGVPZlR5cGU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwLCB5LCB4LCBvcmlnZW5OdW0sIHJlcGxhY2VOdW0pIHtcclxuICAgICAgICAvL2dpdmVzIGEgcGxhY2VtZW50IC0xLCAwLCAxXHJcbiAgICAgICAgbGV0IG1vdmVYID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgIGxldCBtb3ZlWSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpIC0gMTtcclxuICAgICAgICBsZXQgbmV3WCA9IHggKyBtb3ZlWDtcclxuICAgICAgICBsZXQgbmV3WSA9IHkgKyBtb3ZlWTtcclxuICAgICAgICBpZiAodGhpcy5zdXJDaGVjayh0aGlzLm1hcEtleSwgeSwgeCwgb3JpZ2VuTnVtKSkge1xyXG4gICAgICAgICAgICAvL3doaWxlIHRoZSBzdXJyb3VuZGluZyBub2RlIGlzIG5vdCB0aGUgb3JpZ2VuYWwgbm9kZSB3ZSB3YW50IHRvIHJlcGxhY2VcclxuICAgICAgICAgICAgd2hpbGUgKGFycmF5TWFwW25ld1ldW25ld1hdICE9IG9yaWdlbk51bSB8fCAhdGhpcy5pbkJvdW5kKG5ld1ksIG5ld1gpKSB7XHJcbiAgICAgICAgICAgICAgICBtb3ZlWCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpIC0gMTtcclxuICAgICAgICAgICAgICAgIG1vdmVZID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgICAgICAgICAgbmV3WCA9IHggKyBtb3ZlWDtcclxuICAgICAgICAgICAgICAgIG5ld1kgPSB5ICsgbW92ZVk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5Q29vcmRpbmF0ZShhcnJheU5vZGUsIGFycmF5TWFwLCBuZXdZLCBuZXdYLCByZXBsYWNlTnVtKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcmVwbGFjZSB4IG51bWJlciBvZiBibG9jayB0aGF0IHN1cnJvdW5kICh4LHkpIGJsb2NrIHdpdGggJ3JlcGxhY2VOdW0nIHR5cGVcclxuICAgIHN1clJlcGxhY2VTaW5nbGU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwLCB5LCB4LCByZXBsYWNlTnVtKSB7XHJcbiAgICAgICAgLy9naXZlcyBhIHBsYWNlbWVudCAtMSwgMCwgMVxyXG4gICAgICAgIGxldCBtb3ZlWCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpIC0gMTtcclxuICAgICAgICBsZXQgbW92ZVkgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKSAtIDE7XHJcbiAgICAgICAgbGV0IG5ld1ggPSB4ICsgbW92ZVg7XHJcbiAgICAgICAgbGV0IG5ld1kgPSB5ICsgbW92ZVk7XHJcbiAgICAgICAgd2hpbGUgKChtb3ZlWCA9PSAwICYmIG1vdmVZID09IDApIHx8ICF0aGlzLmluQm91bmQobmV3WSwgbmV3WCkpIHtcclxuICAgICAgICAgICAgbW92ZVggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKSAtIDE7XHJcbiAgICAgICAgICAgIG1vdmVZID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMykgLSAxO1xyXG4gICAgICAgICAgICBuZXdYID0geCArIG1vdmVYO1xyXG4gICAgICAgICAgICBuZXdZID0geSArIG1vdmVZO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlDb29yZGluYXRlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIG5ld1ksIG5ld1gsIHJlcGxhY2VOdW0pO1xyXG4gICAgfSxcclxuIFxyXG4gICAgY2xpY2tCYWNrSG9tZUJ1dHRvbjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdyZXR1cm4gdG8gbWFpbiBwYWdlJyk7XHJcbiAgICAgICAgdGhpcy5zYXZlVXNlckRhdGEoKTtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wQWxsKCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwid2VsY29tZVwiKTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGNsaWNrU2hhcmVCdXR0b246IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjYW52YXMudG9UZW1wRmlsZVBhdGgoe1xyXG4gICAgICAgICAgICBkZXN0V2lkdGg6IDgwMCxcclxuICAgICAgICAgICAgZGVzdEhlaWdodDogNjQwLFxyXG4gICAgICAgICAgICBzdWNjZXNzIChyZXMpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Y+v5Lul5L+d5a2Y6K+l5oiq5bGP5Zu+54mHICBcIixyZXMpO1xyXG4gICAgICAgICAgICAgICAgd3guc2hhcmVBcHBNZXNzYWdlKHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCLmrKLov47lj4Lop4LmiJHnmoTlspvlsb/vvZ5cIixcclxuICAgICAgICAgICAgICAgICAgICBpbWFnZVVybDogcmVzLnRlbXBGaWxlUGF0aCxcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzKHJlcyl7fSxcclxuICAgICAgICAgICAgICAgICAgICBmYWlsKCl7fVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuXHJcbiBcclxuICAgIC8vYWN0aW9ucyAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblxyXG4gICAgLy9jbGljayBidXR0b24gXCIxXCJcclxuICAgIGNsaWNrQnV0dG9uMTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0NsaWNrLCBmYWxzZSwgMSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZURhdGFbN10gPCB0aGlzLmdhbWVEYXRhWzhdKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10gPSAwO1xyXG4gICAgICAgIHRoaXMuYWN0aW9uMSgpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy9jbGljayBidXR0b24gXCIyXCJcclxuICAgIGNsaWNrQnV0dG9uMjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0NsaWNrLCBmYWxzZSwgMSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZURhdGFbN10gPCA2MCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5rOV5Yqb5YC85LiN6Laz77yM54K55Ye75peg5pWIXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmdhbWVEYXRhWzddLT02MFxyXG4gICAgICAgIHRoaXMuYWN0aW9uMigpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy9jbGljayBidXR0b24gXCIzXCJcclxuICAgIGNsaWNrQnV0dG9uMzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0NsaWNrLCBmYWxzZSwgMSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZURhdGFbN10gPCA0MCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5rOV5Yqb5YC85LiN6Laz77yM54K55Ye75peg5pWIXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmdhbWVEYXRhWzddLT00MFxyXG4gICAgICAgIHRoaXMuYWN0aW9uMygpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy9jbGljayBidXR0b24gXCI0XCJcclxuICAgIGNsaWNrQnV0dG9uNDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0NsaWNrLCBmYWxzZSwgMSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZURhdGFbN10gPCAyMCArIHRoaXMuZ2FtZURhdGFbMTFdKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10tPTIwICsgdGhpcy5nYW1lRGF0YVsxMV07XHJcbiAgICAgICAgdGhpcy5hY3Rpb240KCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2NsaWNrIGJ1dHRvbiBcIjVcIlxyXG4gICAgY2xpY2tCdXR0b241OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmF1ZGlvQ2xpY2ssIGZhbHNlLCAxKTtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVs3XSA8IDMwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfms5XlipvlgLzkuI3otrPvvIzngrnlh7vml6DmlYhcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbN10tPTMwO1xyXG4gICAgICAgIHRoaXMuYWN0aW9uNSgpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy9jbGljayBidXR0b24gXCI2XCJcclxuICAgIGNsaWNrQnV0dG9uNjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5hdWRpb0NsaWNrLCBmYWxzZSwgMSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2FtZURhdGFbN10gPCA1MCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5rOV5Yqb5YC85LiN6Laz77yM54K55Ye75peg5pWIXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmdhbWVEYXRhWzddLT0gNTA7XHJcbiAgICAgICAgdGhpcy5hY3Rpb242KCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvL2xhbmRcclxuICAgIGFjdGlvbjE6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAvL2lmIChtYW5hIDwgMTIwKSB7XHJcbiAgICAgICAgLy8gICAgcmV0dXJuO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vbWFuYSAtPSAxMjA7XHJcbiAgICAgICAgdGhpcy5nZW5Hcm91bmQoKTsgLy/lop7liqDpmYblnLDvvIzmtojogJflhajpg6jms5XliptcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy9zdG9uZVxyXG4gICAgYWN0aW9uMjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vaWYgKG1hbmEgPCA2MCkge1xyXG4gICAgICAgIC8vICAgIC8vbm90aWZpY2F0aW9uXHJcbiAgICAgICAgLy8gICAgcmV0dXJuO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vbWFuYSAtPSA2MDtcclxuICAgICAgICAvLyDlpb3kuovllYpcclxuICAgICAgICBsZXQgcmFuZG9tID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC43LCB0aGlzLmdhbWVEYXRhWzRdKSkge1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuZ2VuR3JvdW5kKCk7IC8v5aKe5Yqg6ZmG5ZywXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHRoaXMuZ2VuU3RvbmUodGhpcy5nYW1lRGF0YSk7IC8v5Yi35paw6ZOB55+/77yM5Y+R546w5Yqg56eR5oqAXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHJhbmRvbSA8IE1hdGgucG93KDAuOSwgdGhpcy5nYW1lRGF0YVs0XSkpIHsgLy8g5bCx6YKj5LmI5Zue5LqL5ZCnXHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAyO1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbnVtYmVyc09mQWN0aW9uKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5nZW5Wb2Nhbm8oKTsgLy/nlJ/miJDngavlsbFcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy52b2Nhbm9FeCh0aGlzLm1hcEtleSk7IC8v54Gr5bGx5Za35Y+R77yM5Lqn55Sf55+z5aS0XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgeyAvLyDkuI3opoHov5nkuKrvvIHvvIFcclxuICAgICAgICAgICAgbGV0IG51bWJlcnNPZkFjdGlvbiA9IDI7XHJcbiAgICAgICAgICAgIGxldCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBudW1iZXJzT2ZBY3Rpb24pO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHJhbmRvbU51bSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiB0aGlzLmRlc2VydGlmaWNhdGlvbih0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5KTsgLy/mspnmvKDljJZcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy5lYXJ0aHF1YWtlKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXkpOyAvL+WcsOmch1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL3NreVxyXG4gICAgYWN0aW9uMzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vIOWlveS6i+WVilxyXG4gICAgICAgIC8vaWYgKG1hbmEgPCA0MCkge1xyXG4gICAgICAgIC8vICAgIC8vbm90aWZpY2F0aW9uXHJcbiAgICAgICAgLy8gICAgcmV0dXJuO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vbWFuYSAtPSA0MDtcclxuICAgICAgICBsZXQgcmFuZG9tID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC4xLCB0aGlzLmdhbWVEYXRhWzRdKSkge1xyXG4gICAgICAgICAgICBsZXQgbnVtYmVyc09mQWN0aW9uID0gMjtcclxuICAgICAgICAgICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZkFjdGlvbik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuc3Rvcm0odGhpcy5nYW1lRGF0YSk7IC8v6Zu3IOWinuWKoOenkeaKgFxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOiB0aGlzLmZvb2REb3VibGUodGhpcy5nYW1lRGF0YSk7IC8v5Liw5pS2XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHJhbmRvbSA8IE1hdGgucG93KDAuOCwgdGhpcy5nYW1lRGF0YVs0XSkpIHsgLy8g5bCx6YKj5LmI5Zue5LqL5ZCnXHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAyO1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbnVtYmVyc09mQWN0aW9uKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5yYWluKHRoaXMuZ2FtZURhdGEpOyAvL+mZjeawtFxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOiB0aGlzLndpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSk7IC8v6aOO77yMIOWQuei1sOS7u+S9leeJqeWTgVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHsgLy8g5LiN6KaB6L+Z5Liq77yB77yBXHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAxOyAvL25lZWQgY2hhbmdlXHJcbiAgICAgICAgICAgIGxldCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBudW1iZXJzT2ZBY3Rpb24pO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHJhbmRvbU51bSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiB0aGlzLmRyb3VnaHQodGhpcy5nYW1lRGF0YSk7IC8v5bmy5pex77yM5qaC546H54Gr54G+77yM57Ku6aOf5YeP5LqnXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IC8v5rC054G+77yM5Zyf5Zyw5Y+Y5oiQ5rC0XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6IC8vdGhpcy5vbkZpcmUoKTsgLy/ngavngb5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9wbGFudFxyXG4gICAgYWN0aW9uNDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vaWYgKG1hbmEgPCAxMCkge1xyXG4gICAgICAgIC8vbm90aWZpY2F0aW9uXHJcbiAgICAgICAgLy8gICAgcmV0dXJuO1xyXG4gICAgICAgIC8vfVxyXG4gICAgICAgIC8vbWFuYSAtPSAxMDtcclxuICAgICAgICAvLyDlpb3kuovllYpcclxuICAgICAgICBsZXQgcmFuZG9tID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBpZiAocmFuZG9tIDwgTWF0aC5wb3coMC43LCB0aGlzLmdhbWVEYXRhWzRdKSkge1xyXG4gICAgICAgICAgICBsZXQgbnVtYmVyc09mQWN0aW9uID0gMztcclxuICAgICAgICAgICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZkFjdGlvbik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHRoaXMuZ2VuQmVycnkoKTsgLy/mnpzmoJEg5YmN5pyf54mp6LWE77yM5Yqg6aOf54mpXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHRoaXMuZ2VuVHJlZSgpOyAvL+agkVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOiB0aGlzLmdlbkdyYXNzKCk7IC8v6I2JXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHJhbmRvbSA8IE1hdGgucG93KDAuOSwgdGhpcy5nYW1lRGF0YVs0XSkpIHsgLy8g5bCx6YKj5LmI5Zue5LqL5ZCnXHJcbiAgICAgICAgICAgIHRoaXMuZ2VuUG9pc29uKCk7ICAvL+avkuaenOWtkO+8jOWQg+S6huS8muatu+OAglxyXG4gICAgICAgIH0gZWxzZSB7IC8vIOS4jeimgei/meS4qu+8ge+8gVxyXG4gICAgICAgICAgICB0aGlzLmdlbkNyb3AoKTsgLy/ogJXlnLBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vYW5pbWFsXHJcbiAgICBhY3Rpb241OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy9pZiAobWFuYSA8IDMwKSB7XHJcbiAgICAgICAgLy8gICAgLy9ub3RpZmljYXRpb25cclxuICAgICAgICAvLyAgICByZXR1cm47XHJcbiAgICAgICAgLy99XHJcbiAgICAgICAgLy9tYW5hIC09IDMwO1xyXG4gICAgICAgIC8vIOWwj+Wei+WKqOeJqVxyXG4gICAgICAgIGxldCByYW5kb20gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjUsIHRoaXMuZ2FtZURhdGFbNF0pKSB7XHJcbiAgICAgICAgICAgIGxldCBudW1iZXJzT2ZBY3Rpb24gPSAyO1xyXG4gICAgICAgICAgICBsZXQgcmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbnVtYmVyc09mQWN0aW9uKTtcclxuICAgICAgICAgICAgc3dpdGNoIChyYW5kb21OdW0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogdGhpcy5nZW5Eb2codGhpcy5nYW1lRGF0YSk7IC8vIPCfkJXvvIznp5HmioDlgLzlpKfkuo4xLjLpqa/mnI3vvIzlh4/lsJHlpKflnovliqjnianmlLvlh7vmpoLnjodcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMTogdGhpcy5nZW5DaGlja2VuKCk7IC8vIPCfkJPvvIznp5HmioDkuYvlpKfkuo4gMS4x6amv5pyN77yM5q+P5bm05bCR6YeP8J+Nl1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjc1LCB0aGlzLmdhbWVEYXRhWzRdKSkgeyAvLyDkuK3lnovliqjnialcclxuICAgICAgICAgICAgdGhpcy5nZW5TaGVlcCgpOyAvL/CfkI/vvIwg5q+P5bm05Lit6YeP8J+Nlu+8jOenkeaKgOWAvOWkp+S6jjIg5Y+v6amv5pyNXHJcbiAgICAgICAgfSBlbHNlIGlmIChyYW5kb20gPCBNYXRoLnBvdygwLjksIHRoaXMuZ2FtZURhdGFbNF0pKSB7IC8vIOWwsemCo+S5iOWbnuS6i+WQp1xyXG4gICAgICAgICAgICB0aGlzLmdlbkNvdygpOyAvL/CfkILvvIwg5Lya5pS75Ye75Lq677yM5q+P5bm05aSn6YeP8J+lqe+8jOenkeaKgOWAvOWkp+S6jjPlj6/pqa/mnI3vvIzpqa/mnI3lkI7mlLvlh7tcclxuICAgICAgICB9IGVsc2UgeyAvLyDkuI3opoHov5nkuKrvvIHvvIFcclxuICAgICAgICAgICAgdGhpcy5nZW5MaW9uKHRoaXMuZ2FtZURhdGEpOyAvL/CfpoHvvIzkvJrmlLvlh7vkurrvvIzml6Dms5Xpqa/mnI1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcG9wdWxhdGlvblxyXG4gICAgYWN0aW9uNjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuZ2VuUGVvcGxlKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgIC8vdGhpcy5nYW1lRGF0YVswXSA9IDA7Ly90ZXN0XHJcbiAgICB9LFxyXG5cclxuICAgIC8vc3Bhd24gaXNsYW5kLCBzcGF3biB2b2Nhbiwgc3Bhd24gc3RvbmUsIGRlc2VydGlmaWNhdGlvbiAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5cclxuICAgIGdlblBlb3BsZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGlmIChhcnJheURhdGFbMl0gPiA1MCkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbMF0gKz0gNTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzJdIC09IDUwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5Lq65Y+jKzVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICB0aGlzLmdhbWVEYXRhWzldICs9IDU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+mjn+eJqeS4jei2s++8jOmcgOimgTUw6aOf54mpXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vZXh0ZW5kIGdyb3VuZFxyXG4gICAgZ2VuR3JvdW5kOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uID0gdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxLCAyKTtcclxuICAgICAgICBpZiAodGhpcy5zdXJDaGVjayh0aGlzLm1hcEtleSwgcG9zaXRpb25bMF0sIHBvc2l0aW9uWzFdLCAwKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBwb3NpdGlvbiA9IHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMSwgMik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMSArIDIgKiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3VyUmVwbGFjZVNpbmdsZU9mVHlwZSh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCBwb3NpdGlvblswXSwgcG9zaXRpb25bMV0sIDAsIDEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDEpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbOV0gKz0gMjA7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+mZhuWcsOaJqeW8oCcpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnKyAnIOmZhuWcsOaJqeW8oFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGdlblN0b25lOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDEpKSB7ICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMSwgNyk7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs0XSArPSAwLjAxO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn5om+5Yiw55+/54mp77yM56eR5oqAKzAuMDEnKTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDEwO1xyXG4gICAgICAgICAgICBhcnJheURhdGFbM10gKz0gMTA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDkurrku6zlj5HnjrDlj5HnjrDkuobkuIDkuKrmlrDnn7Pnn7/vvIxcXG7otYTmupArMTAs56eR5oqAKzAuMDFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnqbrlnLDkuI3otrPvvIzml6Dms5Xojrflj5bnn7Pnn78nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZ2VuZXJhdGUgYSB2b2Nhbm9cclxuICAgIGdlblZvY2FubzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAxKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEsIDYpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5p2/5Z2X6L+Q5Yqo77yM5b2i5oiQ54Gr5bGxXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgNik7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDmnb/lnZfov5DliqjvvIzlvaLmiJDngavlsbFcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAwKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+epuuWcsOS4jei2s++8jOaXoOazleW9ouaIkOeBq+WxsScgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDAsIDYpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOadv+Wdl+i/kOWKqO+8jOW9ouaIkOeBq+WxsVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHZvY2FubyBleHBsb2RlXHJcbiAgICB2b2Nhbm9FeDogZnVuY3Rpb24gKGFycmF5TWFwKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDYpKSB7XHJcbiAgICAgICAgICAgIGxldCBsaXN0T2ZJdGVtID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgNik7XHJcbiAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQpICsgMTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN1clJlcGxhY2VTaW5nbGUodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgbGlzdE9mSXRlbVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1baW5kZXhdWzFdLCA3KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg54Gr5bGx5Za35Y+RXFxuJyArIHRoaXMubG9nLnN0cmluZzsgICAgICAgICAgXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5nZW5Wb2Nhbm8oKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDYpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg54Gr5bGx5Za35Y+RXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy9lYXJ0aHF1YWtlXHJcbiAgICBlYXJ0aHF1YWtlOiBmdW5jdGlvbiAoYXJyYXlOb2RlLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTApICsgNTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCB5ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlNYXAubGVuZ3RoKTtcclxuICAgICAgICAgICAgbGV0IHggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheU1hcFswXS5sZW5ndGgpO1xyXG4gICAgICAgICAgICBsZXQgb3JpSG91c2UgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwzKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBvcmlIb3VzZSAvIDMpOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMykgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdXJSZXBsYWNlU2luZ2xlT2ZUeXBlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIHksIHgsIDMsIDcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2FtZURhdGFbMF0tPSBNYXRoLmNlaWwoTWF0aC5yYW5kb20oKSAqIDMpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmdhbWVEYXRhWzBdIDw9IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nYW1lRGF0YVswXSA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+WcsOmch+WVpicpO1xyXG4gICAgICAgIHRoaXMuZ2FtZURhdGFbOV0gLT0gMTA7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWPkeeUn+S6huWcsOmch++8jOS6uuWPo+WHj+WwkVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vRGVzZXJ0aWZpY2F0aW9uXHJcbiAgICBkZXNlcnRpZmljYXRpb246IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgbGV0IHJhbmROdW0gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICBsZXQgZ3Jhc3MgPSB0aGlzLmZpbmROb2RlKHRoaXMubWFwS2V5LCAyKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKGdyYXNzLmxlbmd0aCAvIDEwKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICByYW5kTnVtID0gTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAgICAgICAgIGlmIChyYW5kTnVtIDwgMC42KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZChhcnJheU5vZGUsIGFycmF5TWFwLCAyLCAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgNSkpIHtcclxuICAgICAgICAgICAgbGV0IGNyb3AgPSB0aGlzLmZpbmROb2RlKHRoaXMubWFwS2V5LCA1KTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKGNyb3AubGVuZ3RoIC8gMTApOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIHJhbmROdW0gPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJhbmROdW0gPCAwLjQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKGFycmF5Tm9kZSwgYXJyYXlOb2RlLCA0LCAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygn5rKZ5ryg5YyWJyk7XHJcbiAgICAgICAgdGhpcy5nYW1lRGF0YVs5XSAtPSAyMDtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5Zyf5Zyw5rKZ5ryg5YyW77yM5Yac55Sw5pS25oiQ5Y+X5o2fXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9yYWluLCBkcnksIGhhcnZlc3QsIHN0b3JtICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5cclxuICAgIC8vaGFydmVzdFxyXG4gICAgZm9vZERvdWJsZTogZnVuY3Rpb24gKGdhbWVEYXRhKSB7XHJcbiAgICAgICAgZ2FtZURhdGFbMl0gKj0gMS41O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCfpo5/niankuLDmlLYnKTtcclxuICAgICAgICBnYW1lRGF0YVs5XSArPSAyMFxyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDpo47osIPpm6jpobrvvIzpo5/nianlpKfkuLDmlLbvvIzpo5/niakqMlxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vc3Rvcm1cclxuICAgIHN0b3JtOiBmdW5jdGlvbiAoZ2FtZURhdGEpIHtcclxuICAgICAgICBsZXQgd29yZCA9ICcnO1xyXG4gICAgICAgIGdhbWVEYXRhWzRdICs9IDAuMDE7XHJcbiAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPiAwLjUpIHtcclxuICAgICAgICAgICAgZ2FtZURhdGFbNV0gKz0gMC4yO1xyXG4gICAgICAgICAgICB3b3JkID0gJ+mbqOawtOeBjOa6ieS6huW6hOeovCc7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzldICs9IDEwO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzVdIC09IDAuMjtcclxuICAgICAgICAgICAgZ2FtZURhdGFbOV0gLT0gMTA7XHJcbiAgICAgICAgICAgIHdvcmQgPSAn6YCg5oiQ5rC054G+JztcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+mbt+mYtembqCcpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDpm7fpmLXpm6ggJyArIHdvcmQgKyAnXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9yYWluOiBmb29kIGJvb3N0XHJcbiAgICByYWluOiBmdW5jdGlvbiAoZ2FtZURhdGEpIHtcclxuICAgICAgICBnYW1lRGF0YVs1XSArPSBNYXRoLnJhbmRvbSgpIC8gMjtcclxuICAgICAgICBjb25zb2xlLmxvZygn5LiL6Zuo5ZWmJyk7XHJcbiAgICAgICAgZ2FtZURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOS4i+mbqOWVplxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZHJvdWdodDogZm9vZCBkZWNheVxyXG4gICAgZHJvdWdodDogZnVuY3Rpb24gKGdhbWVEYXRhKSB7XHJcbiAgICAgICAgZ2FtZURhdGFbNV0gLT0gTWF0aC5yYW5kb20oKSAvIDI7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+W5suaXsScpO1xyXG4gICAgICAgIGdhbWVEYXRhWzldIC09IDIwO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDpm6jmsLTlsJHvvIzlj5HnlJ/kuoblubLml7FcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL3dpbmQ6IHJlb212ZSBzb21lIG5vZGVcclxuICAgIHdpbmQ6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDgpKSB7XHJcbiAgICAgICAgICAgIGxldCB0cmVlID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgOCk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcih0cmVlLmxlbmd0aCAvIDEwKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQoYXJyYXlOb2RlLCBhcnJheU1hcCwgOCwgMik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDUpKSB7XHJcbiAgICAgICAgICAgIGxldCB3aGVhdCA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDUpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IE1hdGguZmxvb3Iod2hlYXQubGVuZ3RoIC8gMTApOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMC4xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZChhcnJheU5vZGUsIGFycmF5TWFwLCA1LCAyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMykpIHtcclxuICAgICAgICAgICAgbGV0IGhvdXNlID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgMyk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgTWF0aC5mbG9vcihob3VzZS5sZW5ndGggLyAxMCk7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjEpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKGFycmF5Tm9kZSwgYXJyYXlNYXAsIDMsIDIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCA3KSkge1xyXG4gICAgICAgICAgICBsZXQgc3RvbmUgPSB0aGlzLmZpbmROb2RlKGFycmF5TWFwLCA3KTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLmZsb29yKHN0b25lLmxlbmd0aCAvIDEwKTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQoYXJyYXlOb2RlLCBhcnJheU1hcCwgNywgMik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+WIruWkp+mjjicpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDlpKfpo47mnaXooq1cXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLy8vZmlyZSBldmVudFxyXG4gICAgLy9vbkZpcmU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAvLyAgICBsZXQgbGlzdE9mSXRlbUZvcmVzdCA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDQpO1xyXG4gICAgLy8gICAgbGV0IGxpc3RPZkl0ZW1Ib3VzZSA9IHRoaXMuZmluZE5vZGUoYXJyYXlNYXAsIDYpO1xyXG4gICAgLy8gICAgbGV0IGxpc3RPZkl0ZW1GcmFtID0gdGhpcy5maW5kTm9kZShhcnJheU1hcCwgNyk7XHJcbiAgICAvLyAgICBsZXQgbnVtYmVyc09mUGxhY2UgPSAzO1xyXG4gICAgLy8gICAgbGV0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG51bWJlcnNPZlBsYWNlKTtcclxuICAgIC8vICAgIHN3aXRjaCAocmFuZG9tTnVtKSB7XHJcbiAgICAvLyAgICAgICAgY2FzZSAwOiBpZiAobGlzdE9mSXRlbUZvcmVzdCAhPSBudWxsKSB7XHJcbiAgICAvLyAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgLy8gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIGxpc3RPZkl0ZW1Gb3Jlc3RbaW5kZXhdWzBdLCBsaXN0T2ZJdGVtRm9yZXN0W2luZGV4XVsxXSwgOSk7XHJcbiAgICAvLyAgICAgICAgICAgIHJldHVybiBbbGlzdE9mSXRlbVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1baW5kZXhdWzFdXTtcclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgLy8gICAgICAgIGNhc2UgMTogaWYgKGxpc3RPZkl0ZW1Ib3VzZSAhPSBudWxsKSB7XHJcbiAgICAvLyAgICAgICAgICAgIGxldCBpbmRleCA9IChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBsaXN0T2ZJdGVtLmxlbmd0aCkpO1xyXG4gICAgLy8gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlKGFycmF5Tm9kZSwgYXJyYXlNYXAsIGxpc3RPZkl0ZW1Ib3VzZVtpbmRleF1bMF0sIGxpc3RPZkl0ZW1Ib3VzZVtpbmRleF1bMV0sIDkpO1xyXG4gICAgLy8gICAgICAgICAgICByZXR1cm4gW2xpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXV07XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICAgICBicmVhaztcclxuICAgIC8vICAgICAgICBjYXNlIDI6IGlmIChsaXN0T2ZJdGVtSG91c2VGcmFtICE9IG51bGwpIHtcclxuICAgIC8vICAgICAgICAgICAgbGV0IGluZGV4ID0gKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGxpc3RPZkl0ZW0ubGVuZ3RoKSk7XHJcbiAgICAvLyAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGUoYXJyYXlOb2RlLCBhcnJheU1hcCwgbGlzdE9mSXRlbUZyYW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtRnJhbVtpbmRleF1bMV0sIDkpO1xyXG4gICAgLy8gICAgICAgICAgICByZXR1cm4gW2xpc3RPZkl0ZW1baW5kZXhdWzBdLCBsaXN0T2ZJdGVtW2luZGV4XVsxXV07XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICAgICBicmVhaztcclxuICAgIC8vICAgIH1cclxuICAgIC8vICAgIHRoaXMubG9nLnN0cmluZyA9ICdZZWFyICcgKyB0aGlzLnRpbWUgKyAnIG9uRmlyZVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAvL30sXHJcblxyXG4gICAgLy8vL29mZiBmaXJlIGV2ZW50XHJcbiAgICAvL09mZkZpcmU6IGZ1bmN0aW9uIChhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAvLyAgICB0aGlzLnJlcGxhY2VBbGwoYXJyYXlOb2RlLCBhcnJheU1hcCwgOSwgMSk7XHJcbiAgICAvLyAgICB0aGlzLmxvZy5zdHJpbmcgPSAnWWVhciAnICsgdGhpcy50aW1lICsgJyBvZmYgZmlyZVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAvL30sXHJcblxyXG4gICAgLy9iZXJyeSwgdHJlZSwgZnJ1aXQsIHBvaXNvbiAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHJcbiAgICAvL2dyb3cgYmVycnlidXNoXHJcbiAgICBnZW5CZXJyeTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDEwKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOaenOS4mycpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn55Sf5oiQ5rWG5p6c5LibXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM56eN5qSN5rWG5p6c5Lib5aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vZ3JvdyBwb2lzb25cclxuICAgIGdlblBvaXNvbjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDE2KTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOavkuaenOS4mycpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg55Sf5oiQ5q+S5p6c5LibXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM56eN5qSN5rWG5p6c5Lib5aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vcGxhbnQgY3JvcFxyXG4gICAgZ2VuQ3JvcDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ6ICV5ZywJyk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDlvIDmi5PogJXlnLBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIzlvIDlnqbogJXlnLDlpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gICBcclxuICAgIH0sXHJcblxyXG4gICAgLy9ncmFzcyBncm93IHVwIHRvIHRyZWVzXHJcbiAgICBnZW5UcmVlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIzmpI3moJHpgKDmnpflpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAyLCA4KTtcclxuICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ5qCRJyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgICsgJyDmpI3moJHpgKDmnpdcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICBnZW5HcmFzczogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMSwgMik7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOiNiScpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICArICcg6I2J77yM5oyH5LiA56eN5qSN54mpXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgLy9jaGlja2VuLCBkb2csIGNvdywgc2hlZXAsIGxpb24gICAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblxyXG4gICAgZ2VuQ2hpY2tlbjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDExKTsgIFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ6bihJyk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICArICcg5Y+R546w5LiA5Y+q6YeO6bihXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM6Kem5Y+R5Yqo54mp5LqL5Lu25aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGdlbkRvZzogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDEyKTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzZdWzFdICs9IDE7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDni7wnKTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWPkeeOsOS4gOWPqumHjueLvFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+iNieWcsOS4jei2s++8jOinpuWPkeWKqOeJqeS6i+S7tuWksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgICBcclxuICAgIGdlbkNvdzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDEzKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUn+aIkOeJmycpO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn56ysJyArIHRoaXMudGltZSArICflubQgJyArICcg5Y+R546w5LiA5aS06YeO54mbXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6I2J5Zyw5LiN6Laz77yM6Kem5Y+R5Yqo54mp5LqL5Lu25aSx6LSlXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGdlblNoZWVwOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hlY2tOb2RlRXhpc3QodGhpcy5tYXBLZXksIDIpKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMiwgMTQpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygn55Sf5oiQ576KJyk7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDlj5HnjrDkuIDlj6rnvopcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfojYnlnLDkuI3otrPvvIzop6blj5Hliqjniankuovku7blpLHotKVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgZ2VuTGlvbjogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrTm9kZUV4aXN0KHRoaXMubWFwS2V5LCAyKSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDIsIDE1KTtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzZdWzRdICs9IDE7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlJ/miJDni67lrZAnKTtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOWPkeeOsOS4gOWktOWHtueMm+eahOeLruWtkFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+iNieWcsOS4jei2s++8jOinpuWPkeWKqOeJqeS6i+S7tuWksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL3VwZGF0ZSBmdW5jdGlvbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgLy9wb3dlciByZXN0b3JlXHJcbiAgICBwb3dlclVwZGF0ZTogZnVuY3Rpb24gKGdhbWVEYXRhKSB7XHJcbiAgICAgICAgZ2FtZURhdGFbN10rPSAxMCArIGdhbWVEYXRhWzhdICogMC4wNTtcclxuICAgICAgICBpZiAoZ2FtZURhdGFbOV0gPj0gZ2FtZURhdGFbMTBdKSB7XHJcbiAgICAgICAgICAgIC8vbGV2ZWwgdXBcclxuICAgICAgICAgICAgZ2FtZURhdGFbOF0gKz0gMjA7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzldIC09IGdhbWVEYXRhWzEwXVxyXG4gICAgICAgICAgICBnYW1lRGF0YVsxMF0gPSBnYW1lRGF0YVsxMF0gKiAxLjI7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzExXSsrO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZ2FtZURhdGFbOV0gPCAwKSB7XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzhdIC09IDIwO1xyXG4gICAgICAgICAgICBnYW1lRGF0YVsxMF0gPSBnYW1lRGF0YVsxMF0gLyAxLjI7XHJcbiAgICAgICAgICAgIGlmIChnYW1lRGF0YVsxMF0gPD0gMTAwKSB7XHJcbiAgICAgICAgICAgICAgICBnYW1lRGF0YVsxMF0gPT0gMTAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzldID0gZ2FtZURhdGFbMTBdICsgZ2FtZURhdGFbOV07ICAgXHJcbiAgICAgICAgICAgIGdhbWVEYXRhWzExXS0tO1xyXG4gICAgICAgICAgICBpZiAoZ2FtZURhdGFbMTFdIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgZ2FtZURhdGFbMTFdID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZ2FtZURhdGFbN10gPj0gZ2FtZURhdGFbOF0pIHtcclxuICAgICAgICAgICAgZ2FtZURhdGFbN10gPSBnYW1lRGF0YVs4XTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy9nYXRoZXIgYmVycnlidXNoXHJcbiAgICBnYXRoZXJCZXJyeTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMTAsIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVsyXSArPSAzO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXIgYmVycnknKTtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gNTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5pS26ZuG5rWG5p6c77yM6aOf54mpKzNcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL2dhdGhlciBwb2lzb25cclxuICAgIGdhdGhlclBvaXNvbjogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMTYsIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVswXSAtPSAxO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXIgcG9pc29uJyk7XHJcbiAgICAgICAgYXJyYXlEYXRhWzldIC09IDEwO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfkuIDkuKrkuI3lubjnmoTkurrlkIPkuobliafmr5LnmoTmnpzlrZDvvIzkurrlj6MtMVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vdGhlIGZydWl0IHRyZWVzIGFyb3VuZCB0b3duIGhhcnZlc3RcclxuICAgIGdhdGhlckZydWl0OiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA5LCA4KTtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gNTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZnJ1aXQgaGFydmVzdCcpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5Lq65Lus5aSW5Ye65ri4546p77yM6YeH5pGY5p6c5a2Q77yM6aOf54mpKzVcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICBnYXRoZXJDcm9wOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCwgbnVtKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciBmb29kJyk7XHJcbiAgICAgICAgbGV0IGdhdGhlcmNvdW50ID0gbnVtO1xyXG4gICAgICAgIGxldCBudW1GcnVpdCA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA5KTtcclxuICAgICAgICBsZXQgbnVtQmVycnkgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTApO1xyXG4gICAgICAgIGxldCBudW1Qb2lzb24gPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTYpO1xyXG4gICAgICAgIGlmIChudW1GcnVpdCA+IDAgfHwgbnVtQmVycnkgPiAwIHx8IG51bVBvaXNvbiA+IDApIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChudW0gPiBudW1GcnVpdCArIG51bUJlcnJ5ICsgbnVtUG9pc29uKSB7XHJcbiAgICAgICAgICAgIGdhdGhlcmNvdW50ID0gbnVtQmVycnkgKyBudW1Qb2lzb24gKyBudW1GcnVpdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBnYXRoZXJjb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXJpbmcgZm9vZCcpXHJcbiAgICAgICAgICAgIGlmIChudW1GcnVpdCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyRnJ1aXQoYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChudW1Qb2lzb24gPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyQmVycnkoYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAobnVtQmVycnkgPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyUG9pc29uKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpID4gMC41KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyQmVycnkoYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdhdGhlclBvaXNvbihhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgZ2F0aGVyVHJlZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgOCwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzNdICs9IDEwO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyIHRyZWUsIHJlc291cmNlICsgMjAnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6YeH6ZuG5Yiw5qCR5pyo77yM6LWE5rqQKzEwXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlckZydWl0VHJlZTogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgOCwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzNdICs9IDEwO1xyXG4gICAgICAgIGFycmF5RGF0YVsyXSArPSA0O1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyIGZydWl0IHRyZWUsIHJlc291cmNlICsgMjAnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn6YeH6ZuG5Yiw5p6c5qCR77yM6LWE5rqQKzEw77yM6aOf54mpKzRcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgZ2F0aGVyU3RvbmU6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDcsIDEpO1xyXG4gICAgICAgIGFycmF5RGF0YVszXSArPSAzMDtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhdGhlciBzdG9uZSwgcmVzb3VyY2UgKyAyMCcpO1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICflj5HnjrDkuobnn7/nn7PvvIzotYTmupArMzBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICBnYXRoZXJSZXNvdXJjZTogZnVuY3Rpb24gKGFycmF5RGF0YSwgYXJyYXlNYXAsIG51bSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnYXRoZXIgcmVzb3VyY2UnKTtcclxuICAgICAgICBsZXQgZ2F0aGVyY291bnQgPSBudW07XHJcbiAgICAgICAgbGV0IG51bVRyZWUgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgOCk7XHJcbiAgICAgICAgbGV0IG51bUZydWl0VHJlZSA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA5KTtcclxuICAgICAgICBsZXQgbnVtU3RvbmUgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNyk7XHJcbiAgICAgICAgaWYgKG51bVRyZWUgPiAwIHx8IG51bUZydWl0VHJlZSA+IDAgfHwgbnVtU3RvbmUgPiAwKSB7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChudW0gPiBudW1UcmVlICsgbnVtU3RvbmUgKyBudW1GcnVpdFRyZWUpIHtcclxuICAgICAgICAgICAgZ2F0aGVyY291bnQgPSBudW1UcmVlICsgbnVtU3RvbmUgKyBudW1GcnVpdFRyZWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZ2F0aGVyY291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyaW5nIHJlc291cmNlJylcclxuICAgICAgICAgICAgaWYgKG51bVN0b25lID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJTdG9uZShhcnJheURhdGEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKG51bVRyZWUgPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyRnJ1aXRUcmVlKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2F0aGVyVHJlZShhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBraWxsQ2hpY2tlbjogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgMTEsIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVsyXSArPSA1O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdraWxsIGNoaWNrZW4nKTtcclxuICAgICAgICBhcnJheURhdGFbOV0gKz0gMTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5LiA5Y+q6bih6KKr5p2A5p2l5ZCD5LqG77yM6aOf54mpKzXvvIznu4/pqowrMVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGxEb2c6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEyLCAyKTtcclxuICAgICAgICBhcnJheURhdGFbNV1bMV0gLT0gMTtcclxuICAgICAgICBsZXQgZGVhZCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIpO1xyXG4gICAgICAgIGFycmF5RGF0YVswXSAtPSBkZWFkO1xyXG4gICAgICAgIGFycmF5RGF0YVsyXSArPSA0O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdraWxsIGRvZycpO1xyXG4gICAgICAgIGlmIChkZWFkID09IDEpIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfmnYDmrbvni7wnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueLvOeIquS4i1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDU7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfmnYDmrbvni7wnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueLvOeIquS4i++8jOe7j+mqjCs1XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGxDb3c6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDEzLCAyKTtcclxuICAgICAgICBsZXQgZGVhZCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpO1xyXG4gICAgICAgIGFycmF5RGF0YVswXSAtPSBkZWFkO1xyXG4gICAgICAgIGFycmF5RGF0YVsyXSArPSA4O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdraWxsIGNvdycpO1xyXG4gICAgICAgIGlmIChkZWFkID49IDIpIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfmnYDmrbvniZsnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+atu+S6jueJm+inkuS4i1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDEwO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5p2A5q2754mbJyArICfvvIzkuI3ov4fmnIknICsgZGVhZCArICfmrbvkuo7niZvop5LkuIvvvIznu4/pqowrMTBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5p2A5q2754mbJyArICfvvIzkuI3ov4fmnIknICsgZGVhZCArICfmrbvkuo7niZvop5LkuItcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgfSxcclxuXHJcbiAgICBraWxsU2hlZXA6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKHRoaXMubm9kZUtleSwgdGhpcy5tYXBLZXksIDE0LCAyKTtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gNDtcclxuICAgICAgICBjb25zb2xlLmxvZygna2lsbCBzaGVlcCcpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSA1O1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfkuIDlj6rnvorooqvmnYDlgZrng6TlhajnvorvvIzpo5/niakrNFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGxMaW9uOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAxNSwgMik7XHJcbiAgICAgICAgYXJyYXlEYXRhWzVdWzRdIC09IDE7XHJcbiAgICAgICAgbGV0IGRlYWQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0KTtcclxuICAgICAgICBhcnJheURhdGFbMF0gLT0gZGVhZDtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gMTY7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2tpbGwgbGlvbicpO1xyXG4gICAgICAgIGlmIChkZWFkID49IDIpIHtcclxuICAgICAgICAgICAgYXJyYXlEYXRhWzldICs9IDA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfmnYDmrbvni67lrZAnICsgJ++8jOS4jei/h+aciScgKyBkZWFkICsgJ+S6uuiiq+eLruWtkOWSrOatu+S6hlxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfSBlbHNlIGlmIChkZWFkID0gMCkge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMjA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfmjZXojrfkuIDlpLTni67lrZDvvIznu4/pqowrMjAnICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVs5XSArPSAxMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+aNleadgOeLruWtkOeahOi/h+eoi+S4re+8jOaciScgKyBkZWFkICsgJ+S6uueJuueJsiznu4/pqowrMTAnICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlck1lYXQ6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5TWFwLCBudW0pIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyIG1lYXQnKTtcclxuICAgICAgICBsZXQgZ2F0aGVyY291bnQgPSBudW07XHJcbiAgICAgICAgbGV0IGNoaWNrZW4gPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTEpIC0gYXJyYXlEYXRhWzZdWzBdO1xyXG4gICAgICAgIGxldCBzaGVlcCA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNCkgLSBhcnJheURhdGFbNl1bM107XHJcbiAgICAgICAgbGV0IGNvdyA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMykgLSBhcnJheURhdGFbNl1bMl07XHJcbiAgICAgICAgbGV0IHdvbGYgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTIpO1xyXG4gICAgICAgIGxldCBsaW9uID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE1KTtcclxuICAgICAgICBpZiAoY2hpY2tlbiA+IDAgfHwgc2hlZXAgPiAwIHx8IGNvdyA+IDAgfHwgd29sZiA+IDAgfHwgbGlvbiA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+S7juWKqOeJqei6q+S4iuiOt+WPluiCie+8jOmjn+eJqeWinuWKoFxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChudW0gPiBNYXRoLmZsb29yKGNoaWNrZW4gKyBzaGVlcCAvIDIgKyBjb3cgLyAzICsgd29sZiAvIDIgKyBsaW9uIC8gNCkpIHtcclxuICAgICAgICAgICAgZ2F0aGVyY291bnQgPSBNYXRoLmZsb29yKGNoaWNrZW4gKyBzaGVlcCAvIDIgKyBjb3cgLyAzICsgd29sZiAvIDIgKyBsaW9uIC8gNCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZ2F0aGVyY291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZ2F0aGVyaW5nIG1lYXQnKVxyXG4gICAgICAgICAgICBpZiAoY2hpY2tlbiA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMua2lsbENoaWNrZW4oYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMC4xICYmIGFycmF5RGF0YVs2XVswXSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBhcnJheURhdGFbNl1bMF0gLT0gMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmIChzaGVlcCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMua2lsbFNoZWVwKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoTWF0aC5yYW5kb20oKSA8IDAuMDkgJiYgYXJyYXlEYXRhWzZdWzNdID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFycmF5RGF0YVs2XVszXSAtPSAxO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGNvdyA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMua2lsbENvdyhhcnJheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjA4ICYmIGFycmF5RGF0YVs2XVsyXSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBhcnJheURhdGFbNl1bMl0gLT0gMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmICh3b2xmID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5raWxsRG9nKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmtpbGxMaW9uKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHRhbWVDaGlja2VuOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgYXJyYXlEYXRhWzZdWzBdICs9IDE7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RhbSBjaGlja2VuJyk7XHJcbiAgICAgICAgYXJyYXlEYXRhWzldICs9IDU7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOaIkOWKn+mpr+acjeW5tuawuOi/nOaLpeacieS4gOWPqum4oe+8jOe7j+mqjCs1XFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgdGFtZUNvdzogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGFycmF5RGF0YVs2XVsyXSArPSAxO1xyXG4gICAgICAgIGFycmF5RGF0YVswXSAtPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyKTtcclxuICAgICAgICBjb25zb2xlLmxvZygndGFtIGNvdycpO1xyXG4gICAgICAgIGxldCBkZWFkID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNCk7XHJcbiAgICAgICAgaWYgKGRlYWQgPj0gMikge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMDtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAn5oiQ5Yqf6amv5pyN5bm25rC46L+c5oul5pyJ5LiA5aS054mbXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBhcnJheURhdGFbOV0gKz0gMTA7XHJcbiAgICAgICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJ+aIkOWKn+mpr+acjeW5tuawuOi/nOaLpeacieS4gOWktOeJmyznu4/pqowrMTBcXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgdGFtZVNoZWVwOiBmdW5jdGlvbiAoYXJyYXlEYXRhKSB7XHJcbiAgICAgICAgYXJyYXlEYXRhWzZdWzNdICs9IDE7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RhbSBzaGVlcCcpO1xyXG4gICAgICAgIGFycmF5RGF0YVs5XSArPSA1O1xyXG4gICAgICAgIHRoaXMubG9nLnN0cmluZyA9ICfnrKwnICsgdGhpcy50aW1lICsgJ+W5tCAnICsgJyDmiJDlip/pqa/mnI3lubbmsLjov5zmi6XmnInkuIDlj6rnvorvvIznu4/pqowrNVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIGdhdGhlclRhbTogZnVuY3Rpb24gKGFycmF5RGF0YSwgYXJyYXlNYXAsIG51bSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0cnkgdGFtaW5nJyk7XHJcbiAgICAgICAgbGV0IGlmVGFtZWQgPSBmYWxzZTtcclxuICAgICAgICAvL2xldCBjaGlja2VuID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDExKSAtIGFycmF5RGF0YVs2XVswXTtcclxuICAgICAgICAvL2xldCBzaGVlcCA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNCkgLSBhcnJheURhdGFbNl1bM107XHJcbiAgICAgICAgLy9sZXQgY293ID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDEzKSAtIGFycmF5RGF0YVs2XVsyXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGlja2VuID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDExKSAtIGFycmF5RGF0YVs2XVswXTtcclxuICAgICAgICAgICAgbGV0IHNoZWVwID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDE0KSAtIGFycmF5RGF0YVs2XVszXTtcclxuICAgICAgICAgICAgbGV0IGNvdyA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMykgLSBhcnJheURhdGFbNl1bMl07XHJcbiAgICAgICAgICAgIGlmIChjaGlja2VuID4gMCAmJiBNYXRoLnJhbmRvbSgpIDwgMC41KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRhbWVDaGlja2VuKGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICBpZlRhbWVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChzaGVlcCA+IDAgJiYgTWF0aC5yYW5kb20oKSA8IDAuNCAmJiB0aGlzLmdhbWVEYXRhWzRdID49IDEuMikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50YW1lU2hlZXAoYXJyYXlEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmVGFtZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGNvdyA+IDAgJiYgTWF0aC5yYW5kb20oKSA8IDAuMyAmJiB0aGlzLmdhbWVEYXRhWzRdID49IDEuNCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50YW1lQ293KGFycmF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICBpZlRhbWVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvKmlmIChjaGlja2VuICsgc2hlZXAgKyBjb3cgPiAwKSB7XHJcbiAgICAgICAgICAgIGlmICghaWZUYW1lZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+mpr+acjeWksei0pVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5peg5Yqo54mp6amv5pyNXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9Ki9cclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIEFJICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5cclxuICAgIGJ1aWxkSG91c2U6IGZ1bmN0aW9uIChnYW1lRGF0YSkge1xyXG4gICAgICAgIGlmIChnYW1lRGF0YVszXSA+PSAxMDAgJiYgZ2FtZURhdGFbMV0gPCBnYW1lRGF0YVswXSAvIDIpIHtcclxuICAgICAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCAyLCAzKTtcclxuICAgICAgICAgICAgZ2FtZURhdGFbM10gLT0gMTAwO1xyXG4gICAgICAgICAgICBnYW1lRGF0YVsxXSArPSAxO1xyXG4gICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5oiQ5Yqf5bu66YCg5LiA5qCL5oi/5a2QXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGZvb2RVcGRhdGU6IGZ1bmN0aW9uIChhcnJheURhdGEsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgbGV0IG51bU9mUGxvdCA9IHRoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA1KTtcclxuICAgICAgICBhcnJheURhdGFbMl0gKz0gbnVtT2ZQbG90ICogMTYgKiBhcnJheURhdGFbNF0gKiBhcnJheURhdGFbNV0gLSBhcnJheURhdGFbMF0gKiA0O1xyXG4gICAgICAgIGlmIChhcnJheURhdGFbMl0gPCAwKSB7XHJcbiAgICAgICAgICAgIGFycmF5RGF0YVsyXSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdmb29kOiAnICsgTWF0aC5mbG9vcihhcnJheURhdGFbMl0pKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy9jcm9wIGdyb3dcclxuICAgIGdyb3dDcm9wOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA0LCA1KTtcclxuICAgICAgICBjb25zb2xlLmxvZygnY3JvcCBncm93Jyk7XHJcbiAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+W6hOeovOaIkOeGn+S6hlxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vdHJlZXMgYXJvdW5kIHRoZSB0b3duIGNoYW5nZSB0byBmcnVpdCB0cmVlc1xyXG4gICAgZ3Jvd0ZydWl0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5yZXBsYWNlTm9kZUJ5S2luZCh0aGlzLm5vZGVLZXksIHRoaXMubWFwS2V5LCA4LCA5KTtcclxuICAgICAgICBjb25zb2xlLmxvZygnZnJ1aXQnKTtcclxuICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn5qCR5LiK57uT5p6c5a2Q5LqGXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgIH0sXHJcblxyXG4gICAgcmVzb3VyY2VEZXN0b3J5OiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU1hcCkge1xyXG4gICAgICAgIGxldCBjaGlja2VuID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxMSkgLSBhcnJheURhdGFbNl1bMF0sIDExLCAwLjFdO1xyXG4gICAgICAgIGxldCBzaGVlcCA9IFt0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTQpIC0gYXJyYXlEYXRhWzZdWzNdLCAxNCwgMC4wNV07XHJcbiAgICAgICAgbGV0IGNvdyA9IFt0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTMpIC0gYXJyYXlEYXRhWzZdWzJdLCAxMywgMC4wNV07XHJcbiAgICAgICAgbGV0IHdvbGYgPSBbdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDEyKSwgMTIsIDAuMDVdO1xyXG4gICAgICAgIGxldCBsaW9uID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNSksIDE1LCAwLjFdO1xyXG4gICAgICAgIGxldCBiZXJyeSA9IFt0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgMTApLCAxMCwgMC40XTtcclxuICAgICAgICBsZXQgcG9pc29uID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCAxNiksIDE2LCAwLjRdO1xyXG4gICAgICAgIGxldCB0cmVlID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA4KSwgOCwgMC4wNV07XHJcbiAgICAgICAgbGV0IGZydWl0ID0gW3RoaXMubnVtT2ZJdGVtKGFycmF5TWFwLCA5KSwgOSwgMC4wNV07XHJcbiAgICAgICAgbGV0IGl0ZW1MaXN0ID0gW2NoaWNrZW4sIHNoZWVwLCBjb3csIHdvbGYsIGxpb24sIGJlcnJ5LCBwb2lzb24sIHRyZWUsIGZydWl0XTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZW1MaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgaXRlbUxpc3RbaV1bMF07IGorKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCBpdGVtTGlzdFtpXVsyXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVwbGFjZU5vZGVCeUtpbmQodGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSwgaXRlbUxpc3RbaV1bMV0sIDIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBsYW5kdXBkYXRlOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgdGhpcy5yZXNvdXJjZURlc3RvcnkoYXJyYXlEYXRhLCBhcnJheU1hcCk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNCk7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLmdyb3dDcm9wKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDgpOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjMpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3Jvd0ZydWl0KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBudW1PZlBsb3QgPSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNSk7XHJcbiAgICAgICAgd2hpbGUgKG51bU9mUGxvdCA+IGFycmF5RGF0YVswXSkge1xyXG4gICAgICAgICAgICB0aGlzLnJlcGxhY2VOb2RlQnlLaW5kKGFycmF5Tm9kZSwgYXJyYXlNYXAsIDUsIDIpO1xyXG4gICAgICAgICAgICBudW1PZlBsb3QgLT0gMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ25vdCBlbm91Z2ggcGVvcGxlIGZhcm1pbmcnKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHRlY2hVcGRhdGU6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICBhcnJheURhdGFbNF0gKz0gMC4wMDU7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RlY2g6ICcgKyBNYXRoLnJvdW5kKGFycmF5RGF0YVs0XSkpO1xyXG4gICAgICAgIC8vdGhpcy5sb2cuc3RyaW5nID0gJ+enkeaKgOWAvCswLjAwMVxcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICB9LFxyXG5cclxuICAgIHBvcHVsYXRpb25VcGRhdGU6IGZ1bmN0aW9uIChhcnJheURhdGEpIHtcclxuICAgICAgICBsZXQgd29sZiA9IHRoaXMubnVtT2ZJdGVtKHRoaXMubWFwS2V5LCAxMik7XHJcbiAgICAgICAgbGV0IGxpb24gPSB0aGlzLm51bU9mSXRlbSh0aGlzLm1hcEtleSwgMTUpO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd29sZjsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChhcnJheURhdGFbMF0gPiBhcnJheURhdGFbMV0gKiAzICYmIE1hdGgucmFuZG9tKCkgPCAwLjEpIHtcclxuICAgICAgICAgICAgICAgIGFycmF5RGF0YVswXSAtPSAxO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+e8uuWwkeaIv+Wxi++8jOS4gOS4quS4jeW5uOeahOa1gea1quaxieiiq+mHjueLvOadgOWus1xcbicgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW9uOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGFycmF5RGF0YVswXSA+IGFycmF5RGF0YVsxXSAqIDMgJiYgTWF0aC5yYW5kb20oKSA8IDAuMykge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlEYXRhWzBdIC09IDE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5zdHJpbmcgPSAn57y65bCR5oi/5bGL77yM5LiA5Liq5LiN5bm455qE5rWB5rWq5rGJ6KKr54uu5a2Q5p2A5a6zXFxuJyArIHRoaXMubG9nLnN0cmluZztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoYXJyYXlEYXRhWzJdID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJ+esrCcgKyB0aGlzLnRpbWUgKyAn5bm0ICcgKyAnIOmlpeiNkizkurrlj6PmjZ/lpLHmg6jph41cXG4nICsgdGhpcy5sb2cuc3RyaW5nO1xyXG4gICAgICAgICAgICBpZiAoYXJyYXlEYXRhWzBdID4gMykge1xyXG4gICAgICAgICAgICAgICAgYXJyYXlEYXRhWzBdID0gTWF0aC5jZWlsKGFycmF5RGF0YVswXSAqIDMgLyA0KTtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5sb2cuc3RyaW5nID0gTWF0aC5jZWlsKGFycmF5RGF0YVswXSAqIDEgLyA0KTsgKyB0aGlzLmxvZy5zdHJpbmc7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBhcnJheURhdGFbMF0gPSBNYXRoLmZsb29yKGFycmF5RGF0YVswXSAqIDMgLyA0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoYXJyYXlEYXRhWzBdID09IDEpIHtcclxuICAgICAgICAgICAgICAgIGFycmF5RGF0YVswXSA9IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgY2hhbmdlV2VhdGhlcjogZnVuY3Rpb24gKGFycmF5RGF0YSkge1xyXG4gICAgICAgIGFycmF5RGF0YVs1XSAtPSAoYXJyYXlEYXRhWzVdIC0gMSkgLyA1O1xyXG4gICAgICAgIGFycmF5RGF0YVs1XSAtPSAwLjAwNTtcclxuICAgIH0sXHJcblxyXG4gICAgeWVhckNoZWNrOiBmdW5jdGlvbiAoYXJyYXlEYXRhLCBhcnJheU5vZGUsIGFycmF5TWFwKSB7XHJcbiAgICAgICAgdGhpcy5idWlsZEhvdXNlKGFycmF5RGF0YSk7XHJcbiAgICAgICAgdGhpcy5nYXRoZXJGb29kKGFycmF5RGF0YSwgYXJyYXlNYXApO1xyXG4gICAgfSxcclxuXHJcbiAgICBnYXRoZXJBSTogZnVuY3Rpb24gKGFycmF5RGF0YSwgYXJyYXlNYXApIHtcclxuICAgICAgICBsZXQgbnVtT2ZQbG90ID0gdGhpcy5udW1PZkl0ZW0oYXJyYXlNYXAsIDUpO1xyXG4gICAgICAgIGxldCBmb29kID0gbnVtT2ZQbG90ICogMjAgLSBhcnJheURhdGFbMF0gKiA0ICsgYXJyYXlEYXRhWzJdO1xyXG4gICAgICAgIGxldCByZW1haW4gPSBhcnJheURhdGFbMF0gLSB0aGlzLm51bU9mSXRlbShhcnJheU1hcCwgNSk7XHJcbiAgICAgICAgaWYgKGZvb2QgPD0gYXJyYXlEYXRhWzBdICogOCkge1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlckNyb3AoYXJyYXlEYXRhLCBhcnJheU1hcCwgcmVtYWluKTtcclxuICAgICAgICAgICAgZm9vZCA9IG51bU9mUGxvdCAqIDIwIC0gYXJyYXlEYXRhWzBdICogNCArIGFycmF5RGF0YVsyXTtcclxuICAgICAgICAgICAgaWYgKGZvb2QgPD0gYXJyYXlEYXRhWzBdICogNCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nYXRoZXJNZWF0KGFycmF5RGF0YSwgYXJyYXlNYXAsIE1hdGguZmxvb3IocmVtYWluIC8gMikpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChmb29kIDw9IGFycmF5RGF0YVswXSAqIDE2KSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ2F0aGVyQ3JvcChhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDYpKTtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJSZXNvdXJjZShhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDIpKTtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJUYW0oYXJyYXlEYXRhLCBhcnJheU1hcCwgTWF0aC5mbG9vcihyZW1haW4gLyAzKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJSZXNvdXJjZShhcnJheURhdGEsIGFycmF5TWFwLCBNYXRoLmZsb29yKHJlbWFpbiAvIDIpKTtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJUYW0oYXJyYXlEYXRhLCBhcnJheU1hcCwgTWF0aC5mbG9vcihyZW1haW4gLyAyKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChhcnJheURhdGFbMF0gPiA1MCkge1xyXG4gICAgICAgICAgICB0aGlzLmdhdGhlck1lYXQoYXJyYXlEYXRhLCBhcnJheU1hcCwgTWF0aC5mbG9vcihyZW1haW4gLyAxMCkpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2hlY2sgaWYgdGhlIG5leHQgdGlsZSBodW1hbiBoZWFkaW5nIHRvIGlzIHdhdGVyIG9yIHNvbWV3aGVyZSBpdCBzaG91bGQgbm90IGJlXHJcbiAgICBjYW5IdW1hbk1vdmUoYWN0aW9uTnVtKSB7XHJcbiAgICAgICAgbGV0IGN1cnJYID0gTWF0aC5mbG9vcih0aGlzLmh1bWFuTm9kZS54IC8gMzIpO1xyXG4gICAgICAgIGxldCBjdXJyWSA9IE1hdGguZmxvb3IodGhpcy5odW1hbk5vZGUueSAvIDMyKTtcclxuXHJcbiAgICAgICAgaWYgKGFjdGlvbk51bSA9PSAwKSB7IC8vIHVwXHJcbiAgICAgICAgICAgIGN1cnJZKys7XHJcbiAgICAgICAgfSBlbHNlIGlmIChhY3Rpb25OdW0gPT0gMSkgeyAvL2Rvd25cclxuICAgICAgICAgICAgY3VyclktLTtcclxuICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbk51bSA9PSAyKSB7IC8vbGVmdFxyXG4gICAgICAgICAgICBjdXJyWC0tO1xyXG4gICAgICAgIH0gZWxzZSB7IC8vcmlnaHRcclxuICAgICAgICAgICAgY3VyclgrKztcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHRoaXMubWFwS2V5W2N1cnJZXVtjdXJyWF0gPT0gMCkgeyAvLyBhZGQgb3RoZXIga2V5cyBpZiBuZWNlc3NhcnlcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgaHVtYW5Nb3ZlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBsZXQgc3RhdGUgPSAnJztcclxuICAgICAgICBsZXQgYWN0aW9uID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNCk7XHJcbiAgICAgICAgaWYgKHRoaXMuY2FuSHVtYW5Nb3ZlKGFjdGlvbikpIHtcclxuICAgICAgICAgICAgaWYgKGFjdGlvbiA9PSAwICYmIHRoaXMuaHVtYW5Ob2RlLnkgPD0gNjQwIC0gMTYgLSAzMikge1xyXG4gICAgICAgICAgICAgICAgLy8gdXBcclxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX3VwJztcclxuICAgICAgICAgICAgICAgIHRoaXMuc3AueCA9IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnkgPSAzMjtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMSAmJiB0aGlzLmh1bWFuTm9kZS55ID49IDE2ICsgMzIpIHtcclxuICAgICAgICAgICAgICAgIC8vIGRvd25cclxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX2Rvd24nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC54ID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3AueSA9IC0zMjtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMiAmJiB0aGlzLmh1bWFuTm9kZS54ID49IDE2ICsgMzIpIHtcclxuICAgICAgICAgICAgICAgIC8vIGxlZnRcclxuICAgICAgICAgICAgICAgIHN0YXRlID0gJ2h1bWFuX2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC54ID0gLTMyO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcC55ID0gMDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT0gMyAmJiB0aGlzLmh1bWFuTm9kZS54IDw9IDY0MCAtIDE2IC0gMzIpIHtcclxuICAgICAgICAgICAgICAgIC8vIHJpZ2h0XHJcbiAgICAgICAgICAgICAgICBzdGF0ZSA9ICdodW1hbl9yaWdodCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwLnggPSAzMjtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3AueSA9IDA7XHJcbiAgICAgICAgICAgIH0gXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zcC54ID0gMDtcclxuICAgICAgICAgICAgdGhpcy5zcC55ID0gMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLnNwLngpIHtcclxuICAgICAgICAgICAgdGhpcy5odW1hbk5vZGUueCArPSB0aGlzLnNwLng7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLnNwLnkpIHtcclxuICAgICAgICAgICAgdGhpcy5odW1hbk5vZGUueSArPSB0aGlzLnNwLnk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoc3RhdGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBwcm9ncmVzc0JhclVwZGF0ZTogZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSB0aGlzLmdhbWVEYXRhWzddIC8gdGhpcy5nYW1lRGF0YVs4XTtcclxuICAgICAgICAvKmlmIChwcm9ncmVzcyA8IDEpIHtcclxuICAgICAgICAgICAgcHJvZ3Jlc3MgKz0gMC4wMDU7XHJcbiAgICAgICAgICAgIHRoaXMucHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSBwcm9ncmVzcztcclxuICAgICAgICBcclxuXHRcdH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMucHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSAxOyAgICAgICBcclxuXHRcdH0qL1xyXG5cdH0sXHJcblxyXG4gICAgcmVhZFVzZXJEYXRhOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dhbWU9JyArIGNvbS5nYW1lT3Zlcik7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZygnZmlyc3RUaW1lICcgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2dsb2JhbE1hcEtleScpID09IG51bGwpOy8vbWF5IG5ldmVyIGJlIHRydWVcclxuICAgICAgICB2YXIgdmFsdWUgPSB3eC5nZXRTdG9yYWdlU3luYygnZ2xvYmFsTWFwS2V5Jyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3Jlc3RhcnQgJyArIGNvbS5yZXN0YXJ0KTtcclxuICAgICAgICBpZiAodmFsdWUubGVuZ3RoID09IDAgfHwgY29tLnJlc3RhcnQgfHwgY29tLmdhbWVPdmVyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCduZXcgZ2FtZScpO1xyXG4gICAgICAgICAgICBjb20uZ2FtZU92ZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgY29tLnJlc3RhcnQgPSBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvL2dsb2JhbE1hcEtleSA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZ2xvYmFsTWFwS2V5Jyk7XHJcbiAgICAgICAgICAgIC8vZ2xvYmFsR2FtZURhdGEgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2dsb2JhbEdhbWVEYXRhJyk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSB3eC5nZXRTdG9yYWdlU3luYygnZ2xvYmFsTWFwS2V5Jyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgLy8gRG8gc29tZXRoaW5nIHdpdGggcmV0dXJuIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgIGdsb2JhbE1hcEtleSA9IHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBEbyBzb21ldGhpbmcgd2hlbiBjYXRjaCBlcnJvclxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2dldCBtYXAga2V5IHN0b3JhZ2UgZXJyb3InKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gd3guZ2V0U3RvcmFnZVN5bmMoJ2dsb2JhbEdhbWVEYXRhJyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgLy8gRG8gc29tZXRoaW5nIHdpdGggcmV0dXJuIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgIGdsb2JhbEdhbWVEYXRhID0gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIC8vIERvIHNvbWV0aGluZyB3aGVuIGNhdGNoIGVycm9yXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZ2V0IGdhbWUgZGF0YSBzdG9yYWdlIGVycm9yJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHd4LmdldFN0b3JhZ2VTeW5jKCdnbG9iYWxZZWFyJyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgLy8gRG8gc29tZXRoaW5nIHdpdGggcmV0dXJuIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgIGdsb2JhbFllYXIgPSB2YWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgLy8gRG8gc29tZXRoaW5nIHdoZW4gY2F0Y2ggZXJyb3JcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnZXQgeWVhciBzdG9yYWdlIGVycm9yJyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnbG9iYWxNYXBLZXknKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsTWFwS2V5KTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2dsb2JhbEdhbWVEYXRhJyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGdsb2JhbEdhbWVEYXRhKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2dsb2JhbFllYXInKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsWWVhcik7XHJcblxyXG4gICAgICAgICAgICAvLyB2YXIga2V5QXJyYXkgPSBnbG9iYWxNYXBLZXkuc3BsaXQoXCIsXCIpO1xyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuc2l6ZVk7IGkrKykge1xyXG4gICAgICAgICAgICAvLyAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLnNpemVYOyBqKyspIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLm1hcEtleVtpXVtqXSA9IHBhcnNlSW50KGtleUFycmF5W2kgKiB0aGlzLnNpemVYICsgal0pO1xyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgIHRoaXMubWFwS2V5ID0gZ2xvYmFsTWFwS2V5O1xyXG5cclxuICAgICAgICAgICAgLy8gdmFyIHNwbGl0QXJyYXkgPSBnbG9iYWxHYW1lRGF0YS5zcGxpdChcIixcIik7XHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5nYW1lRGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAvLyAgICAgaWYgKGkgPT0gNiB8fCBpID09IDcgfHwgaSA9PSA4IHx8IGkgPT0gOSB8fCBpID09IDEwKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgZm9yIChqID0gMDsgaiA8IHRoaXMuZ2FtZURhdGFbaV0ubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgdGhpcy5nYW1lRGF0YVtpXVtqXSA9IHBhcnNlRmxvYXQoc3BsaXRBcnJheVtpICsgal0pO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy5nYW1lRGF0YVtpXSA9IHBhcnNlRmxvYXQoc3BsaXRBcnJheVtpXSk7XHJcbiAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgdGhpcy5nYW1lRGF0YSA9IGdsb2JhbEdhbWVEYXRhO1xyXG4gICAgICAgICAgICB0aGlzLnRpbWUgPSBnbG9iYWxZZWFyO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgZ2FtZU92ZXJVcGRhdGU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5nYW1lRGF0YVswXSA8PSAwICYmIHRoaXMuZ2FtZU92ZXJPck5vdCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZGVhZCcpO1xyXG4gICAgICAgICAgICB0aGlzLmdhbWVPdmVyLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZU92ZXJPck5vdCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuc2F2ZVVzZXJEYXRhKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZU92ZXJUaW1lID0gdGhpcy50aW1lO1xyXG4gICAgICAgICAgICB0aGlzLmdhbWVPdmVyU3RyaW5nLnN0cmluZyA9ICfmuLjmiI/nu5PmnZ9cXG7mgqjnmoTlrZDmsJHnga3nu53kuoZcXG4nICsgJ+aCqOeahOaWh+aYjuaMgee7reS6hlxcbicgKyB0aGlzLmdhbWVPdmVyVGltZSArICflubQnO1xyXG5cdCAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHNhdmVVc2VyRGF0YTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNvbS5nYW1lT3ZlciA9IHRoaXMuZ2FtZU92ZXJPck5vdDtcclxuICAgICAgICBnbG9iYWxNYXBLZXkgPSB0aGlzLm1hcEtleTtcclxuICAgICAgICAvL2NjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZ2xvYmFsTWFwS2V5JywgZ2xvYmFsTWFwS2V5KTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICB3eC5zZXRTdG9yYWdlU3luYygnZ2xvYmFsTWFwS2V5JywgZ2xvYmFsTWFwS2V5KTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdzZXQgbWFwIGtleSBzdG9yYWdlIGVycm9yJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdzYXZlVXNlckRhdGEgZ2xvYmFsTWFwS2V5OicpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGdsb2JhbE1hcEtleSk7XHJcblxyXG4gICAgICAgIGdsb2JhbEdhbWVEYXRhID0gdGhpcy5nYW1lRGF0YTtcclxuICAgICAgICAvL2NjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZ2xvYmFsR2FtZURhdGEnLCBnbG9iYWxHYW1lRGF0YSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgd3guc2V0U3RvcmFnZVN5bmMoJ2dsb2JhbEdhbWVEYXRhJywgZ2xvYmFsR2FtZURhdGEpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3NldCBnYW1lIGRhdGEgc3RvcmFnZSBlcnJvcicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZygnc2F2ZVVzZXJEYXRhIGdsb2JhbEdhbWVEYXRhJyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZ2xvYmFsR2FtZURhdGEpO1xyXG5cclxuICAgICAgICBnbG9iYWxZZWFyID0gdGhpcy50aW1lO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHd4LnNldFN0b3JhZ2VTeW5jKCdnbG9iYWxZZWFyJywgZ2xvYmFsWWVhcik7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnc2V0IHllYXIgc3RvcmFnZSBlcnJvcicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIGlmICh0aGlzLmdhbWVPdmVyT3JOb3QpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmZyYW1lKys7XHJcbiAgICAgICAgdGhpcy5sb2dmcmFtZSsrO1xyXG4gICAgICAgIGlmICh0aGlzLmZyYW1lICUgNjAgPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLnBvd2VyVXBkYXRlKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5mcmFtZSA9PSAyNzApIHtcclxuICAgICAgICAgICAgdGhpcy5nYXRoZXJBSSh0aGlzLmdhbWVEYXRhLCB0aGlzLm1hcEtleSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmZyYW1lID09IDMwMCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGVja05vZGVFeGlzdCh0aGlzLm1hcEtleSwgMikpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYnVpbGRIb3VzZSh0aGlzLmdhbWVEYXRhKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5mcmFtZSA9PSAzMzApIHtcclxuICAgICAgICAgICAgdGhpcy5wb3B1bGF0aW9uVXBkYXRlKHRoaXMuZ2FtZURhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLmZvb2RVcGRhdGUodGhpcy5nYW1lRGF0YSwgdGhpcy5tYXBLZXkpO1xyXG4gICAgICAgICAgICB0aGlzLnRlY2hVcGRhdGUodGhpcy5nYW1lRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmZyYW1lID49IDM2MCkge1xyXG4gICAgICAgICAgICB0aGlzLmxhbmR1cGRhdGUodGhpcy5nYW1lRGF0YSwgdGhpcy5ub2RlS2V5LCB0aGlzLm1hcEtleSk7XHJcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlV2VhdGhlcih0aGlzLmdhbWVEYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5mcmFtZSA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMudGltZSsrO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmh1bWFuVGltZXIrKztcclxuICAgICAgICBpZiAodGhpcy5odW1hblRpbWVyID4gNjApIHtcclxuICAgICAgICAgICAgdGhpcy5odW1hbk1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5odW1hblRpbWVyID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMubG9nZnJhbWUgJSAyNzAwID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5sb2cuc3RyaW5nID0gJyc7XHJcbiAgICAgICAgICAgIHRoaXMubG9nZnJhbWUgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLkxldmVsVGV4dC5zdHJpbmcgPSAn562J57qnOiAnICsgdGhpcy5nYW1lRGF0YVsxMV07XHJcbiAgICAgICAgdGhpcy5wb3B1bGF0aW9uVGV4dC5zdHJpbmcgPSAn5Lq65Y+jOiAnICsgdGhpcy5nYW1lRGF0YVswXTtcclxuICAgICAgICB0aGlzLmZvb2RUZXh0LnN0cmluZyA9ICfpo5/niak6ICcgKyBNYXRoLnJvdW5kKHRoaXMuZ2FtZURhdGFbMl0pOyBcclxuICAgICAgICAvL3RoaXMudGVjaFRleHQuc3RyaW5nID0gJ+enkeaKgDogJyArIHRoaXMuZ2FtZURhdGFbNF0udG9GaXhlZCgzKTtcclxuICAgICAgICB0aGlzLnRlY2hUZXh0LnN0cmluZyA9ICfnp5HmioA6ICcgKyBNYXRoLnJvdW5kKHRoaXMuZ2FtZURhdGFbNF0gKiAxMDAwKSAvIDEwMDA7XHJcbiAgICAgICAgLy90aGlzLndlYXRoZXJUZXh0LnN0cmluZyA9ICflpKnmsJQ6ICcgKyB0aGlzLmdhbWVEYXRhWzVdLnRvRml4ZWQoMSk7XHJcbiAgICAgICAgdGhpcy5yZXNvdXJjZVRleHQuc3RyaW5nID0gJ+i1hOa6kDogJyArIHRoaXMuZ2FtZURhdGFbM107IFxyXG4gICAgICAgIHRoaXMucG93ZXJUZXh0LnN0cmluZyA9IHRoaXMuZ2FtZURhdGFbN10gKyAnLycgKyB0aGlzLmdhbWVEYXRhWzhdOyBcclxuICAgICAgICB0aGlzLnByb2dyZXNzQmFyVXBkYXRlKCk7XHJcbiAgICAgICAgdGhpcy5nYW1lT3ZlclVwZGF0ZSgpO1xyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==